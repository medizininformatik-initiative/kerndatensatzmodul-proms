# MII Logical Model Modul PRO - Patient-Reported Outcomes und abgeleitete Metriken - MII IG PRO v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII Logical Model Modul PRO - Patient-Reported Outcomes und abgeleitete Metriken**

## Logisches Modell: MII Logical Model Modul PRO - Patient-Reported Outcomes und abgeleitete Metriken ( Experimentell ) 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-lm-pro | *Version*:2027.0.0-ballot.1 |
| Active Stand: 2026-11-04 | *Maschinenlesbarer Name*:MII_LM_PRO |

 
Logisches Modell für die strukturierte Erfassung und Verarbeitung von Patient-Reported Outcomes (PROs) inklusive Fragebögen, Antworten, Scores und Domain-Mappings. 

**Usages:**

* This Logical Model is not used by any profiles in this Specification

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/de.medizininformatikinitiative.kerndatensatz.pros|current/StructureDefinition/StructureDefinition-mii-lm-pro.json)

### Formale Ansichten des Profilinhalts

 [Beschreibung von Profilen, Differentials, Snapshots und deren Repräsentationen](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Schlüsselelemente-Tabelle](#tabs-key) 
*  [Differential-Tabelle](#tabs-diff) 
*  [Snapshot-Tabelle](#tabs-snap) 
*  [Statistiken/Referenzen](#tabs-summ) 
*  [Alle](#tabs-all) 

#### Constraints

Diese Struktur ist abgeleitet von [Base](http://build.fhir.org/types.html#Base) 

#### Constraints

Diese Struktur ist abgeleitet von [Base](http://build.fhir.org/types.html#Base) 

** Summary **

Mandatory: 0 element(38 nested mandatory elements)

 **Schlüsselelemente-Ansicht** 

#### Constraints

 **Differential-Ansicht** 

Diese Struktur ist abgeleitet von [Base](http://build.fhir.org/types.html#Base) 

 **Snapshot-AnsichtView** 

#### Constraints

Diese Struktur ist abgeleitet von [Base](http://build.fhir.org/types.html#Base) 

** Summary **

Mandatory: 0 element(38 nested mandatory elements)

 

Weitere Repräsentationen des Profils: [CSV](../StructureDefinition-mii-lm-pro.csv), [Excel](../StructureDefinition-mii-lm-pro.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "mii-lm-pro",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-lm-pro",
  "version" : "2027.0.0-ballot.1",
  "name" : "MII_LM_PRO",
  "title" : "MII Logical Model Modul PRO - Patient-Reported Outcomes und abgeleitete Metriken",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-11-04T14:34:29+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "Logisches Modell für die strukturierte Erfassung und Verarbeitung von Patient-Reported Outcomes (PROs) inklusive Fragebögen, Antworten, Scores und Domain-Mappings.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "FHIR",
    "name" : "PRO LogicalModel FHIR Mapping"
  }],
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-lm-pro",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "mii-lm-pro",
      "path" : "mii-lm-pro",
      "short" : "MII Logical Model Modul PRO - Patient-Reported Outcomes und abgeleitete Metriken",
      "definition" : "Logisches Modell für die strukturierte Erfassung und Verarbeitung von Patient-Reported Outcomes (PROs) inklusive Fragebögen, Antworten, Scores und Domain-Mappings."
    },
    {
      "id" : "mii-lm-pro.Fragebogen",
      "path" : "mii-lm-pro.Fragebogen",
      "short" : "Fragebogen (Questionnaire)",
      "definition" : "Strukturierter Fragebogen zur Erfassung von Patient-Reported Outcomes",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire",
        "comment" : "Maps to FHIR Questionnaire resource"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.FragebogenID",
      "path" : "mii-lm-pro.Fragebogen.FragebogenID",
      "short" : "Fragebogen-ID",
      "definition" : "Eindeutige Identifikation des Fragebogens",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire.url"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.FragebogenNameVollstaendig",
      "path" : "mii-lm-pro.Fragebogen.FragebogenNameVollstaendig",
      "short" : "Vollständiger Name",
      "definition" : "Ausgeschriebener Name des Fragebogens (z.B. 'Patient Health Questionnaire-9')",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire.title"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.FragebogenNameAbkuerzung",
      "path" : "mii-lm-pro.Fragebogen.FragebogenNameAbkuerzung",
      "short" : "Abkürzung",
      "definition" : "Kurzbezeichnung des Fragebogens (z.B. 'PHQ-9')",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire.name"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.FragebogenVersion",
      "path" : "mii-lm-pro.Fragebogen.FragebogenVersion",
      "short" : "Version",
      "definition" : "Versionsnummer des Fragebogens nach SemVer",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire.version"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.FragebogenIDIntern",
      "path" : "mii-lm-pro.Fragebogen.FragebogenIDIntern",
      "short" : "Interne ID",
      "definition" : "Einrichtungsspezifische ID",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.FragebogenStandardID",
      "path" : "mii-lm-pro.Fragebogen.FragebogenStandardID",
      "short" : "Standard-ID",
      "definition" : "ID aus Standardterminologie (z.B. LOINC)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire.code.code"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.FragebogenStandardSystem",
      "path" : "mii-lm-pro.Fragebogen.FragebogenStandardSystem",
      "short" : "Codesystem",
      "definition" : "URI des verwendeten Codesystems",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire.code.system"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.FragebogenStandardVersion",
      "path" : "mii-lm-pro.Fragebogen.FragebogenStandardVersion",
      "short" : "Codesystem-Version",
      "definition" : "Version des verwendeten Codesystems",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen",
      "path" : "mii-lm-pro.Fragebogen.Fragen",
      "short" : "Fragen",
      "definition" : "Einzelne Fragen/Items des Fragebogens",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire.item"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.FragenIDIntern",
      "path" : "mii-lm-pro.Fragebogen.Fragen.FragenIDIntern",
      "short" : "Frage-ID",
      "definition" : "Eindeutige ID der Frage innerhalb des Fragebogens",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire.item.linkId"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.FragenIDStandardID",
      "path" : "mii-lm-pro.Fragebogen.Fragen.FragenIDStandardID",
      "short" : "Standard Frage-ID",
      "definition" : "ID der Frage aus Standardterminologie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.FragenIDStandardSystem",
      "path" : "mii-lm-pro.Fragebogen.Fragen.FragenIDStandardSystem",
      "short" : "Frage Codesystem",
      "definition" : "Codesystem der Frage",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.FragenIDStandardVersion",
      "path" : "mii-lm-pro.Fragebogen.Fragen.FragenIDStandardVersion",
      "short" : "Frage Codesystem-Version",
      "definition" : "Version des Frage-Codesystems",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.Fragetext",
      "path" : "mii-lm-pro.Fragebogen.Fragen.Fragetext",
      "short" : "Fragetext",
      "definition" : "Der anzuzeigende Fragetext",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire.item.text"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.FragetextAusfuellhinweise",
      "path" : "mii-lm-pro.Fragebogen.Fragen.FragetextAusfuellhinweise",
      "short" : "Ausfüllhinweise",
      "definition" : "Instruktionen zum Ausfüllen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.Anzeigemodalitaet",
      "path" : "mii-lm-pro.Fragebogen.Fragen.Anzeigemodalitaet",
      "short" : "Anzeigemodus",
      "definition" : "Art der Darstellung (z.B. Radio-Button, Slider)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.FragetextAusgefuelltWenn",
      "path" : "mii-lm-pro.Fragebogen.Fragen.FragetextAusgefuelltWenn",
      "short" : "Bedingte Anzeige",
      "definition" : "FHIRPath-Expression für bedingte Anzeige",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage",
      "short" : "Antwortoptionen",
      "definition" : "Definierte Antwortmöglichkeiten",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.Antworttyp",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.Antworttyp",
      "short" : "Antworttyp",
      "definition" : "Datentyp der Antwort (boolean, integer, string, etc.)",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire.item.type"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortUhrzeit",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortUhrzeit",
      "short" : "Zeiterfassung",
      "definition" : "Ob Zeitpunkt der Antwort erfasst wird",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortDatum",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortDatum",
      "short" : "Datumsformat",
      "definition" : "Spezifikation für Datumsantworten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortDatum.minDatum",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortDatum.minDatum",
      "short" : "Minimales Datum",
      "definition" : "Frühestes erlaubtes Datum",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortDatum.Datumsgenauigkeit",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortDatum.Datumsgenauigkeit",
      "short" : "Genauigkeit",
      "definition" : "Tag, Monat oder Jahr",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortNumerischerWert",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortNumerischerWert",
      "short" : "Numerische Antwort",
      "definition" : "Spezifikation für numerische Antworten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortNumerischerWert.AntwortNumerischerWertKleinster",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortNumerischerWert.AntwortNumerischerWertKleinster",
      "short" : "Minimum",
      "definition" : "Kleinster erlaubter Wert",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortNumerischerWert.AntwortNumerischerWertGroesster",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortNumerischerWert.AntwortNumerischerWertGroesster",
      "short" : "Maximum",
      "definition" : "Größter erlaubter Wert",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortNumerischerWert.AntwortNumerischerWertEinheit",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortNumerischerWert.AntwortNumerischerWertEinheit",
      "short" : "Einheit",
      "definition" : "UCUM-Code der Einheit",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortNumerischerWert.AntwortNumerischerWertPraezision",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortNumerischerWert.AntwortNumerischerWertPraezision",
      "short" : "Dezimalstellen",
      "definition" : "Anzahl der Nachkommastellen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortString",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortString",
      "short" : "Text-Antwort",
      "definition" : "Spezifikation für Textantworten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortString.AntwortStringMinLength",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortString.AntwortStringMinLength",
      "short" : "Minimale Länge",
      "definition" : "Minimale Anzahl Zeichen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortString.AntwortStringMaxLength",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortString.AntwortStringMaxLength",
      "short" : "Maximale Länge",
      "definition" : "Maximale Anzahl Zeichen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "integer"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl",
      "short" : "Auswahlantworten",
      "definition" : "Vordefinierte Antwortoptionen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.Mehrfachauswahl",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.Mehrfachauswahl",
      "short" : "Mehrfachauswahl",
      "definition" : "Ob mehrere Optionen wählbar sind",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortStandardValueSetReference",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortStandardValueSetReference",
      "short" : "ValueSet Referenz",
      "definition" : "Verweis auf externes ValueSet",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption",
      "short" : "Antwortoption",
      "definition" : "Einzelne Antwortoption",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire.item.answerOption"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionText",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionText",
      "short" : "Anzeigetext",
      "definition" : "Text der Antwortoption",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionExklusive",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionExklusive",
      "short" : "Exklusiv",
      "definition" : "Schließt andere Optionen aus",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionCodeIntern",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionCodeIntern",
      "short" : "Interner Code",
      "definition" : "Einrichtungsspezifischer Code",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionStandardCode",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionStandardCode",
      "short" : "Standard Code",
      "definition" : "Code aus Standardterminologie",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionStandardSystem",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionStandardSystem",
      "short" : "Codesystem",
      "definition" : "URI des Codesystems",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionStandardSystemVersion",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionStandardSystemVersion",
      "short" : "Codesystem-Version",
      "definition" : "Version des Codesystems",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionGewicht",
      "path" : "mii-lm-pro.Fragebogen.Fragen.AntwortVorlage.AntwortAuswahl.AntwortAuswahlOption.AntwortOptionGewicht",
      "short" : "Scoring-Gewicht",
      "definition" : "Numerischer Wert für Score-Berechnung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Autoren",
      "path" : "mii-lm-pro.Fragebogen.Autoren",
      "short" : "Autoren",
      "definition" : "Ersteller des Fragebogens",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Autoren.Autor",
      "path" : "mii-lm-pro.Fragebogen.Autoren.Autor",
      "short" : "Name",
      "definition" : "Name des Autors oder der Organisation",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Fragebogen.Copyright",
      "path" : "mii-lm-pro.Fragebogen.Copyright",
      "short" : "Copyright",
      "definition" : "Urheberrechtsinformationen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Questionnaire.copyright"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen",
      "path" : "mii-lm-pro.AusgefuellterFragebogen",
      "short" : "Ausgefüllter Fragebogen (QuestionnaireResponse)",
      "definition" : "Ausgefüllte Instanz eines Fragebogens",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "QuestionnaireResponse",
        "comment" : "Maps to FHIR QuestionnaireResponse resource"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen.FragebogenIDIntern",
      "path" : "mii-lm-pro.AusgefuellterFragebogen.FragebogenIDIntern",
      "short" : "Referenz zum Fragebogen",
      "definition" : "Verweis auf den zugrundeliegenden Fragebogen",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "QuestionnaireResponse.questionnaire"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen.Antwort",
      "path" : "mii-lm-pro.AusgefuellterFragebogen.Antwort",
      "short" : "Antworten",
      "definition" : "Erfasste Antworten",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "QuestionnaireResponse.item"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortErfasst",
      "path" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortErfasst",
      "short" : "Antwort vorhanden",
      "definition" : "Ob eine Antwort gegeben wurde",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "boolean"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.FragenIntern",
      "path" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.FragenIntern",
      "short" : "Frage-Referenz",
      "definition" : "Verweis auf die beantwortete Frage",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "QuestionnaireResponse.item.linkId"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortCode",
      "path" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortCode",
      "short" : "Antwort-Code",
      "definition" : "Codierte Antwort",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "QuestionnaireResponse.item.answer.valueCoding"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortNummer",
      "path" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortNummer",
      "short" : "Numerische Antwort",
      "definition" : "Zahlenwert als Antwort",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "QuestionnaireResponse.item.answer.valueDecimal"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortString",
      "path" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortString",
      "short" : "Text-Antwort",
      "definition" : "Freitext als Antwort",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "QuestionnaireResponse.item.answer.valueString"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortDatum",
      "path" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortDatum",
      "short" : "Datums-Antwort",
      "definition" : "Datum als Antwort",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "date"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "QuestionnaireResponse.item.answer.valueDate"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.Erfassungsdatum",
      "path" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.Erfassungsdatum",
      "short" : "Erfassungszeitpunkt",
      "definition" : "Zeitpunkt der Antworterfassung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "QuestionnaireResponse.authored"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortVorlage",
      "path" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortVorlage",
      "short" : "Gewählte Option",
      "definition" : "Bei Auswahlantworten",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortVorlage.Antworttyp",
      "path" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortVorlage.Antworttyp",
      "short" : "Typ",
      "definition" : "Typ der gewählten Antwort",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortVorlage.Antwortinhalt",
      "path" : "mii-lm-pro.AusgefuellterFragebogen.Antwort.AntwortVorlage.Antwortinhalt",
      "short" : "Inhalt",
      "definition" : "Inhalt der gewählten Option",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score",
      "path" : "mii-lm-pro.Score",
      "short" : "Scores (Observation)",
      "definition" : "Berechnete Scores aus Fragebögen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage",
      "path" : "mii-lm-pro.Score.ScoreVorlage",
      "short" : "Score-Definition (ObservationDefinition)",
      "definition" : "Template für Score-Berechnung",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "ObservationDefinition",
        "comment" : "Maps to FHIR ObservationDefinition resource"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.ScoreVorlageID",
      "path" : "mii-lm-pro.Score.ScoreVorlage.ScoreVorlageID",
      "short" : "Score-ID",
      "definition" : "Eindeutige Identifikation des Score-Typs",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "ObservationDefinition.id"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.ScoreName",
      "path" : "mii-lm-pro.Score.ScoreVorlage.ScoreName",
      "short" : "Score-Name",
      "definition" : "Bezeichnung des Scores",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "ObservationDefinition.code.display"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Scoreberechnung",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Scoreberechnung",
      "short" : "Berechnungsvorschrift",
      "definition" : "Algorithmus zur Score-Berechnung",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Scoreberechnung.ScoreBerechnungsID",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Scoreberechnung.ScoreBerechnungsID",
      "short" : "Berechnungs-ID",
      "definition" : "ID des Berechnungsalgorithmus",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Scoreberechnung.ScoreDatentyp",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Scoreberechnung.ScoreDatentyp",
      "short" : "Ergebnis-Datentyp",
      "definition" : "Datentyp des berechneten Scores",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "ObservationDefinition.quantitativeDetails.type"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Scoreberechnung.ScoreBerechnungsAlgorithmus",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Scoreberechnung.ScoreBerechnungsAlgorithmus",
      "short" : "Algorithmus",
      "definition" : "FHIRPath oder CQL Expression",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Scoreberechnung.ScoreQuelle",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Scoreberechnung.ScoreQuelle",
      "short" : "Quellenangabe",
      "definition" : "Referenz zur Algorithmus-Dokumentation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "uri"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala",
      "short" : "Domain-Zuordnung",
      "definition" : "Zuordnung zu Gesundheitsdomänen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainID",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainID",
      "short" : "Domain-ID",
      "definition" : "ID der Gesundheitsdomäne",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainCode",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainCode",
      "short" : "Domain-Code",
      "definition" : "Code der Domain (z.B. SNOMED)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainTitel",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainTitel",
      "short" : "Domain-Titel",
      "definition" : "Name der Domain",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainBeschreibung",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainBeschreibung",
      "short" : "Beschreibung",
      "definition" : "Beschreibung der Domain",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainSkalen",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainSkalen",
      "short" : "Skalen-Details",
      "definition" : "Details zur Domain-Skala",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainSkalen.Minimum",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainSkalen.Minimum",
      "short" : "Minimum",
      "definition" : "Minimaler Skalenwert",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainSkalen.Maximum",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainSkalen.Maximum",
      "short" : "Maximum",
      "definition" : "Maximaler Skalenwert",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainSkalen.Skalenwert",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainSkalen.Skalenwert",
      "short" : "Skalentyp",
      "definition" : "Art der Skala (ordinal, interval, ratio)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainSkalen.DomainenskalaDomainenskala",
      "path" : "mii-lm-pro.Score.ScoreVorlage.Domainenskala.DomainSkalen.DomainenskalaDomainenskala",
      "short" : "Subskalierung",
      "definition" : "Verweis auf Unterskalen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping",
      "path" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping",
      "short" : "Score-Mapping",
      "definition" : "Mapping zu anderen Scoring-Systemen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping.SourceScoreID",
      "path" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping.SourceScoreID",
      "short" : "Quell-Score",
      "definition" : "ID des Ausgangs-Scores",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping.TargetScoreID",
      "path" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping.TargetScoreID",
      "short" : "Ziel-Score",
      "definition" : "ID des Ziel-Scores",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping.MappingScorewert",
      "path" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping.MappingScorewert",
      "short" : "Wert-Mapping",
      "definition" : "Konkrete Wertezuordnungen",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping.MappingScorewert.SourceValue",
      "path" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping.MappingScorewert.SourceValue",
      "short" : "Quellwert",
      "definition" : "Wert im Ausgangssystem",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping.MappingScorewert.TargetValue",
      "path" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping.MappingScorewert.TargetValue",
      "short" : "Zielwert",
      "definition" : "Wert im Zielsystem",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping.MappingScorewert.MappingExpression",
      "path" : "mii-lm-pro.Score.ScoreVorlage.ScoreMapping.MappingScorewert.MappingExpression",
      "short" : "Mapping-Formel",
      "definition" : "Mathematische Transformation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreBerechnet",
      "path" : "mii-lm-pro.Score.ScoreBerechnet",
      "short" : "Berechnete Score-Instanz",
      "definition" : "Konkret berechneter Score-Wert",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation",
        "comment" : "Maps to FHIR Observation resource"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreBerechnet.ScoreID",
      "path" : "mii-lm-pro.Score.ScoreBerechnet.ScoreID",
      "short" : "Score-Instanz-ID",
      "definition" : "ID der Score-Berechnung",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.id"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreBerechnet.ScoreVorlage",
      "path" : "mii-lm-pro.Score.ScoreBerechnet.ScoreVorlage",
      "short" : "Score-Template",
      "definition" : "Verweis auf Score-Definition",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreBerechnet.ScoreBerechnung",
      "path" : "mii-lm-pro.Score.ScoreBerechnet.ScoreBerechnung",
      "short" : "Verwendeter Algorithmus",
      "definition" : "Referenz zum Berechnungsalgorithmus",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreBerechnet.Berechnungsdatum",
      "path" : "mii-lm-pro.Score.ScoreBerechnet.Berechnungsdatum",
      "short" : "Berechnungszeitpunkt",
      "definition" : "Zeitpunkt der Score-Berechnung",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "dateTime"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.effectiveDateTime"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreBerechnet.ScoreInterpretation",
      "path" : "mii-lm-pro.Score.ScoreBerechnet.ScoreInterpretation",
      "short" : "Interpretation",
      "definition" : "Klinische Interpretation (normal, auffällig, kritisch)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.interpretation"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreBerechnet.BerechneterScorewert",
      "path" : "mii-lm-pro.Score.ScoreBerechnet.BerechneterScorewert",
      "short" : "Score-Wert",
      "definition" : "Der berechnete numerische Wert",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.valueQuantity.value"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreFragebogenScore",
      "path" : "mii-lm-pro.Score.ScoreFragebogenScore",
      "short" : "Fragebogen-basierter Score",
      "definition" : "Score direkt aus Fragebogen berechnet",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreFragebogenScore.FragebogenVorlage",
      "path" : "mii-lm-pro.Score.ScoreFragebogenScore.FragebogenVorlage",
      "short" : "Fragebogen-Referenz",
      "definition" : "Verweis auf Fragebogen-Template",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreFragebogenScore.AusgefuellterFragebogen",
      "path" : "mii-lm-pro.Score.ScoreFragebogenScore.AusgefuellterFragebogen",
      "short" : "Response-Referenz",
      "definition" : "Verweis auf QuestionnaireResponse",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }],
      "mapping" : [{
        "identity" : "FHIR",
        "map" : "Observation.derivedFrom[QuestionnaireResponse]"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreItembasierterScore",
      "path" : "mii-lm-pro.Score.ScoreItembasierterScore",
      "short" : "Item-basierter Score",
      "definition" : "Score aus einzelnen Items/Antworten",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Score.ScoreItembasierterScore.AusgefuellteAntworten",
      "path" : "mii-lm-pro.Score.ScoreItembasierterScore.AusgefuellteAntworten",
      "short" : "Item-Referenzen",
      "definition" : "Verweise auf einzelne Antwort-Items",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene",
      "path" : "mii-lm-pro.Domaene",
      "short" : "Gesundheitsdomänen",
      "definition" : "Klassifikation nach Gesundheitsbereichen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.DomaeneID",
      "path" : "mii-lm-pro.Domaene.DomaeneID",
      "short" : "Domain-ID",
      "definition" : "Eindeutige ID der Domain",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.DomaeneCode",
      "path" : "mii-lm-pro.Domaene.DomaeneCode",
      "short" : "Domain-Code",
      "definition" : "Standardisierter Code (z.B. ICF)",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.DomaeneTitel",
      "path" : "mii-lm-pro.Domaene.DomaeneTitel",
      "short" : "Domain-Name",
      "definition" : "Bezeichnung der Domain",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.DomaeneBeschreibung",
      "path" : "mii-lm-pro.Domaene.DomaeneBeschreibung",
      "short" : "Beschreibung",
      "definition" : "Detaillierte Beschreibung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.DomaeneSkaliert",
      "path" : "mii-lm-pro.Domaene.DomaeneSkaliert",
      "short" : "Skalierung",
      "definition" : "Skalierungsinformationen",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.DomaeneSkaliert.DomaenenSkalenID",
      "path" : "mii-lm-pro.Domaene.DomaeneSkaliert.DomaenenSkalenID",
      "short" : "Skalen-ID",
      "definition" : "ID der Domänenskala",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.DomaeneSkaliert.Minimum",
      "path" : "mii-lm-pro.Domaene.DomaeneSkaliert.Minimum",
      "short" : "Minimum",
      "definition" : "Minimaler Wert",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.DomaeneSkaliert.Maximum",
      "path" : "mii-lm-pro.Domaene.DomaeneSkaliert.Maximum",
      "short" : "Maximum",
      "definition" : "Maximaler Wert",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.DomaeneSkaliert.Skalenwert",
      "path" : "mii-lm-pro.Domaene.DomaeneSkaliert.Skalenwert",
      "short" : "Skalentyp",
      "definition" : "Art der Skala",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.Referenzpopulation",
      "path" : "mii-lm-pro.Domaene.Referenzpopulation",
      "short" : "Referenzpopulation",
      "definition" : "Normwerte für Populationen",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "BackboneElement"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.Referenzpopulation.Altersbereich",
      "path" : "mii-lm-pro.Domaene.Referenzpopulation.Altersbereich",
      "short" : "Altersbereich",
      "definition" : "z.B. '18-65 Jahre'",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.Referenzpopulation.Geschlecht",
      "path" : "mii-lm-pro.Domaene.Referenzpopulation.Geschlecht",
      "short" : "Geschlecht",
      "definition" : "Geschlechtsspezifische Norm",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "code"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.Referenzpopulation.Indikation",
      "path" : "mii-lm-pro.Domaene.Referenzpopulation.Indikation",
      "short" : "Indikation",
      "definition" : "Krankheitsspezifische Norm",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.Referenzpopulation.Mittelwert",
      "path" : "mii-lm-pro.Domaene.Referenzpopulation.Mittelwert",
      "short" : "Mittelwert",
      "definition" : "Durchschnittswert der Population",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    },
    {
      "id" : "mii-lm-pro.Domaene.Referenzpopulation.Standardabweichung",
      "path" : "mii-lm-pro.Domaene.Referenzpopulation.Standardabweichung",
      "short" : "Standardabweichung",
      "definition" : "Streuung der Werte",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "decimal"
      }]
    }]
  }
}

```
