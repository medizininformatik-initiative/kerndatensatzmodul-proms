# MII VS PRO PROMIS Frequency Response Scale - MII IG PRO v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII VS PRO PROMIS Frequency Response Scale**

## ValueSet: MII VS PRO PROMIS Frequency Response Scale (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-promis-frequency-response-scale | *Version*:2027.0.0-ballot.1 |
| Active as of 2026-11-04 | *Computable Name*:MII_VS_PRO_PROMIS_Frequency_Response_Scale |

 
PROMIS Frequency response scale based on LOINC LL1016-6 

 **References** 

* [MII QST PRO PROMIS-16 (Adults)](Questionnaire-mii-qst-pro-promis-16.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-pro-promis-frequency-response-scale",
  "language" : "en",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-promis-frequency-response-scale",
  "version" : "2027.0.0-ballot.1",
  "name" : "MII_VS_PRO_PROMIS_Frequency_Response_Scale",
  "title" : "MII VS PRO PROMIS Frequency Response Scale",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-11-04T14:56:33+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "PROMIS Frequency response scale based on LOINC LL1016-6",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "LA6270-8",
        "display" : "Never",
        "designation" : [{
          "language" : "de",
          "value" : "Nie"
        }]
      },
      {
        "code" : "LA10066-1",
        "display" : "Rarely",
        "designation" : [{
          "language" : "de",
          "value" : "Selten"
        }]
      },
      {
        "code" : "LA10082-8",
        "display" : "Sometimes",
        "designation" : [{
          "language" : "de",
          "value" : "Manchmal"
        }]
      },
      {
        "code" : "LA10044-8",
        "display" : "Often",
        "designation" : [{
          "language" : "de",
          "value" : "Oft"
        }]
      },
      {
        "code" : "LA9933-8",
        "display" : "Always",
        "designation" : [{
          "language" : "de",
          "value" : "Immer"
        }]
      }]
    }]
  }
}

```
