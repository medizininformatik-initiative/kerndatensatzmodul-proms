# MII PR PRO Score Blueprint / Template - MII IG PRO v2027.0.0-ballot.rc4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII PR PRO Score Blueprint / Template**

## Resource Profile: MII PR PRO Score Blueprint / Template 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-pr-pro-score-blueprint | *Version*:2027.0.0-ballot.rc4 |
| Active as of 2026-09-10 | *Computable Name*:MII_PR_PRO_Score_Blueprint |

 
MII PR PRO Questionnaire, based on the FHIR Structure Data Capture Specification 

The abstract Score Blueprint profile defines the structure of ObservationDefinitions that serve as templates for PRO scores. It describes which scores an instrument produces, including value ranges, units and reference intervals. Concrete score definitions (the PHQ-9 total score, the EQ-5D-5L index and so on) must extend this abstract profile.

**Core elements:**

* A code for unambiguous score identification (typically LOINC)
* quantitativeDetails with units and value ranges
* qualifiedInterval for reference ranges (clinical cut-offs, for instance)
* Population-specific norms
* The health-correlation extension giving the direction of score interpretation

**Example** — a concrete score definition extending this abstract profile: [BDI-II score definition](ObservationDefinition-mii-obsdef-pro-score-bdi-ii.md).

**Usages:**

* Examples for this Profile: [ObservationDefinition/mii-obsdef-pro-depression-t-score](ObservationDefinition-mii-obsdef-pro-depression-t-score.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-ap](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-ap.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-cf](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-cf.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-co](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-co.md)... Show 43 more, [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-di](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-di.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-dy](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-dy.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-ef](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-ef.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-fa](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-fa.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-fi](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-fi.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-nv](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-nv.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-pa](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-pa.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-pf](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-pf.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-ql](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-ql.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-rf](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-rf.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-sf](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-sf.md), [ObservationDefinition/mii-obsdef-pro-eortc-qlq-c30-sl](ObservationDefinition-mii-obsdef-pro-eortc-qlq-c30-sl.md), [ObservationDefinition/mii-obsdef-pro-promis-29-anxiety-tscore](ObservationDefinition-mii-obsdef-pro-promis-29-anxiety-tscore.md), [ObservationDefinition/mii-obsdef-pro-promis-29-depression-tscore](ObservationDefinition-mii-obsdef-pro-promis-29-depression-tscore.md), [ObservationDefinition/mii-obsdef-pro-promis-29-fatigue-tscore](ObservationDefinition-mii-obsdef-pro-promis-29-fatigue-tscore.md), [ObservationDefinition/mii-obsdef-pro-promis-29-pain-intensity](ObservationDefinition-mii-obsdef-pro-promis-29-pain-intensity.md), [ObservationDefinition/mii-obsdef-pro-promis-29-pain-interference-tscore](ObservationDefinition-mii-obsdef-pro-promis-29-pain-interference-tscore.md), [ObservationDefinition/mii-obsdef-pro-promis-29-physical-function-tscore](ObservationDefinition-mii-obsdef-pro-promis-29-physical-function-tscore.md), [ObservationDefinition/mii-obsdef-pro-promis-29-sleep-disturbance-tscore](ObservationDefinition-mii-obsdef-pro-promis-29-sleep-disturbance-tscore.md), [ObservationDefinition/mii-obsdef-pro-promis-29-social-function-tscore](ObservationDefinition-mii-obsdef-pro-promis-29-social-function-tscore.md), [ObservationDefinition/mii-obsdef-pro-promis-cognitive-function-sf4a-raw-score](ObservationDefinition-mii-obsdef-pro-promis-cognitive-function-sf4a-raw-score.md), [ObservationDefinition/mii-obsdef-pro-promis-cognitive-function-sf4a-tscore](ObservationDefinition-mii-obsdef-pro-promis-cognitive-function-sf4a-tscore.md), [ObservationDefinition/mii-obsdef-pro-score-bdi-ii](ObservationDefinition-mii-obsdef-pro-score-bdi-ii.md), [ObservationDefinition/mii-obsdef-pro-score-dass21-anxiety-equiv](ObservationDefinition-mii-obsdef-pro-score-dass21-anxiety-equiv.md), [ObservationDefinition/mii-obsdef-pro-score-dass21-anxiety-raw](ObservationDefinition-mii-obsdef-pro-score-dass21-anxiety-raw.md), [ObservationDefinition/mii-obsdef-pro-score-dass21-depression-equiv](ObservationDefinition-mii-obsdef-pro-score-dass21-depression-equiv.md), [ObservationDefinition/mii-obsdef-pro-score-dass21-depression-raw](ObservationDefinition-mii-obsdef-pro-score-dass21-depression-raw.md), [ObservationDefinition/mii-obsdef-pro-score-dass21-stress-equiv](ObservationDefinition-mii-obsdef-pro-score-dass21-stress-equiv.md), [ObservationDefinition/mii-obsdef-pro-score-dass21-stress-raw](ObservationDefinition-mii-obsdef-pro-score-dass21-stress-raw.md), [ObservationDefinition/mii-obsdef-pro-score-eq5d5l-index](ObservationDefinition-mii-obsdef-pro-score-eq5d5l-index.md), [ObservationDefinition/mii-obsdef-pro-score-eq5d5l-profile](ObservationDefinition-mii-obsdef-pro-score-eq5d5l-profile.md), [ObservationDefinition/mii-obsdef-pro-score-eq5d5l-vas](ObservationDefinition-mii-obsdef-pro-score-eq5d5l-vas.md), [ObservationDefinition/mii-obsdef-pro-score-gad-7](ObservationDefinition-mii-obsdef-pro-score-gad-7.md), [ObservationDefinition/mii-obsdef-pro-score-isr-z](ObservationDefinition-mii-obsdef-pro-score-isr-z.md), [ObservationDefinition/mii-obsdef-pro-score-pc-ptsd](ObservationDefinition-mii-obsdef-pro-score-pc-ptsd.md), [ObservationDefinition/mii-obsdef-pro-score-phq-15](ObservationDefinition-mii-obsdef-pro-score-phq-15.md), [ObservationDefinition/mii-obsdef-pro-score-phq-9](ObservationDefinition-mii-obsdef-pro-score-phq-9.md), [ObservationDefinition/mii-obsdef-pro-score-proctcae-acs](ObservationDefinition-mii-obsdef-pro-score-proctcae-acs.md), [ObservationDefinition/mii-obsdef-pro-score-proctcae-composite-grade](ObservationDefinition-mii-obsdef-pro-score-proctcae-composite-grade.md), [ObservationDefinition/mii-obsdef-pro-score-scoff](ObservationDefinition-mii-obsdef-pro-score-scoff.md), [ObservationDefinition/mii-obsdef-pro-score-ssd-12](ObservationDefinition-mii-obsdef-pro-score-ssd-12.md), [ObservationDefinition/mii-obsdef-pro-score-whodas12-simple-sum](ObservationDefinition-mii-obsdef-pro-score-whodas12-simple-sum.md) and [ObservationDefinition/mii-obsdef-pro-score-wi-7](ObservationDefinition-mii-obsdef-pro-score-wi-7.md)
* CapabilityStatements using this Profile: [MII CPS PRO CapabilityStatement](CapabilityStatement-mii-cps-pro-capabilitystatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/de.medizininformatikinitiative.kerndatensatz.pros|current/StructureDefinition/StructureDefinition-mii-pr-pro-score-blueprint.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-mii-pr-pro-score-blueprint.csv), [Excel](../StructureDefinition-mii-pr-pro-score-blueprint.xlsx), [Schematron](../StructureDefinition-mii-pr-pro-score-blueprint.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "mii-pr-pro-score-blueprint",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-pr-pro-score-blueprint",
  "version" : "2027.0.0-ballot.rc4",
  "name" : "MII_PR_PRO_Score_Blueprint",
  "title" : "MII PR PRO Score Blueprint / Template",
  "status" : "active",
  "date" : "2026-09-10T16:43:20+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "MII PR PRO Questionnaire, based on the FHIR Structure Data Capture Specification",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "ObservationDefinition",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/ObservationDefinition",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "ObservationDefinition",
      "path" : "ObservationDefinition"
    },
    {
      "id" : "ObservationDefinition.code",
      "path" : "ObservationDefinition.code",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.code.coding",
      "path" : "ObservationDefinition.code.coding",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "description" : "Different code systems for the same questionnaire",
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.code.coding:snomed",
      "path" : "ObservationDefinition.code.coding",
      "sliceName" : "snomed",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "ObservationDefinition.code.coding:snomed.system",
      "path" : "ObservationDefinition.code.coding.system",
      "min" : 1,
      "fixedUri" : "http://snomed.info/sct",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.code.coding:snomed.code",
      "path" : "ObservationDefinition.code.coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.code.coding:loinc",
      "path" : "ObservationDefinition.code.coding",
      "sliceName" : "loinc",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "ObservationDefinition.code.coding:loinc.system",
      "path" : "ObservationDefinition.code.coding.system",
      "min" : 1,
      "fixedUri" : "http://loinc.org",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.code.coding:loinc.code",
      "path" : "ObservationDefinition.code.coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.code.coding:mii",
      "path" : "ObservationDefinition.code.coding",
      "sliceName" : "mii",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "ObservationDefinition.code.coding:mii.system",
      "path" : "ObservationDefinition.code.coding.system",
      "min" : 1,
      "fixedUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-score-catalogue",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.code.coding:mii.code",
      "path" : "ObservationDefinition.code.coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.permittedDataType",
      "path" : "ObservationDefinition.permittedDataType",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.preferredReportName",
      "path" : "ObservationDefinition.preferredReportName",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.quantitativeDetails.customaryUnit",
      "path" : "ObservationDefinition.quantitativeDetails.customaryUnit",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.quantitativeDetails.unit",
      "path" : "ObservationDefinition.quantitativeDetails.unit",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.quantitativeDetails.decimalPrecision",
      "path" : "ObservationDefinition.quantitativeDetails.decimalPrecision",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.qualifiedInterval",
      "path" : "ObservationDefinition.qualifiedInterval",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.qualifiedInterval.category",
      "path" : "ObservationDefinition.qualifiedInterval.category",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.qualifiedInterval.range.extension",
      "path" : "ObservationDefinition.qualifiedInterval.range.extension",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.qualifiedInterval.range.extension:ScoreHealthCorrelation",
      "path" : "ObservationDefinition.qualifiedInterval.range.extension",
      "sliceName" : "ScoreHealthCorrelation",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-ex-pro-score-score-health-correlation"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.qualifiedInterval.range.extension:ScoreHealthCorrelation.value[x]",
      "path" : "ObservationDefinition.qualifiedInterval.range.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.qualifiedInterval.range.low",
      "path" : "ObservationDefinition.qualifiedInterval.range.low",
      "mustSupport" : true
    },
    {
      "id" : "ObservationDefinition.qualifiedInterval.range.high",
      "path" : "ObservationDefinition.qualifiedInterval.range.high",
      "mustSupport" : true
    }]
  }
}

```
