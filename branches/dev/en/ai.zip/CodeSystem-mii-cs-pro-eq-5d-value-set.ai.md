# MII CS EQ-5D Value Set - MII IG PRO v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII CS EQ-5D Value Set**

## CodeSystem: MII CS EQ-5D Value Set (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-eq-5d-value-set | *Version*:2027.0.0-ballot.1 |
| Active as of 2026-11-05 | *Computable Name*:MII_CS_PRO_EQ_5D_ValueSet |

 
EuroQol EQ-5D Value Set 

This Code system is referenced in the definition of the following value sets:

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "mii-cs-pro-eq-5d-value-set",
  "language" : "de-DE",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-eq-5d-value-set",
  "version" : "2027.0.0-ballot.1",
  "name" : "MII_CS_PRO_EQ_5D_ValueSet",
  "title" : "MII CS EQ-5D Value Set",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-11-05T04:04:59+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "EuroQol EQ-5D Value Set",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "hierarchyMeaning" : "grouped-by",
  "content" : "complete",
  "count" : 36,
  "property" : [{
    "code" : "eq-5d-vs-coefficient-de-de",
    "description" : "EQ-5D ValueSet Coefficient Germany",
    "type" : "decimal"
  },
  {
    "code" : "eq-5d-vs-coefficient-en-us",
    "description" : "EQ-5D ValueSet Coefficient US",
    "type" : "decimal"
  }],
  "concept" : [{
    "code" : "MO",
    "display" : "BEWEGLICHKEIT / MOBILITÄT",
    "designation" : [{
      "language" : "en",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "MOBILITY"
    }],
    "concept" : [{
      "code" : "MO-1",
      "display" : "Ich habe keine Probleme herumzugehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have no problems in walking about"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0
      }]
    },
    {
      "code" : "MO-2",
      "display" : "Ich habe leichte Probleme herumzugehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have slight problems in walking about"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.026
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.096
      }]
    },
    {
      "code" : "MO-3",
      "display" : "Ich habe mäßige Probleme herumzugehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have moderate problems in walking about"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.042
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.122
      }]
    },
    {
      "code" : "MO-4",
      "display" : "Ich habe große Probleme herumzugehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have severe problems in walking about"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.139
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.237
      }]
    },
    {
      "code" : "MO-5",
      "display" : "Ich bin nicht in der Lage herumzugehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I am unable to walk about"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.224
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.322
      }]
    }]
  },
  {
    "code" : "SC",
    "display" : "FÜR SICH SELBST SORGEN",
    "designation" : [{
      "language" : "en",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "SELF-CARE"
    }],
    "concept" : [{
      "code" : "SC-1",
      "display" : "Ich habe keine Probleme, mich selbst zu waschen oder anzuziehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have no problems washing or dressing myself"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0
      }]
    },
    {
      "code" : "SC-2",
      "display" : "Ich habe leichte Probleme, mich selbst zu waschen oder anzuziehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have slight problems washing or dressing myself"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.05
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.089
      }]
    },
    {
      "code" : "SC-3",
      "display" : "Ich habe mäßige Probleme, mich selbst zu waschen oder anzuziehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have moderate problems washing or dressing myself"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.056
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.107
      }]
    },
    {
      "code" : "SC-4",
      "display" : "Ich habe große Probleme, mich selbst zu waschen oder anzuziehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have severe problems washing or dressing myself"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.169
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.22
      }]
    },
    {
      "code" : "SC-5",
      "display" : "Ich bin nicht in der Lage, mich selbst zu waschen oder anzuziehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I am unable to wash or dress myself"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.26
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.261
      }]
    }]
  },
  {
    "code" : "UA",
    "display" : "ALLTÄGLICHE TÄTIGKEITEN (z.B. Arbeit, Studium, Hausarbeit, Familien- / Freizeitaktivitäten)",
    "designation" : [{
      "language" : "en",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "USUAL ACTIVITIES (e.g. work, study, housework, family or leisure activities)"
    }],
    "concept" : [{
      "code" : "UA-1",
      "display" : "Ich habe keine Probleme, meinen alltäglichen Tätigkeiten nachzugehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have no problems doing my usual activities"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0
      }]
    },
    {
      "code" : "UA-2",
      "display" : "Ich habe leichte Probleme, meinen alltäglichen Tätigkeiten nachzugehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have slight problems doing my usual activities"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.036
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.068
      }]
    },
    {
      "code" : "UA-3",
      "display" : "Ich habe mäßige Probleme, meinen alltäglichen Tätigkeiten nachzugehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have moderate problems doing my usual activities"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.049
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.101
      }]
    },
    {
      "code" : "UA-4",
      "display" : "Ich habe große Probleme, meinen alltäglichen Tätigkeiten nachzugehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have severe problems doing my usual activities"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.129
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.255
      }]
    },
    {
      "code" : "UA-5",
      "display" : "Ich bin nicht in der Lage, meinen alltäglichen Tätigkeiten nachzugehen",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I am unable to do my usual activities"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.209
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.255
      }]
    }]
  },
  {
    "code" : "PD",
    "display" : "SCHMERZEN / KÖRPERLICHEN BESCHWERDEN",
    "designation" : [{
      "language" : "en",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "PAIN / DISCOMFORT"
    }],
    "concept" : [{
      "code" : "PD-1",
      "display" : "Ich habe keine Schmerzen oder Beschwerden",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have no pain or discomfort"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0
      }]
    },
    {
      "code" : "PD-2",
      "display" : "Ich habe leichte Schmerzen oder Beschwerden",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have slight pain or discomfort"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.057
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.06
      }]
    },
    {
      "code" : "PD-3",
      "display" : "Ich habe mäßige Schmerzen oder Beschwerden",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have moderate pain or discomfort"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.109
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.098
      }]
    },
    {
      "code" : "PD-4",
      "display" : "Ich habe starke Schmerzen oder Beschwerden",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have severe pain or discomfort"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.404
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.318
      }]
    },
    {
      "code" : "PD-5",
      "display" : "Ich habe extreme Schmerzen oder Beschwerden",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I have extreme pain or discomfort"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.612
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.414
      }]
    }]
  },
  {
    "code" : "AD",
    "display" : "ANGST / NIEDERGESCHLAGENHEIT",
    "designation" : [{
      "language" : "en",
      "use" : {
        "system" : "http://snomed.info/sct",
        "code" : "900000000000013009",
        "display" : "Synonym"
      },
      "value" : "ANXIETY / DEPRESSION"
    }],
    "concept" : [{
      "code" : "AD-1",
      "display" : "Ich bin nicht ängstlich oder deprimiert",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I am not anxious or depressed"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0
      }]
    },
    {
      "code" : "AD-2",
      "display" : "Ich bin ein wenig ängstlich oder deprimiert",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I am slightly anxious or depressed"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.03
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.057
      }]
    },
    {
      "code" : "AD-3",
      "display" : "Ich bin mäßig ängstlich oder deprimiert",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I am moderately anxious or depressed"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.082
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.123
      }]
    },
    {
      "code" : "AD-4",
      "display" : "Ich bin sehr ängstlich oder deprimiert",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I am severely anxious or depressed"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.244
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.299
      }]
    },
    {
      "code" : "AD-5",
      "display" : "Ich bin extrem ängstlich oder deprimiert",
      "designation" : [{
        "language" : "en-US",
        "use" : {
          "system" : "http://snomed.info/sct",
          "code" : "900000000000013009",
          "display" : "Synonym"
        },
        "value" : "I am extremely anxious or depressed"
      }],
      "property" : [{
        "code" : "eq-5d-vs-coefficient-de-de",
        "valueDecimal" : 0.356
      },
      {
        "code" : "eq-5d-vs-coefficient-en-us",
        "valueDecimal" : 0.321
      }]
    }]
  },
  {
    "code" : "1",
    "display" : "Level 1",
    "designation" : [{
      "language" : "de",
      "value" : "Ich bin nicht ängstlich oder deprimiert"
    },
    {
      "language" : "de",
      "value" : "Ich habe keine Probleme herumzugehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe keine Probleme, meinen alltäglichen Tätigkeiten nachzugehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe keine Probleme, mich selbst zu waschen oder anzuziehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe keine Schmerzen oder Beschwerden"
    },
    {
      "language" : "en",
      "value" : "I am not anxious or depressed"
    },
    {
      "language" : "en",
      "value" : "I have no pain or discomfort"
    },
    {
      "language" : "en",
      "value" : "I have no problems doing my usual activities"
    },
    {
      "language" : "en",
      "value" : "I have no problems in walking about"
    },
    {
      "language" : "en",
      "value" : "I have no problems washing or dressing myself"
    }]
  },
  {
    "code" : "2",
    "display" : "Level 2",
    "designation" : [{
      "language" : "de",
      "value" : "Ich bin ein wenig ängstlich oder deprimiert"
    },
    {
      "language" : "de",
      "value" : "Ich habe leichte Probleme herumzugehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe leichte Probleme, meinen alltäglichen Tätigkeiten nachzugehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe leichte Probleme, mich selbst zu waschen oder anzuziehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe leichte Schmerzen oder Beschwerden"
    },
    {
      "language" : "en",
      "value" : "I am slightly anxious or depressed"
    },
    {
      "language" : "en",
      "value" : "I have slight pain or discomfort"
    },
    {
      "language" : "en",
      "value" : "I have slight problems doing my usual activities"
    },
    {
      "language" : "en",
      "value" : "I have slight problems in walking about"
    },
    {
      "language" : "en",
      "value" : "I have slight problems washing or dressing myself"
    }]
  },
  {
    "code" : "3",
    "display" : "Level 3",
    "designation" : [{
      "language" : "de",
      "value" : "Ich bin mäßig ängstlich oder deprimiert"
    },
    {
      "language" : "de",
      "value" : "Ich habe mäßige Probleme herumzugehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe mäßige Probleme, meinen alltäglichen Tätigkeiten nachzugehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe mäßige Probleme, mich selbst zu waschen oder anzuziehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe mäßige Schmerzen oder Beschwerden"
    },
    {
      "language" : "en",
      "value" : "I am moderately anxious or depressed"
    },
    {
      "language" : "en",
      "value" : "I have moderate pain or discomfort"
    },
    {
      "language" : "en",
      "value" : "I have moderate problems doing my usual activities"
    },
    {
      "language" : "en",
      "value" : "I have moderate problems in walking about"
    },
    {
      "language" : "en",
      "value" : "I have moderate problems washing or dressing myself"
    }]
  },
  {
    "code" : "4",
    "display" : "Level 4",
    "designation" : [{
      "language" : "de",
      "value" : "Ich bin sehr ängstlich oder deprimiert"
    },
    {
      "language" : "de",
      "value" : "Ich habe große Probleme herumzugehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe große Probleme, meinen alltäglichen Tätigkeiten nachzugehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe große Probleme, mich selbst zu waschen oder anzuziehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe starke Schmerzen oder Beschwerden"
    },
    {
      "language" : "en",
      "value" : "I am severely anxious or depressed"
    },
    {
      "language" : "en",
      "value" : "I have severe pain or discomfort"
    },
    {
      "language" : "en",
      "value" : "I have severe problems doing my usual activities"
    },
    {
      "language" : "en",
      "value" : "I have severe problems in walking about"
    },
    {
      "language" : "en",
      "value" : "I have severe problems washing or dressing myself"
    }]
  },
  {
    "code" : "5",
    "display" : "Level 5",
    "designation" : [{
      "language" : "de",
      "value" : "Ich bin extrem ängstlich oder deprimiert"
    },
    {
      "language" : "de",
      "value" : "Ich bin nicht in der Lage herumzugehen"
    },
    {
      "language" : "de",
      "value" : "Ich bin nicht in der Lage, meinen alltäglichen Tätigkeiten nachzugehen"
    },
    {
      "language" : "de",
      "value" : "Ich bin nicht in der Lage, mich selbst zu waschen oder anzuziehen"
    },
    {
      "language" : "de",
      "value" : "Ich habe extreme Schmerzen oder Beschwerden"
    },
    {
      "language" : "en",
      "value" : "I am extremely anxious or depressed"
    },
    {
      "language" : "en",
      "value" : "I am unable to do my usual activities"
    },
    {
      "language" : "en",
      "value" : "I am unable to walk about"
    },
    {
      "language" : "en",
      "value" : "I am unable to wash or dress myself"
    },
    {
      "language" : "en",
      "value" : "I have extreme pain or discomfort"
    }]
  },
  {
    "code" : "9",
    "display" : "Level 9",
    "designation" : [{
      "language" : "de",
      "value" : "Fehlender Wert"
    },
    {
      "language" : "en",
      "value" : "Missing value"
    }]
  }]
}

```
