# MII QST PRO EORTC QLQ-C30 Variant A - MII IG PRO v2027.0.0-ballot.rc3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII QST PRO EORTC QLQ-C30 Variant A**

## Questionnaire: EORTC QLQ-C30 Quality of Life Questionnaire Version 3.0 - Variant A (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/Questionnaire/mii-qst-pro-eortc-qlq-c30-variant-a | *Version*:2027.0.0-ballot.rc3 |
| Active as of 2026-09-08 | *Computable Name*: |
| **Copyright/Legal**: © Copyright 1995 EORTC Quality of Life Group. All rights reserved. Version 3.0 | |

 
EORTC QLQ-C30 Version 3.0 - Variant A: References standalone external ValueSets directly (no contained resources) 

*  [Tree view](#tabs-tree) 
*  [Sample Rendering](#tabs-sample) 
*  [Form Logic](#tabs-logic) 

### Test this Questionnaire

### Responses for this Questionnaire

There are currently no QuestionnaireResponse instances for this Questionnaire defined in this IG.



## Resource Content

```json
{
  "resourceType" : "Questionnaire",
  "id" : "mii-qst-pro-eortc-qlq-c30-variant-a",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-pr-pro-questionnaire|2027.0.0-ballot.rc3"]
  },
  "language" : "en",
  "extension" : [{
    "extension" : [{
      "url" : "displayable",
      "valueBoolean" : true
    },
    {
      "url" : "collectable",
      "valueBoolean" : true
    },
    {
      "url" : "calculatable",
      "valueBoolean" : true
    },
    {
      "url" : "extractable",
      "valueBoolean" : true
    },
    {
      "url" : "domainAligned",
      "valueBoolean" : false
    }],
    "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-ex-pro-questionnaire-capabilities"
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/Questionnaire/mii-qst-pro-eortc-qlq-c30-variant-a",
  "version" : "2027.0.0-ballot.rc3",
  "title" : "EORTC QLQ-C30 Quality of Life Questionnaire Version 3.0 - Variant A",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-09-08T07:03:30+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "EORTC QLQ-C30 Version 3.0 - Variant A: References standalone external ValueSets directly (no contained resources)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "© Copyright 1995 EORTC Quality of Life Group. All rights reserved. Version 3.0",
  "code" : [{
    "system" : "http://snomed.info/sct",
    "code" : "273446001",
    "display" : "European Organisation for Research and Treatment of Cancer - Quality of Life questionnaire (assessment scale)"
  },
  {
    "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-questionnaire-catalogue",
    "code" : "eortc-qlq-c30",
    "display" : "EORTC QLQ-C30 Quality of Life Questionnaire"
  }],
  "item" : [{
    "linkId" : "QLQ-C30.Introduction",
    "text" : "We are interested in some things about you and your health. Please answer all of the questions yourself by circling the number that best applies to you. There are no 'right' or 'wrong' answers. The information that you provide will remain strictly confidential.",
    "type" : "display"
  },
  {
    "linkId" : "QLQ-C30.Section1",
    "text" : "During the past week:",
    "type" : "display"
  },
  {
    "linkId" : "qlq-c30-q01",
    "prefix" : "1",
    "text" : "Do you have any trouble doing strenuous activities, like carrying a heavy shopping bag or a suitcase?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q02",
    "prefix" : "2",
    "text" : "Do you have any trouble taking a long walk?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q03",
    "prefix" : "3",
    "text" : "Do you have any trouble taking a short walk outside of the house?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q04",
    "prefix" : "4",
    "text" : "Do you need to stay in bed or a chair during the day?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q05",
    "prefix" : "5",
    "text" : "Do you need help with eating, dressing, washing yourself or using the toilet?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q06",
    "prefix" : "6",
    "text" : "Were you limited in doing either your work or other daily activities?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q07",
    "prefix" : "7",
    "text" : "Were you limited in pursuing your hobbies or other leisure time activities?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q08",
    "prefix" : "8",
    "text" : "Were you short of breath?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q09",
    "prefix" : "9",
    "text" : "Have you had pain?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q10",
    "prefix" : "10",
    "text" : "Did you need to rest?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q11",
    "prefix" : "11",
    "text" : "Have you had trouble sleeping?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q12",
    "prefix" : "12",
    "text" : "Have you felt weak?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q13",
    "prefix" : "13",
    "text" : "Have you lacked appetite?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q14",
    "prefix" : "14",
    "text" : "Have you felt nauseated?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q15",
    "prefix" : "15",
    "text" : "Have you vomited?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q16",
    "prefix" : "16",
    "text" : "Have you been constipated?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q17",
    "prefix" : "17",
    "text" : "Have you had diarrhea?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q18",
    "prefix" : "18",
    "text" : "Were you tired?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q19",
    "prefix" : "19",
    "text" : "Did pain interfere with your daily activities?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q20",
    "prefix" : "20",
    "text" : "Have you had difficulty in concentrating on things, like reading a newspaper or watching television?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q21",
    "prefix" : "21",
    "text" : "Did you feel tense?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q22",
    "prefix" : "22",
    "text" : "Did you worry?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q23",
    "prefix" : "23",
    "text" : "Did you feel irritable?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q24",
    "prefix" : "24",
    "text" : "Did you feel depressed?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q25",
    "prefix" : "25",
    "text" : "Have you had difficulty remembering things?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q26",
    "prefix" : "26",
    "text" : "Has your physical condition or medical treatment interfered with your family life?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q27",
    "prefix" : "27",
    "text" : "Has your physical condition or medical treatment interfered with your social activities?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "qlq-c30-q28",
    "prefix" : "28",
    "text" : "Has your physical condition or medical treatment caused you financial difficulties?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-4pt"
  },
  {
    "linkId" : "QLQ-C30.Section2",
    "text" : "For the following questions please circle the number between 1 and 7 that best applies to you",
    "type" : "display"
  },
  {
    "linkId" : "qlq-c30-q29",
    "prefix" : "29",
    "text" : "How would you rate your overall health during the past week?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-7pt"
  },
  {
    "linkId" : "qlq-c30-q30",
    "prefix" : "30",
    "text" : "How would you rate your overall quality of life during the past week?",
    "type" : "choice",
    "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-eortc-qlq-c30-scale-7pt"
  },
  {
    "linkId" : "QLQ-C30.Scores",
    "text" : "Calculated Scores (0-100 scale)",
    "type" : "group",
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "(1 - (((%resource.item.where(linkId.matches('^qlq-c30-q0[1-5]$')).answer.value.ordinal().sum()) / 5) - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-pf",
      "text" : "Physical Functioning Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "(1 - (((%resource.item.where(linkId='qlq-c30-q06' or linkId='qlq-c30-q07').answer.value.ordinal().sum()) / 2) - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-rf",
      "text" : "Role Functioning Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "(1 - (((%resource.item.where(linkId.matches('^qlq-c30-q2[1-4]$')).answer.value.ordinal().sum()) / 4) - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-ef",
      "text" : "Emotional Functioning Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "(1 - (((%resource.item.where(linkId='qlq-c30-q20' or linkId='qlq-c30-q25').answer.value.ordinal().sum()) / 2) - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-cf",
      "text" : "Cognitive Functioning Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "(1 - (((%resource.item.where(linkId='qlq-c30-q26' or linkId='qlq-c30-q27').answer.value.ordinal().sum()) / 2) - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-sf",
      "text" : "Social Functioning Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "(((%resource.item.where(linkId='qlq-c30-q10' or linkId='qlq-c30-q12' or linkId='qlq-c30-q18').answer.value.ordinal().sum()) / 3) - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-fa",
      "text" : "Fatigue Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "(((%resource.item.where(linkId='qlq-c30-q14' or linkId='qlq-c30-q15').answer.value.ordinal().sum()) / 2) - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-nv",
      "text" : "Nausea and Vomiting Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "(((%resource.item.where(linkId='qlq-c30-q09' or linkId='qlq-c30-q19').answer.value.ordinal().sum()) / 2) - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-pa",
      "text" : "Pain Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "((%resource.item.where(linkId='qlq-c30-q08').answer.value.ordinal() - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-dy",
      "text" : "Dyspnoea Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "((%resource.item.where(linkId='qlq-c30-q11').answer.value.ordinal() - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-sl",
      "text" : "Insomnia Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "((%resource.item.where(linkId='qlq-c30-q13').answer.value.ordinal() - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-ap",
      "text" : "Appetite Loss Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "((%resource.item.where(linkId='qlq-c30-q16').answer.value.ordinal() - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-co",
      "text" : "Constipation Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "((%resource.item.where(linkId='qlq-c30-q17').answer.value.ordinal() - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-di",
      "text" : "Diarrhoea Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "((%resource.item.where(linkId='qlq-c30-q28').answer.value.ordinal() - 1) / 3) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-fi",
      "text" : "Financial Difficulties Score",
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "(((%resource.item.where(linkId='qlq-c30-q29' or linkId='qlq-c30-q30').answer.value.ordinal().sum()) / 2) - 1) / 6) * 100"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "score-ql",
      "text" : "Global Health Status / Quality of Life Score",
      "type" : "decimal",
      "readOnly" : true
    }]
  }]
}

```
