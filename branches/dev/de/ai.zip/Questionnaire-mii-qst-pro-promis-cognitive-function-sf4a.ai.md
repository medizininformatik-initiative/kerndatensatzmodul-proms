# MII QST PRO PROMIS Cognitive Function SF 4a - MII IG PRO v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII QST PRO PROMIS Cognitive Function SF 4a**

## Questionnaire: MII QST PRO PROMIS Cognitive Function SF 4a (Experimentell) 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/Questionnaire/mii-qst-pro-promis-cognitive-function-sf4a | *Version*:2027.0.0-ballot.1 |
| Active Stand: 2026-11-05 | *Maschinenlesbarer Name*: |
| **Verwendung**: PROMIS (Patient-Reported Outcomes Measurement Information System) (https://www.healthmeasures.net/explore-measurement-systems/promis), PROMIS National Center Deutschland (CPCOR Charité) — Curator of the official German translations provided by PCOR-MII (https://cpcor.charite.de/promis_national_center_deutschland) | |
| **Copyright/Rechtliches**: The FHIR Questionnaire resource (linkIds, extensions, score calculation logic, observation extraction definitions) is part of the MII PRO Module and is licensed under CC-BY 4.0.The PROMIS items contained herein (item text, response options, scoring algorithms, IRT parameters) are © 2008–2024 PROMIS Health Organization and PROMIS Cooperative Group. PROMIS® is a registered trademark. See https://www.healthmeasures.net for the upstream license.The official German translations are provided by PCOR-MII (Patient-Centered Outcomes Research within the Medizininformatik-Initiative) and curated by the PROMIS National Center Germany (CPCOR, Charité – Universitätsmedizin Berlin; head: Felix Fischer).Institutional use outside the PCOR-MII / MII context requires a usage request to CPCOR: https://cpcor.charite.de/promis_national_center_deutschland/nutzungsanfragenLOINC® codes are © Regenstrief Institute, Inc. and used under the LOINC license: https://loinc.org/license/ | |

 
PROMIS Cognitive Function Short Form 4a - Assessment of cognitive abilities and concerns 

*  [Baumansicht](#tabs-tree) 
*  [Beispielanzeige](#tabs-sample) 
*  [Formularlogik](#tabs-logic) 

### Diesen Fragebogen testen

### Antworten zu diesem Fragebogen

Es sind derzeit keine QuestionnaireResponse-Instanzen für diesen Fragebogen in diesem IG definiert.



## Resource Content

```json
{
  "resourceType" : "Questionnaire",
  "id" : "mii-qst-pro-promis-cognitive-function-sf4a",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-pr-pro-questionnaire|2027.0.0-ballot.1"]
  },
  "language" : "en",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "natural",
      "display" : "Natural"
    }
  },
  {
    "extension" : [{
      "url" : "displayable",
      "valueBoolean" : true
    },
    {
      "url" : "collectable",
      "valueBoolean" : true
    },
    {
      "url" : "calculatable",
      "valueBoolean" : true
    },
    {
      "url" : "extractable",
      "valueBoolean" : true
    }],
    "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-ex-pro-questionnaire-capabilities"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/variable",
    "valueExpression" : {
      "name" : "cognitiveRawScore",
      "language" : "text/fhirpath",
      "expression" : "%resource.item.item.where(linkId.matches('^promis-cognition-(pc2r|pc35r|pc36r|pc42r)$')).answer.value.weight().sum()"
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/Questionnaire/mii-qst-pro-promis-cognitive-function-sf4a",
  "version" : "2027.0.0-ballot.1",
  "title" : "MII QST PRO PROMIS Cognitive Function SF 4a",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-11-05T04:04:59+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "PROMIS Cognitive Function Short Form 4a - Assessment of cognitive abilities and concerns",
  "useContext" : [{
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus"
    },
    "valueReference" : {
      "display" : "PROMIS (Patient-Reported Outcomes Measurement Information System) (https://www.healthmeasures.net/explore-measurement-systems/promis)"
    }
  },
  {
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus"
    },
    "valueReference" : {
      "display" : "PROMIS National Center Deutschland (CPCOR Charité) — Curator of the official German translations provided by PCOR-MII (https://cpcor.charite.de/promis_national_center_deutschland)"
    }
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "The FHIR Questionnaire resource (linkIds, extensions, score calculation logic, observation extraction definitions) is part of the MII PRO Module and is licensed under CC-BY 4.0.\n\nThe PROMIS items contained herein (item text, response options, scoring algorithms, IRT parameters) are © 2008–2024 PROMIS Health Organization and PROMIS Cooperative Group. PROMIS® is a registered trademark. See https://www.healthmeasures.net for the upstream license.\n\nThe official German translations are provided by PCOR-MII (Patient-Centered Outcomes Research within the Medizininformatik-Initiative) and curated by the PROMIS National Center Germany (CPCOR, Charité – Universitätsmedizin Berlin; head: Felix Fischer).\n\nInstitutional use outside the PCOR-MII / MII context requires a usage request to CPCOR: https://cpcor.charite.de/promis_national_center_deutschland/nutzungsanfragen\n\nLOINC® codes are © Regenstrief Institute, Inc. and used under the LOINC license: https://loinc.org/license/",
  "code" : [{
    "system" : "http://loinc.org",
    "code" : "81525-8",
    "display" : "PROMIS short form - cognitive function - abilities subset 4a - version 2.0"
  },
  {
    "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-questionnaire-catalogue",
    "code" : "promis-cognitive-function-sf4a",
    "display" : "PROMIS Cognitive Function Abilities 4a Short Form Questionnaire"
  }],
  "item" : [{
    "linkId" : "PROMIS-CognitiveFunction-SF4a",
    "text" : "PROMIS Cognitive Function SF 4a",
    "_text" : {
      "extension" : [{
        "extension" : [{
          "url" : "lang",
          "valueCode" : "de"
        },
        {
          "url" : "content",
          "valueString" : "PROMIS Kognitive Funktion SF 4a"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/translation"
      }]
    },
    "type" : "group",
    "item" : [{
      "linkId" : "PROMIS-CognitiveFunction-SF4a.Instructions",
      "text" : "In the past 7 days",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "In den letzten 7 Tagen:"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "display"
    },
    {
      "linkId" : "promis-cognition-pc2r",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "81461-6",
        "display" : "My thinking has been slow in past 7 days [PROMIS]"
      }],
      "text" : "My thinking has been slow",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich war langsam beim Denken"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "required" : true,
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten (einmal)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal (zwei- oder dreimal)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10044-8",
          "display" : "Often",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Oft (ungefähr einmal täglich)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr oft (mehrmals täglich)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-cognition-pc35r",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "81478-0",
        "display" : "It has seemed like my brain was not working as well as usual in past 7 days [PROMIS]"
      }],
      "text" : "It has seemed like my brain was not working as well as usual",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Es kam mir so vor, als ob mein Gehirn nicht so gut wie sonst funktionierte"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "required" : true,
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten (einmal)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal (zwei- oder dreimal)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10044-8",
          "display" : "Often",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Oft (ungefähr einmal täglich)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr oft (mehrmals täglich)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-cognition-pc36r",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "81479-8",
        "display" : "I have had to work harder than usual to keep track of what I was doing in past 7 days [PROMIS]"
      }],
      "text" : "I have had to work harder than usual to keep track of what I was doing",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich musste mir größere Mühe geben als sonst, um den Überblick über das zu bewahren, womit ich gerade beschäftigt war"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "required" : true,
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten (einmal)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal (zwei- oder dreimal)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10044-8",
          "display" : "Often",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Oft (ungefähr einmal täglich)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr oft (mehrmals täglich)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-cognition-pc42r",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "81485-5",
        "display" : "I have had trouble shifting back and forth between different activities that require thinking in past 7 days [PROMIS]"
      }],
      "text" : "I have had trouble shifting back and forth between different activities that require thinking",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich hatte Schwierigkeiten, zwischen verschiedenen Aktivitäten, die ein gewisses Nachdenken erfordern, hin und her zu wechseln"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "required" : true,
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten (einmal)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal (zwei- oder dreimal)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10044-8",
          "display" : "Often",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Oft (ungefähr einmal täglich)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr oft (mehrmals täglich)"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%cognitiveRawScore"
        }
      }],
      "linkId" : "promis-cognition-sf4a-raw-score",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "81533-2",
        "display" : "PROMIS short form - cognitive function 4a - version 2.0 raw score"
      }],
      "text" : "PROMIS Cognitive Function SF 4a Raw Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS Kognitive Funktion SF 4a Rohwert"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "quantity",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%cognitiveRawScore=4, 24.99, iif(%cognitiveRawScore=5, 28.95, iif(%cognitiveRawScore=6, 31.07, iif(%cognitiveRawScore=7, 32.94, iif(%cognitiveRawScore=8, 34.61, iif(%cognitiveRawScore=9, 36.17, iif(%cognitiveRawScore=10, 37.69, iif(%cognitiveRawScore=11, 39.19, iif(%cognitiveRawScore=12, 40.70, iif(%cognitiveRawScore=13, 42.25, iif(%cognitiveRawScore=14, 43.86, iif(%cognitiveRawScore=15, 45.54, iif(%cognitiveRawScore=16, 47.33, iif(%cognitiveRawScore=17, 49.28, iif(%cognitiveRawScore=18, 51.62, iif(%cognitiveRawScore=19, 54.58, iif(%cognitiveRawScore=20, 61.13, 50.0)))))))))))))))))"
        }
      }],
      "linkId" : "promis-cognition-sf4a-t-score",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "81538-1",
        "display" : "PROMIS cognitive function - version 2.0 T-score"
      }],
      "text" : "PROMIS Cognitive Function SF 4a T-Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS Kognitive Funktion SF 4a T-Score"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "quantity",
      "readOnly" : true
    }]
  }]
}

```
