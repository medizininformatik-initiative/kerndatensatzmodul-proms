# MII CS PRO Score Catalogue - MII IG PRO v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII CS PRO Score Catalogue**

## CodeSystem: MII CS PRO Score Catalogue 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-score-catalogue | *Version*:2027.0.0-ballot |
| Active Stand: 2026-09-11 | *Maschinenlesbarer Name*:MII_CS_PRO_Score_Catalogue |

 
MII CS PRO Score Catalogue for PRO Scores used in the MII PROMs Module 

Dieses CodeSystem wird in der Definition der folgenden ValueSets referenziert:

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "mii-cs-pro-score-catalogue",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-score-catalogue",
  "version" : "2027.0.0-ballot",
  "name" : "MII_CS_PRO_Score_Catalogue",
  "title" : "MII CS PRO Score Catalogue",
  "status" : "active",
  "date" : "2026-09-11T14:12:49+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "MII CS PRO Score Catalogue for PRO Scores used in the MII PROMs Module",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "content" : "complete",
  "count" : 47,
  "concept" : [{
    "code" : "euroqol-eq5d5l-index",
    "display" : "EuroQol EQ-5D-5L Index Score"
  },
  {
    "code" : "euroqol-eq5d5l-vas",
    "display" : "EuroQol EQ-5D-5L Visual Analog Scale (VAS) Score"
  },
  {
    "code" : "euroqol-eq5d5l-profile",
    "display" : "EuroQol EQ-5D-5L Profile"
  },
  {
    "code" : "phq-phq9-total",
    "display" : "PHQ-9 Total Score"
  },
  {
    "code" : "phq-phq15-total",
    "display" : "PHQ-15 Total Score"
  },
  {
    "code" : "bdi-bdi2-total",
    "display" : "Beck Depression Inventory II (BDI-II) Total Score"
  },
  {
    "code" : "promis-29-physical-function-tscore",
    "display" : "PROMIS-29 Physical Function T-Score"
  },
  {
    "code" : "promis-29-anxiety-tscore",
    "display" : "PROMIS-29 Anxiety T-Score"
  },
  {
    "code" : "promis-29-depression-tscore",
    "display" : "PROMIS-29 Depression T-Score"
  },
  {
    "code" : "promis-29-fatigue-tscore",
    "display" : "PROMIS-29 Fatigue T-Score"
  },
  {
    "code" : "promis-29-sleep-disturbance-tscore",
    "display" : "PROMIS-29 Sleep Disturbance T-Score"
  },
  {
    "code" : "promis-29-social-function-tscore",
    "display" : "PROMIS-29 Ability to Participate in Social Roles and Activities T-Score"
  },
  {
    "code" : "promis-29-pain-interference-tscore",
    "display" : "PROMIS-29 Pain Interference T-Score"
  },
  {
    "code" : "promis-29-pain-intensity",
    "display" : "PROMIS-29 Pain Intensity (0-10 Numeric Rating)"
  },
  {
    "code" : "promis-cognitive-function-sf4a-raw",
    "display" : "PROMIS Cognitive Function Abilities 4a Raw Score"
  },
  {
    "code" : "promis-cognitive-function-sf4a-tscore",
    "display" : "PROMIS Cognitive Function Abilities 4a T-Score"
  },
  {
    "code" : "promis-depression",
    "display" : "PROMIS Depression Score"
  },
  {
    "code" : "eortc-qlq-c30-pf",
    "display" : "EORTC QLQ-C30 Physical Functioning Score"
  },
  {
    "code" : "eortc-qlq-c30-rf",
    "display" : "EORTC QLQ-C30 Role Functioning Score"
  },
  {
    "code" : "eortc-qlq-c30-ef",
    "display" : "EORTC QLQ-C30 Emotional Functioning Score"
  },
  {
    "code" : "eortc-qlq-c30-cf",
    "display" : "EORTC QLQ-C30 Cognitive Functioning Score"
  },
  {
    "code" : "eortc-qlq-c30-sf",
    "display" : "EORTC QLQ-C30 Social Functioning Score"
  },
  {
    "code" : "eortc-qlq-c30-fa",
    "display" : "EORTC QLQ-C30 Fatigue Score"
  },
  {
    "code" : "eortc-qlq-c30-nv",
    "display" : "EORTC QLQ-C30 Nausea and Vomiting Score"
  },
  {
    "code" : "eortc-qlq-c30-pa",
    "display" : "EORTC QLQ-C30 Pain Score"
  },
  {
    "code" : "eortc-qlq-c30-dy",
    "display" : "EORTC QLQ-C30 Dyspnoea Score"
  },
  {
    "code" : "eortc-qlq-c30-sl",
    "display" : "EORTC QLQ-C30 Insomnia Score"
  },
  {
    "code" : "eortc-qlq-c30-ap",
    "display" : "EORTC QLQ-C30 Appetite Loss Score"
  },
  {
    "code" : "eortc-qlq-c30-co",
    "display" : "EORTC QLQ-C30 Constipation Score"
  },
  {
    "code" : "eortc-qlq-c30-di",
    "display" : "EORTC QLQ-C30 Diarrhoea Score"
  },
  {
    "code" : "eortc-qlq-c30-fi",
    "display" : "EORTC QLQ-C30 Financial Difficulties Score"
  },
  {
    "code" : "eortc-qlq-c30-ql",
    "display" : "EORTC QLQ-C30 Global Health Status / Quality of Life Score"
  },
  {
    "code" : "dass21-depression-raw",
    "display" : "DASS-21 Depression Raw Score"
  },
  {
    "code" : "dass21-anxiety-raw",
    "display" : "DASS-21 Anxiety Raw Score"
  },
  {
    "code" : "dass21-stress-raw",
    "display" : "DASS-21 Stress Raw Score"
  },
  {
    "code" : "dass21-depression-equiv",
    "display" : "DASS-21 Depression DASS-42 Equivalent Score"
  },
  {
    "code" : "dass21-anxiety-equiv",
    "display" : "DASS-21 Anxiety DASS-42 Equivalent Score"
  },
  {
    "code" : "dass21-stress-equiv",
    "display" : "DASS-21 Stress DASS-42 Equivalent Score"
  },
  {
    "code" : "whodas12-simple-sum",
    "display" : "WHODAS 2.0 12-Item Simple Sum Score (0-48)"
  },
  {
    "code" : "proctcae-composite-grade",
    "display" : "PRO-CTCAE Composite Grade (per Adverse Event)"
  },
  {
    "code" : "proctcae-acs",
    "display" : "PRO-CTCAE Average Composite Score (ACS)"
  },
  {
    "code" : "scoff-total",
    "display" : "SCOFF Total Score (0-5)"
  },
  {
    "code" : "wi-7-total",
    "display" : "Whiteley-7 Total Score (0-7)"
  },
  {
    "code" : "pc-ptsd-total",
    "display" : "PC-PTSD Total Score (0-4)"
  },
  {
    "code" : "ssd-12-total",
    "display" : "SSD-12 Total Score (0-48)"
  },
  {
    "code" : "isr-z-mean",
    "display" : "ISR-Z Skalenwert (Mittelwert 0-4)"
  },
  {
    "code" : "phq-gad7-total",
    "display" : "GAD-7 Total Score (0-21)"
  }]
}

```
