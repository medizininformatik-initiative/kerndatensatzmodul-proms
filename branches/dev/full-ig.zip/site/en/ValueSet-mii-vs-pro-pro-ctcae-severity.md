# MII VS PRO PRO-CTCAE Severity Scale - MII IG PRO v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII VS PRO PRO-CTCAE Severity Scale**

## ValueSet: MII VS PRO PRO-CTCAE Severity Scale (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity | *Version*:2027.0.0-ballot.1 |
| Active as of 2026-10-19 | *Computable Name*:MII_VS_PRO_PRO_CTCAE_Severity |

 
5-point severity response scale for PRO-CTCAE items (0=None, 4=Very severe) 

 **References** 

* [PRO-CTCAE Deutsches Brustkrebszentrum-Subset (21 Symptome)](Questionnaire-mii-qst-pro-pro-ctcae-breast-de.md)
* [MII QST PRO PRO-CTCAE Onkologisches Basisscreening](Questionnaire-mii-qst-pro-pro-ctcae-onkologisches-basisscreening.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-pro-pro-ctcae-severity",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity",
  "version" : "2027.0.0-ballot.1",
  "name" : "MII_VS_PRO_PRO_CTCAE_Severity",
  "title" : "MII VS PRO PRO-CTCAE Severity Scale",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-10-19T03:43:18+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "5-point severity response scale for PRO-CTCAE items (0=None, 4=Very severe)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-pro-ctcae",
      "concept" : [{
        "code" : "proctcae-severity-0"
      },
      {
        "code" : "proctcae-severity-1"
      },
      {
        "code" : "proctcae-severity-2"
      },
      {
        "code" : "proctcae-severity-3"
      },
      {
        "code" : "proctcae-severity-4"
      }]
    }]
  }
}

```
