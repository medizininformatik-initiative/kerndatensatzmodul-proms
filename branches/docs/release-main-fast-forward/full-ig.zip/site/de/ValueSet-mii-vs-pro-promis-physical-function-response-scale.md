# MII VS PRO PROMIS Physical Function Response Scale - MII IG PRO v2027.0.0-ballot.2

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII VS PRO PROMIS Physical Function Response Scale**

## ValueSet: MII VS PRO PROMIS Physical Function Response Scale (Experimentell) 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-promis-physical-function-response-scale | *Version*:2027.0.0-ballot.2 |
| Active Stand: 2026-11-17 | *Maschinenlesbarer Name*:MII_VS_PRO_PROMIS_Physical_Function_Response_Scale |

 
PROMIS Physical Function response scale based on LOINC LL1022-4 

 **References** 

* [MII QST PRO PROMIS-16 (Adults)](Questionnaire-mii-qst-pro-promis-16.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-pro-promis-physical-function-response-scale",
  "language" : "en",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-promis-physical-function-response-scale",
  "version" : "2027.0.0-ballot.2",
  "name" : "MII_VS_PRO_PROMIS_Physical_Function_Response_Scale",
  "title" : "MII VS PRO PROMIS Physical Function Response Scale",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-11-17T12:24:49+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "PROMIS Physical Function response scale based on LOINC LL1022-4",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "LA13921-4",
        "display" : "Without any difficulty",
        "designation" : [{
          "language" : "de",
          "value" : "Ohne jede Schwierigkeiten"
        }]
      },
      {
        "code" : "LA13918-0",
        "display" : "With a little difficulty",
        "designation" : [{
          "language" : "de",
          "value" : "Mit geringen Schwierigkeiten"
        }]
      },
      {
        "code" : "LA13920-6",
        "display" : "With some difficulty",
        "designation" : [{
          "language" : "de",
          "value" : "Mit einigen Schwierigkeiten"
        }]
      },
      {
        "code" : "LA13919-8",
        "display" : "With much difficulty",
        "designation" : [{
          "language" : "de",
          "value" : "Mit großen Schwierigkeiten"
        }]
      },
      {
        "code" : "LA13912-3",
        "display" : "Unable to do",
        "designation" : [{
          "language" : "de",
          "value" : "Kann ich gar nicht"
        }]
      }]
    }]
  }
}

```
