# References - MII IG PRO v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Guidance**](guidance.md)
* **References**

## References

### Research

* CPCOR: [https://cpcor.charite.de/](https://cpcor.charite.de/)
* H2O: [https://health-outcomes-observatory.eu/](https://health-outcomes-observatory.eu/de/homepage/)
* ICHOM: [https://www.ichom.org/](https://www.ichom.org/)
* PCORI: [https://www.pcori.org/](https://www.pcori.org/)

### Standardization

* EORTC: [https://www.eortc.org/](https://www.eortc.org/)
* EuroQol: [https://euroqol.org/](https://euroqol.org/)
* PROMIS International: [http://promis-international.org/](http://promis-international.org/)
* PROMIS Germany: [https://promis-germany.de/](https://promis-germany.de/)

