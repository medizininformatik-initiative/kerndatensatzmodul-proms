# MII CS PRO DASS-21 Response Scale and Item Codes - MII IG PRO v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII CS PRO DASS-21 Response Scale and Item Codes**

## CodeSystem: MII CS PRO DASS-21 Response Scale and Item Codes (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-dass-21 | *Version*:2027.0.0-ballot.1 |
| Active as of 2026-10-14 | *Computable Name*:MII_CS_PRO_DASS_21 |

 
CodeSystem for the Depression Anxiety Stress Scales - Short Form (DASS-21) with answer codes, item codes, and multilingual support (English primary, German translations from Nilges & Essau 2015) 

This Code system is referenced in the definition of the following value sets:

* [MII VS PRO DASS-21 Answer List](ValueSet-mii-vs-pro-dass-21-answer-list.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "mii-cs-pro-dass-21",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-dass-21",
  "version" : "2027.0.0-ballot.1",
  "name" : "MII_CS_PRO_DASS_21",
  "title" : "MII CS PRO DASS-21 Response Scale and Item Codes",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-10-14T07:28:35+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "CodeSystem for the Depression Anxiety Stress Scales - Short Form (DASS-21) with answer codes, item codes, and multilingual support (English primary, German translations from Nilges & Essau 2015)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 25,
  "concept" : [{
    "code" : "dass-dass21-answer-0",
    "display" : "Did not apply to me at all",
    "designation" : [{
      "language" : "de",
      "value" : "Traf gar nicht auf mich zu"
    }]
  },
  {
    "code" : "dass-dass21-answer-1",
    "display" : "Applied to me to some degree",
    "designation" : [{
      "language" : "de",
      "value" : "Traf bis zu einem gewissen Grad auf mich zu"
    }]
  },
  {
    "code" : "dass-dass21-answer-2",
    "display" : "Applied to me to a considerable degree",
    "designation" : [{
      "language" : "de",
      "value" : "Traf in beträchtlichem Maße auf mich zu"
    }]
  },
  {
    "code" : "dass-dass21-answer-3",
    "display" : "Applied to me very much",
    "designation" : [{
      "language" : "de",
      "value" : "Traf sehr stark auf mich zu"
    }]
  },
  {
    "code" : "dass-dass21-q01",
    "display" : "I found it hard to wind down",
    "designation" : [{
      "language" : "de",
      "value" : "Ich fand es schwer abzuschalten"
    }]
  },
  {
    "code" : "dass-dass21-q02",
    "display" : "I was aware of dryness of my mouth",
    "designation" : [{
      "language" : "de",
      "value" : "Ich bemerkte Mundtrockenheit"
    }]
  },
  {
    "code" : "dass-dass21-q03",
    "display" : "I couldn't seem to experience any positive feeling at all",
    "designation" : [{
      "language" : "de",
      "value" : "Ich konnte überhaupt keine positiven Gefühle mehr erleben"
    }]
  },
  {
    "code" : "dass-dass21-q04",
    "display" : "I experienced breathing difficulty",
    "designation" : [{
      "language" : "de",
      "value" : "Ich hatte Atemschwierigkeiten"
    }]
  },
  {
    "code" : "dass-dass21-q05",
    "display" : "I found it difficult to work up the initiative to do things",
    "designation" : [{
      "language" : "de",
      "value" : "Ich fand es schwierig, die Initiative zum Tun aufzubringen"
    }]
  },
  {
    "code" : "dass-dass21-q06",
    "display" : "I tended to over-react to situations",
    "designation" : [{
      "language" : "de",
      "value" : "Ich neigte dazu, auf Situationen überzureagieren"
    }]
  },
  {
    "code" : "dass-dass21-q07",
    "display" : "I experienced trembling (e.g., in the hands)",
    "designation" : [{
      "language" : "de",
      "value" : "Ich zitterte (z.B. an den Händen)"
    }]
  },
  {
    "code" : "dass-dass21-q08",
    "display" : "I felt that I was using a lot of nervous energy",
    "designation" : [{
      "language" : "de",
      "value" : "Ich merkte, dass ich viel nervöse Energie verbrauchte"
    }]
  },
  {
    "code" : "dass-dass21-q09",
    "display" : "I was worried about situations in which I might panic and make a fool of myself",
    "designation" : [{
      "language" : "de",
      "value" : "Ich machte mir Sorgen über Situationen, in denen ich in Panik geraten könnte"
    }]
  },
  {
    "code" : "dass-dass21-q10",
    "display" : "I felt that I had nothing to look forward to",
    "designation" : [{
      "language" : "de",
      "value" : "Ich hatte das Gefühl, dass ich nichts erwarten konnte"
    }]
  },
  {
    "code" : "dass-dass21-q11",
    "display" : "I found myself getting agitated",
    "designation" : [{
      "language" : "de",
      "value" : "Ich merkte, dass ich unruhig wurde"
    }]
  },
  {
    "code" : "dass-dass21-q12",
    "display" : "I found it difficult to relax",
    "designation" : [{
      "language" : "de",
      "value" : "Ich fand es schwierig, mich zu entspannen"
    }]
  },
  {
    "code" : "dass-dass21-q13",
    "display" : "I felt down-hearted and blue",
    "designation" : [{
      "language" : "de",
      "value" : "Ich fühlte mich niedergeschlagen und traurig"
    }]
  },
  {
    "code" : "dass-dass21-q14",
    "display" : "I was intolerant of anything that kept me from getting on with what I was doing",
    "designation" : [{
      "language" : "de",
      "value" : "Ich war ungeduldig, wenn ich aufgehalten wurde"
    }]
  },
  {
    "code" : "dass-dass21-q15",
    "display" : "I felt I was close to panic",
    "designation" : [{
      "language" : "de",
      "value" : "Ich fühlte mich einer Panik nahe"
    }]
  },
  {
    "code" : "dass-dass21-q16",
    "display" : "I was unable to become enthusiastic about anything",
    "designation" : [{
      "language" : "de",
      "value" : "Ich konnte mich für nichts begeistern"
    }]
  },
  {
    "code" : "dass-dass21-q17",
    "display" : "I felt I wasn't worth much as a person",
    "designation" : [{
      "language" : "de",
      "value" : "Ich hatte das Gefühl, nicht viel wert zu sein"
    }]
  },
  {
    "code" : "dass-dass21-q18",
    "display" : "I felt that I was rather touchy",
    "designation" : [{
      "language" : "de",
      "value" : "Ich merkte, dass ich ziemlich empfindlich war"
    }]
  },
  {
    "code" : "dass-dass21-q19",
    "display" : "I was aware of the action of my heart in the absence of physical exertion",
    "designation" : [{
      "language" : "de",
      "value" : "Ich nahm meinen Herzschlag wahr, ohne körperlich aktiv zu sein"
    }]
  },
  {
    "code" : "dass-dass21-q20",
    "display" : "I felt scared without any good reason",
    "designation" : [{
      "language" : "de",
      "value" : "Ich fürchtete mich ohne ersichtlichen Grund"
    }]
  },
  {
    "code" : "dass-dass21-q21",
    "display" : "I felt that life was meaningless",
    "designation" : [{
      "language" : "de",
      "value" : "Ich fand das Leben sinnlos"
    }]
  }]
}

```
