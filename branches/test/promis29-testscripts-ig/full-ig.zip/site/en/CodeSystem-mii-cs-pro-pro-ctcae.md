# MII CS PRO PRO-CTCAE Item Library - MII IG PRO v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII CS PRO PRO-CTCAE Item Library**

## CodeSystem: MII CS PRO PRO-CTCAE Item Library (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-pro-ctcae | *Version*:2027.0.0-ballot.1 |
| Active as of 2026-10-14 | *Computable Name*:MII_CS_PRO_PRO_CTCAE |
| **Copyright/Legal**: PRO-CTCAE is a product of the US National Cancer Institute (NCI). The PRO-CTCAE items, calculation algorithms, and item library are available free of charge for use in cancer clinical trials. | |

 
CodeSystem for the Patient-Reported Outcomes version of the Common Terminology Criteria for Adverse Events (PRO-CTCAE). Contains all 124 items across 78 adverse events with English primary text and German designations from the NCI-authorized translation. Item Library Version 1.0. 

This Code system is referenced in the definition of the following value sets:

* [MII VS PRO PRO-CTCAE Frequency Scale](ValueSet-mii-vs-pro-pro-ctcae-frequency.md)
* [MII VS PRO PRO-CTCAE Frequency Scale (Sexual Function)](ValueSet-mii-vs-pro-pro-ctcae-frequency-sexual.md)
* [MII VS PRO PRO-CTCAE Interference Scale](ValueSet-mii-vs-pro-pro-ctcae-interference.md)
* [MII VS PRO PRO-CTCAE Presence Scale](ValueSet-mii-vs-pro-pro-ctcae-presence.md)
* [MII VS PRO PRO-CTCAE Presence Scale (with Not Applicable)](ValueSet-mii-vs-pro-pro-ctcae-presence-na.md)
* [MII VS PRO PRO-CTCAE Presence Scale (Sexual Function)](ValueSet-mii-vs-pro-pro-ctcae-presence-sexual.md)
* [MII VS PRO PRO-CTCAE Severity Scale](ValueSet-mii-vs-pro-pro-ctcae-severity.md)
* [MII VS PRO PRO-CTCAE Severity Scale (Radiation)](ValueSet-mii-vs-pro-pro-ctcae-severity-radiation.md)
* [MII VS PRO PRO-CTCAE Severity Scale (Sexual Function)](ValueSet-mii-vs-pro-pro-ctcae-severity-sexual.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "mii-cs-pro-pro-ctcae",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-pro-ctcae",
  "version" : "2027.0.0-ballot.1",
  "name" : "MII_CS_PRO_PRO_CTCAE",
  "title" : "MII CS PRO PRO-CTCAE Item Library",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-10-14T07:51:24+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "CodeSystem for the Patient-Reported Outcomes version of the Common Terminology Criteria for Adverse Events (PRO-CTCAE). Contains all 124 items across 78 adverse events with English primary text and German designations from the NCI-authorized translation. Item Library Version 1.0.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "PRO-CTCAE is a product of the US National Cancer Institute (NCI). The PRO-CTCAE items, calculation algorithms, and item library are available free of charge for use in cancer clinical trials.",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 224,
  "property" : [{
    "code" : "attributes",
    "description" : "Which item attributes apply to this AE (frq, sev, int, presence)",
    "type" : "string"
  },
  {
    "code" : "rank",
    "description" : "Composite grading rank (1=frq, 2=sev, 3=int, 4=frq+sev, 5=frq+int, 6=sev+int, 7=frq+sev+int)",
    "type" : "integer"
  }],
  "concept" : [{
    "code" : "proctcae-frequency-0",
    "display" : "Never",
    "designation" : [{
      "language" : "de",
      "value" : "Nie"
    }]
  },
  {
    "code" : "proctcae-frequency-1",
    "display" : "Rarely",
    "designation" : [{
      "language" : "de",
      "value" : "Selten"
    }]
  },
  {
    "code" : "proctcae-frequency-2",
    "display" : "Occasionally",
    "designation" : [{
      "language" : "de",
      "value" : "Gelegentlich"
    }]
  },
  {
    "code" : "proctcae-frequency-3",
    "display" : "Frequently",
    "designation" : [{
      "language" : "de",
      "value" : "Häufig"
    }]
  },
  {
    "code" : "proctcae-frequency-4",
    "display" : "Almost constantly",
    "designation" : [{
      "language" : "de",
      "value" : "Fast immer"
    }]
  },
  {
    "code" : "proctcae-severity-0",
    "display" : "None",
    "designation" : [{
      "language" : "de",
      "value" : "Gar nicht"
    }]
  },
  {
    "code" : "proctcae-severity-1",
    "display" : "Mild",
    "designation" : [{
      "language" : "de",
      "value" : "Ein wenig"
    }]
  },
  {
    "code" : "proctcae-severity-2",
    "display" : "Moderate",
    "designation" : [{
      "language" : "de",
      "value" : "Mäßig"
    }]
  },
  {
    "code" : "proctcae-severity-3",
    "display" : "Severe",
    "designation" : [{
      "language" : "de",
      "value" : "Ziemlich"
    }]
  },
  {
    "code" : "proctcae-severity-4",
    "display" : "Very severe",
    "designation" : [{
      "language" : "de",
      "value" : "Sehr"
    }]
  },
  {
    "code" : "proctcae-interference-0",
    "display" : "Not at all",
    "designation" : [{
      "language" : "de",
      "value" : "Gar nicht"
    }]
  },
  {
    "code" : "proctcae-interference-1",
    "display" : "A little bit",
    "designation" : [{
      "language" : "de",
      "value" : "Ein wenig"
    }]
  },
  {
    "code" : "proctcae-interference-2",
    "display" : "Somewhat",
    "designation" : [{
      "language" : "de",
      "value" : "Mäßig"
    }]
  },
  {
    "code" : "proctcae-interference-3",
    "display" : "Quite a bit",
    "designation" : [{
      "language" : "de",
      "value" : "Ziemlich"
    }]
  },
  {
    "code" : "proctcae-interference-4",
    "display" : "Very much",
    "designation" : [{
      "language" : "de",
      "value" : "Sehr"
    }]
  },
  {
    "code" : "proctcae-presence-0",
    "display" : "No",
    "designation" : [{
      "language" : "de",
      "value" : "Nein"
    }]
  },
  {
    "code" : "proctcae-presence-1",
    "display" : "Yes",
    "designation" : [{
      "language" : "de",
      "value" : "Ja"
    }]
  },
  {
    "code" : "proctcae-optout-not-applicable",
    "display" : "Not applicable",
    "designation" : [{
      "language" : "de",
      "value" : "Trifft nicht auf mich zu"
    }]
  },
  {
    "code" : "proctcae-optout-not-sexually-active",
    "display" : "Not sexually active",
    "designation" : [{
      "language" : "de",
      "value" : "Nicht sexuell aktiv"
    }]
  },
  {
    "code" : "proctcae-optout-prefer-not-to-answer",
    "display" : "Prefer not to answer",
    "designation" : [{
      "language" : "de",
      "value" : "Möchte nicht antworten"
    }]
  },
  {
    "code" : "proctcae-ae-01",
    "display" : "Dry Mouth",
    "designation" : [{
      "language" : "de",
      "value" : "Mundtrockenheit"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-01a-sev",
    "display" : "Dry Mouth Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihre MUNDTROCKENHEIT im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-02",
    "display" : "Difficulty Swallowing",
    "designation" : [{
      "language" : "de",
      "value" : "Schwierigkeiten beim Schlucken"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-02a-sev",
    "display" : "Difficulty Swallowing Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre SCHWIERIGKEITEN BEIM SCHLUCKEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-03",
    "display" : "Mouth or Throat Sores",
    "designation" : [{
      "language" : "de",
      "value" : "Wunde oder offene Stellen in Mund oder Hals"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 6
    }]
  },
  {
    "code" : "proctcae-03a-sev",
    "display" : "Mouth or Throat Sores Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK hatten Sie WUNDE ODER OFFENE STELLEN IN MUND ODER HALS im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-03b-int",
    "display" : "Mouth or Throat Sores Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr haben WUNDE ODER OFFENE STELLEN IN MUND ODER HALS Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-04",
    "display" : "Cracking at Corners of Mouth",
    "designation" : [{
      "language" : "de",
      "value" : "Rissige Mundwinkel"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-04a-sev",
    "display" : "Cracking at Corners of Mouth Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK hatten Sie RISSIGE MUNDWINKEL im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-05",
    "display" : "Voice Quality Changes",
    "designation" : [{
      "language" : "de",
      "value" : "Veränderung der Stimme"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-05a-yn",
    "display" : "Voice Quality Changes Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie irgendeine VERÄNDERUNG DER STIMME?"
    }]
  },
  {
    "code" : "proctcae-ae-06",
    "display" : "Hoarseness",
    "designation" : [{
      "language" : "de",
      "value" : "Heiserkeit"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-06a-sev",
    "display" : "Hoarseness Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihre HEISERKEIT im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-07",
    "display" : "Taste Changes",
    "designation" : [{
      "language" : "de",
      "value" : "Geschmacksveränderungen beim Essen oder Trinken"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-07a-sev",
    "display" : "Taste Changes Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre GESCHMACKSVERÄNDERUNGEN BEIM ESSEN ODER TRINKEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-08",
    "display" : "Decreased Appetite",
    "designation" : [{
      "language" : "de",
      "value" : "Appetitmangel"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 6
    }]
  },
  {
    "code" : "proctcae-08a-sev",
    "display" : "Decreased Appetite Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihr APPETITMANGEL im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-08b-int",
    "display" : "Decreased Appetite Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr hat Ihr APPETITMANGEL Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-09",
    "display" : "Nausea",
    "designation" : [{
      "language" : "de",
      "value" : "Übelkeit"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 4
    }]
  },
  {
    "code" : "proctcae-09a-frq",
    "display" : "Nausea Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie ÜBELKEIT?"
    }]
  },
  {
    "code" : "proctcae-09b-sev",
    "display" : "Nausea Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihre ÜBELKEIT im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-10",
    "display" : "Vomiting",
    "designation" : [{
      "language" : "de",
      "value" : "Erbrechen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 4
    }]
  },
  {
    "code" : "proctcae-10a-frq",
    "display" : "Vomiting Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG mussten Sie ERBRECHEN?"
    }]
  },
  {
    "code" : "proctcae-10b-sev",
    "display" : "Vomiting Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihr ERBRECHEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-11",
    "display" : "Heartburn",
    "designation" : [{
      "language" : "de",
      "value" : "Sodbrennen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 4
    }]
  },
  {
    "code" : "proctcae-11a-frq",
    "display" : "Heartburn Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie SODBRENNEN?"
    }]
  },
  {
    "code" : "proctcae-11b-sev",
    "display" : "Heartburn Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihr SODBRENNEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-12",
    "display" : "Increased Flatulence",
    "designation" : [{
      "language" : "de",
      "value" : "Winde lassen (Flatulenz)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-12a-yn",
    "display" : "Increased Flatulence Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Mussten Sie HÄUFIGER WINDE LASSEN (FLATULENZ)?"
    }]
  },
  {
    "code" : "proctcae-ae-13",
    "display" : "Bloating",
    "designation" : [{
      "language" : "de",
      "value" : "Einen geblähten Bauch"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 4
    }]
  },
  {
    "code" : "proctcae-13a-frq",
    "display" : "Bloating Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie EINEN GEBLÄHTEN BAUCH?"
    }]
  },
  {
    "code" : "proctcae-13b-sev",
    "display" : "Bloating Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK GEBLÄHT war Ihr BAUCH im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-14",
    "display" : "Hiccups",
    "designation" : [{
      "language" : "de",
      "value" : "Schluckauf"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 4
    }]
  },
  {
    "code" : "proctcae-14a-frq",
    "display" : "Hiccups Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie SCHLUCKAUF?"
    }]
  },
  {
    "code" : "proctcae-14b-sev",
    "display" : "Hiccups Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihr SCHLUCKAUF im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-15",
    "display" : "Constipation",
    "designation" : [{
      "language" : "de",
      "value" : "Verstopfung"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-15a-sev",
    "display" : "Constipation Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihre VERSTOPFUNG im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-16",
    "display" : "Diarrhea",
    "designation" : [{
      "language" : "de",
      "value" : "Durchfall"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq"
    },
    {
      "code" : "rank",
      "valueInteger" : 1
    }]
  },
  {
    "code" : "proctcae-16a-frq",
    "display" : "Diarrhea Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie DURCHFALL?"
    }]
  },
  {
    "code" : "proctcae-ae-17",
    "display" : "Pain in Abdomen",
    "designation" : [{
      "language" : "de",
      "value" : "Bauchschmerzen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 7
    }]
  },
  {
    "code" : "proctcae-17a-frq",
    "display" : "Pain in Abdomen Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie BAUCHSCHMERZEN?"
    }]
  },
  {
    "code" : "proctcae-17b-sev",
    "display" : "Pain in Abdomen Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre BAUCHSCHMERZEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-17c-int",
    "display" : "Pain in Abdomen Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr haben BAUCHSCHMERZEN Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-18",
    "display" : "Fecal Incontinence",
    "designation" : [{
      "language" : "de",
      "value" : "Stuhlgang nicht kontrollieren oder halten können (Stuhlinkontinenz)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq int"
    },
    {
      "code" : "rank",
      "valueInteger" : 5
    }]
  },
  {
    "code" : "proctcae-18a-frq",
    "display" : "Fecal Incontinence Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG konnten Sie Ihren STUHLGANG NICHT KONTROLLIEREN ODER HALTEN?"
    }]
  },
  {
    "code" : "proctcae-18b-int",
    "display" : "Fecal Incontinence Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr wurden Sie in Ihren täglichen Aktivitäten GESTÖRT, weil Sie Ihren STUHLGANG NICHT KONTROLLIEREN ODER HALTEN konnten?"
    }]
  },
  {
    "code" : "proctcae-ae-19",
    "display" : "Shortness of Breath",
    "designation" : [{
      "language" : "de",
      "value" : "Kurzatmigkeit"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 6
    }]
  },
  {
    "code" : "proctcae-19a-sev",
    "display" : "Shortness of Breath Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihre KURZATMIGKEIT im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-19b-int",
    "display" : "Shortness of Breath Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr hat KURZATMIGKEIT Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-20",
    "display" : "Cough",
    "designation" : [{
      "language" : "de",
      "value" : "Husten"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 6
    }]
  },
  {
    "code" : "proctcae-20a-sev",
    "display" : "Cough Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihr HUSTEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-20b-int",
    "display" : "Cough Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr hat HUSTEN Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-21",
    "display" : "Wheezing",
    "designation" : [{
      "language" : "de",
      "value" : "Giemen (pfeifendes Atemgeräusch) der Lunge"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-21a-sev",
    "display" : "Wheezing Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK hatten Sie ein GIEMEN (PFEIFENDES ATEMGERÄUSCH) DER LUNGE im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-22",
    "display" : "Arm or Leg Swelling",
    "designation" : [{
      "language" : "de",
      "value" : "Geschwollene Arme oder Beine"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 7
    }]
  },
  {
    "code" : "proctcae-22a-frq",
    "display" : "Arm or Leg Swelling Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie GESCHWOLLENE ARME ODER BEINE?"
    }]
  },
  {
    "code" : "proctcae-22b-sev",
    "display" : "Arm or Leg Swelling Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK GESCHWOLLEN waren Ihre ARME ODER BEINE im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-22c-int",
    "display" : "Arm or Leg Swelling Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr haben GESCHWOLLENE ARME ODER BEINE Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-23",
    "display" : "Pounding or Racing Heartbeat",
    "designation" : [{
      "language" : "de",
      "value" : "Herzklopfen, Herzrasen oder unregelmäßiger Puls"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 4
    }]
  },
  {
    "code" : "proctcae-23a-frq",
    "display" : "Pounding or Racing Heartbeat Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie HERZKLOPFEN, HERZRASEN ODER EINEN UNREGELMÄSSIGEN PULS?"
    }]
  },
  {
    "code" : "proctcae-23b-sev",
    "display" : "Pounding or Racing Heartbeat Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihr HERZKLOPFEN, HERZRASEN ODER UNREGELMÄSSIGER PULS im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-24",
    "display" : "Rash",
    "designation" : [{
      "language" : "de",
      "value" : "Hautausschlag"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-24a-yn",
    "display" : "Rash Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie einen HAUTAUSSCHLAG?"
    }]
  },
  {
    "code" : "proctcae-ae-25",
    "display" : "Skin Dryness",
    "designation" : [{
      "language" : "de",
      "value" : "Trockene Haut"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-25a-sev",
    "display" : "Skin Dryness Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie TROCKEN war Ihre Haut im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-26",
    "display" : "Acne",
    "designation" : [{
      "language" : "de",
      "value" : "Akne oder Pickel im Gesicht oder auf dem Brustkorb"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-26a-sev",
    "display" : "Acne Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK ausgeprägt hatten Sie AKNE ODER PICKEL IM GESICHT ODER AUF DEM BRUSTKORB im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-27",
    "display" : "Hair Loss",
    "designation" : [{
      "language" : "de",
      "value" : "Haarausfall"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "int"
    },
    {
      "code" : "rank",
      "valueInteger" : 3
    }]
  },
  {
    "code" : "proctcae-27a-int",
    "display" : "Hair Loss Amount",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie HAARAUSFALL?"
    }]
  },
  {
    "code" : "proctcae-ae-28",
    "display" : "Itching",
    "designation" : [{
      "language" : "de",
      "value" : "Juckreiz"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-28a-sev",
    "display" : "Itching Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war IHR JUCKREIZ im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-29",
    "display" : "Hives",
    "designation" : [{
      "language" : "de",
      "value" : "Nesselfieber (eine juckende, rote Hautschwellung)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-29a-yn",
    "display" : "Hives Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie NESSELFIEBER (EINE JUCKENDE, ROTE HAUTSCHWELLUNG)?"
    }]
  },
  {
    "code" : "proctcae-ae-30",
    "display" : "Hand-Foot Syndrome",
    "designation" : [{
      "language" : "de",
      "value" : "Hand-Fuss-Syndrom (ein Hautausschlag der Hände oder Füße, der Brennen, Abschälen der Haut, Rötung oder Schmerzen machen kann)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-30a-sev",
    "display" : "Hand-Foot Syndrome Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihr HAND-FUSS-SYNDROM im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-31",
    "display" : "Nail Loss",
    "designation" : [{
      "language" : "de",
      "value" : "Verlust von Finger- oder Fußnägeln"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-31a-yn",
    "display" : "Nail Loss Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Sind Ihnen FINGER- ODER FUSSNÄGEL AUSGEFALLEN?"
    }]
  },
  {
    "code" : "proctcae-ae-32",
    "display" : "Nail Ridging",
    "designation" : [{
      "language" : "de",
      "value" : "Furchen oder Unebenheiten der Finger- oder Fußnägel"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-32a-yn",
    "display" : "Nail Ridging Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie FURCHEN ODER UNEBENHEITEN DER FINGER- ODER FUSSNÄGEL?"
    }]
  },
  {
    "code" : "proctcae-ae-33",
    "display" : "Nail Discoloration",
    "designation" : [{
      "language" : "de",
      "value" : "Veränderungen der Farbe von Finger- oder Fußnägeln"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-33a-yn",
    "display" : "Nail Discoloration Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie VERÄNDERUNGEN DER FARBE VON FINGER- ODER FUSSNÄGELN?"
    }]
  },
  {
    "code" : "proctcae-ae-34",
    "display" : "Sensitivity to Sunlight",
    "designation" : [{
      "language" : "de",
      "value" : "Erhöhte Sonnenlichtempfindlichkeit der Haut"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-34a-yn",
    "display" : "Sensitivity to Sunlight Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie eine ERHÖHTE SONNENLICHTEMPFINDLICHKEIT DER HAUT?"
    }]
  },
  {
    "code" : "proctcae-ae-35",
    "display" : "Bed Sores",
    "designation" : [{
      "language" : "de",
      "value" : "Druckstellen (Dekubitus)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-35a-yn",
    "display" : "Bed Sores Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie DRUCKSTELLEN (DEKUBITUS)?"
    }]
  },
  {
    "code" : "proctcae-ae-36",
    "display" : "Radiation Skin Reaction",
    "designation" : [{
      "language" : "de",
      "value" : "Hautverbrennungen nach einer Bestrahlung"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-36a-sev",
    "display" : "Radiation Skin Reaction Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK ausgeprägt waren Ihre HAUTVERBRENNUNGEN NACH EINER BESTRAHLUNG im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-37",
    "display" : "Skin Darkening",
    "designation" : [{
      "language" : "de",
      "value" : "Ungewöhnliche dunkle Veränderung der Haut"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-37a-yn",
    "display" : "Skin Darkening Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie eine UNGEWÖHNLICHE DUNKLE VERÄNDERUNG DER HAUT?"
    }]
  },
  {
    "code" : "proctcae-ae-38",
    "display" : "Stretch Marks",
    "designation" : [{
      "language" : "de",
      "value" : "Dehnungsstreifen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-38a-yn",
    "display" : "Stretch Marks Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie DEHNUNGSSTREIFEN?"
    }]
  },
  {
    "code" : "proctcae-ae-39",
    "display" : "Numbness and Tingling",
    "designation" : [{
      "language" : "de",
      "value" : "Taubheit oder Kribbeln in Händen oder Füßen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 6
    }]
  },
  {
    "code" : "proctcae-39a-sev",
    "display" : "Numbness and Tingling Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK hatten Sie TAUBHEIT ODER KRIBBELN IN HÄNDEN ODER FÜSSEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-39b-int",
    "display" : "Numbness and Tingling Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr hatten Sie TAUBHEIT ODER KRIBBELN IN HÄNDEN ODER FÜSSEN in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-40",
    "display" : "Dizziness",
    "designation" : [{
      "language" : "de",
      "value" : "Schwindel"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 6
    }]
  },
  {
    "code" : "proctcae-40a-sev",
    "display" : "Dizziness Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihr SCHWINDEL im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-40b-int",
    "display" : "Dizziness Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr hat SCHWINDEL Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-41",
    "display" : "Blurred Vision",
    "designation" : [{
      "language" : "de",
      "value" : "Verschwommenes Sehen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 6
    }]
  },
  {
    "code" : "proctcae-41a-sev",
    "display" : "Blurred Vision Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK VERSCHWOMMEN haben Sie im SCHLIMMSTEN FALL GESEHEN?"
    }]
  },
  {
    "code" : "proctcae-41b-int",
    "display" : "Blurred Vision Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr hat Sie VERSCHWOMMENES SEHEN in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-42",
    "display" : "Flashing Lights",
    "designation" : [{
      "language" : "de",
      "value" : "Blitze vor den Augen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-42a-yn",
    "display" : "Flashing Lights Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Haben Sie BLITZE VOR DEN AUGEN gesehen?"
    }]
  },
  {
    "code" : "proctcae-ae-43",
    "display" : "Visual Floaters",
    "designation" : [{
      "language" : "de",
      "value" : "Schwimmende Punkte, Linien oder Mücken vor den Augen (Mouches volantes)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-43a-yn",
    "display" : "Visual Floaters Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Sahen Sie SCHWIMMENDE PUNKTE, LINIEN ODER MÜCKEN VOR DEN AUGEN (MOUCHES VOLANTES)?"
    }]
  },
  {
    "code" : "proctcae-ae-44",
    "display" : "Watery Eyes",
    "designation" : [{
      "language" : "de",
      "value" : "Tränende Augen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 6
    }]
  },
  {
    "code" : "proctcae-44a-sev",
    "display" : "Watery Eyes Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK hatten Sie TRÄNENDE AUGEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-44b-int",
    "display" : "Watery Eyes Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr haben TRÄNENDE AUGEN Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-45",
    "display" : "Ringing in Ears",
    "designation" : [{
      "language" : "de",
      "value" : "Ohrgeräusche (z. B. Pfeifen in den Ohren)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-45a-sev",
    "display" : "Ringing in Ears Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre OHRGERÄUSCHE (Z. B. PFEIFEN IN DEN OHREN) im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-46",
    "display" : "Concentration",
    "designation" : [{
      "language" : "de",
      "value" : "Probleme sich zu konzentrieren"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 6
    }]
  },
  {
    "code" : "proctcae-46a-sev",
    "display" : "Concentration Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre PROBLEME SICH ZU KONZENTRIEREN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-46b-int",
    "display" : "Concentration Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr haben Ihre PROBLEME SICH ZU KONZENTRIEREN Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-47",
    "display" : "Memory",
    "designation" : [{
      "language" : "de",
      "value" : "Probleme mit dem Gedächtnis (Vergesslichkeit)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 6
    }]
  },
  {
    "code" : "proctcae-47a-sev",
    "display" : "Memory Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre PROBLEME MIT DEM GEDÄCHTNIS (VERGESSLICHKEIT) im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-47b-int",
    "display" : "Memory Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr haben Sie Ihre PROBLEME MIT DEM GEDÄCHTNIS (VERGESSLICHKEIT) in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-48",
    "display" : "General Pain",
    "designation" : [{
      "language" : "de",
      "value" : "Schmerzen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 7
    }]
  },
  {
    "code" : "proctcae-48a-frq",
    "display" : "General Pain Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie SCHMERZEN?"
    }]
  },
  {
    "code" : "proctcae-48b-sev",
    "display" : "General Pain Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre SCHMERZEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-48c-int",
    "display" : "General Pain Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr haben SCHMERZEN Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-49",
    "display" : "Headache",
    "designation" : [{
      "language" : "de",
      "value" : "Kopfschmerzen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 7
    }]
  },
  {
    "code" : "proctcae-49a-frq",
    "display" : "Headache Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie KOPFSCHMERZEN?"
    }]
  },
  {
    "code" : "proctcae-49b-sev",
    "display" : "Headache Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre KOPFSCHMERZEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-49c-int",
    "display" : "Headache Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr haben KOPFSCHMERZEN Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-50",
    "display" : "Muscle Pain",
    "designation" : [{
      "language" : "de",
      "value" : "Muskelschmerzen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 7
    }]
  },
  {
    "code" : "proctcae-50a-frq",
    "display" : "Muscle Pain Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie MUSKELSCHMERZEN?"
    }]
  },
  {
    "code" : "proctcae-50b-sev",
    "display" : "Muscle Pain Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK hatten Sie MUSKELSCHMERZEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-50c-int",
    "display" : "Muscle Pain Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr haben MUSKELSCHMERZEN Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-51",
    "display" : "Joint Pain",
    "designation" : [{
      "language" : "de",
      "value" : "Gelenkschmerzen (z. B. Ellenbogen, Knie, Schultern)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 7
    }]
  },
  {
    "code" : "proctcae-51a-frq",
    "display" : "Joint Pain Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie GELENKSCHMERZEN (Z. B. ELLENBOGEN, KNIE, SCHULTERN)?"
    }]
  },
  {
    "code" : "proctcae-51b-sev",
    "display" : "Joint Pain Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK hatten Sie GELENKSCHMERZEN (Z. B. ELLENBOGEN, KNIE, SCHULTERN) im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-51c-int",
    "display" : "Joint Pain Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr haben GELENKSCHMERZEN (Z. B. ELLENBOGEN, KNIE, SCHULTERN) Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-52",
    "display" : "Insomnia",
    "designation" : [{
      "language" : "de",
      "value" : "Probleme beim Schlafen (wie z. B. Schwierigkeiten beim Einschlafen, Durchschlafen oder zu frühes Aufwachen)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 6
    }]
  },
  {
    "code" : "proctcae-52a-sev",
    "display" : "Insomnia Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre PROBLEME BEIM SCHLAFEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-52b-int",
    "display" : "Insomnia Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr haben PROBLEME BEIM SCHLAFEN Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-53",
    "display" : "Fatigue",
    "designation" : [{
      "language" : "de",
      "value" : "Müdigkeit, Erschöpfung oder fehlende Energie"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 6
    }]
  },
  {
    "code" : "proctcae-53a-sev",
    "display" : "Fatigue Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre MÜDIGKEIT, ERSCHÖPFUNG ODER FEHLENDE ENERGIE im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-53b-int",
    "display" : "Fatigue Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr haben MÜDIGKEIT, ERSCHÖPFUNG ODER FEHLENDE ENERGIE Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-54",
    "display" : "Anxiety",
    "designation" : [{
      "language" : "de",
      "value" : "Angst"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 7
    }]
  },
  {
    "code" : "proctcae-54a-frq",
    "display" : "Anxiety Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie ANGST?"
    }]
  },
  {
    "code" : "proctcae-54b-sev",
    "display" : "Anxiety Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihre ANGST im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-54c-int",
    "display" : "Anxiety Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr hat ANGST Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-55",
    "display" : "Discouraged",
    "designation" : [{
      "language" : "de",
      "value" : "Mutlosigkeit (Gefühl, dass einen nichts aufmuntern kann)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 7
    }]
  },
  {
    "code" : "proctcae-55a-frq",
    "display" : "Discouraged Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie das GEFÜHL, DASS SIE NICHTS AUFMUNTERN KONNTE?"
    }]
  },
  {
    "code" : "proctcae-55b-sev",
    "display" : "Discouraged Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK hatten Sie das GEFÜHL, DASS SIE NICHTS AUFMUNTERN KONNTE, im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-55c-int",
    "display" : "Discouraged Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr hat Sie das GEFÜHL, DASS SIE NICHTS AUFMUNTERN KONNTE in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-56",
    "display" : "Sad",
    "designation" : [{
      "language" : "de",
      "value" : "Traurigkeit"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev int"
    },
    {
      "code" : "rank",
      "valueInteger" : 7
    }]
  },
  {
    "code" : "proctcae-56a-frq",
    "display" : "Sad Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG waren Sie TRAURIG?"
    }]
  },
  {
    "code" : "proctcae-56b-sev",
    "display" : "Sad Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihre TRAURIGKEIT im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-56c-int",
    "display" : "Sad Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr hat Ihre TRAURIGKEIT Sie in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-57",
    "display" : "Irregular Periods",
    "designation" : [{
      "language" : "de",
      "value" : "Unregelmäßige Regelblutung"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-57a-yn",
    "display" : "Irregular Periods Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie eine UNREGELMÄSSIGE REGELBLUTUNG?"
    }]
  },
  {
    "code" : "proctcae-ae-58",
    "display" : "Missed Expected Menstrual Period",
    "designation" : [{
      "language" : "de",
      "value" : "Ausbleiben einer erwarteten Regelblutung"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-58a-yn",
    "display" : "Missed Periods Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Ist bei Ihnen eine ERWARTETE REGELBLUTUNG ausgeblieben?"
    }]
  },
  {
    "code" : "proctcae-ae-59",
    "display" : "Vaginal Discharge",
    "designation" : [{
      "language" : "de",
      "value" : "Ungewöhnlicher Ausfluss der Scheide"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "int"
    },
    {
      "code" : "rank",
      "valueInteger" : 3
    }]
  },
  {
    "code" : "proctcae-59a-int",
    "display" : "Vaginal Discharge Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie einen UNGEWÖHNLICHEN AUSFLUSS DER SCHEIDE?"
    }]
  },
  {
    "code" : "proctcae-ae-60",
    "display" : "Vaginal Dryness",
    "designation" : [{
      "language" : "de",
      "value" : "Scheidentrockenheit"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-60a-sev",
    "display" : "Vaginal Dryness Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihre SCHEIDENTROCKENHEIT im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-61",
    "display" : "Painful Urination",
    "designation" : [{
      "language" : "de",
      "value" : "Schmerzen oder Brennen beim Wasserlassen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-61a-sev",
    "display" : "Painful Urination Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre SCHMERZEN ODER BRENNEN BEIM WASSERLASSEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-62",
    "display" : "Urinary Urgency",
    "designation" : [{
      "language" : "de",
      "value" : "Plötzlicher starker Drang zum Wasserlassen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq int"
    },
    {
      "code" : "rank",
      "valueInteger" : 5
    }]
  },
  {
    "code" : "proctcae-62a-frq",
    "display" : "Urinary Urgency Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie einen PLÖTZLICHEN STARKEN DRANG ZUM WASSERLASSEN?"
    }]
  },
  {
    "code" : "proctcae-62b-int",
    "display" : "Urinary Urgency Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr wurden Sie durch einen PLÖTZLICHEN STARKEN DRANG ZUM WASSERLASSEN in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-63",
    "display" : "Urinary Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Häufiges Wasserlassen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq int"
    },
    {
      "code" : "rank",
      "valueInteger" : 5
    }]
  },
  {
    "code" : "proctcae-63a-frq",
    "display" : "Urinary Frequency Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Mussten Sie HÄUFIGER WASSER LASSEN als üblich?"
    }]
  },
  {
    "code" : "proctcae-63b-int",
    "display" : "Urinary Frequency Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr hat Sie HÄUFIGES WASSERLASSEN in Ihren täglichen Aktivitäten GESTÖRT?"
    }]
  },
  {
    "code" : "proctcae-ae-64",
    "display" : "Urine Color Change",
    "designation" : [{
      "language" : "de",
      "value" : "Ungewöhnliche Veränderung der Urinfarbe"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-64a-yn",
    "display" : "Urine Color Change Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie eine UNGEWÖHNLICHE VERÄNDERUNG DER URINFARBE?"
    }]
  },
  {
    "code" : "proctcae-ae-65",
    "display" : "Urinary Incontinence",
    "designation" : [{
      "language" : "de",
      "value" : "Urin nicht halten können (Urininkontinenz)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq int"
    },
    {
      "code" : "rank",
      "valueInteger" : 5
    }]
  },
  {
    "code" : "proctcae-65a-frq",
    "display" : "Urinary Incontinence Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG konnten Sie Ihren URIN NICHT HALTEN (URININKONTINENZ)?"
    }]
  },
  {
    "code" : "proctcae-65b-int",
    "display" : "Urinary Incontinence Interference",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr wurden Sie in Ihren täglichen Aktivitäten GESTÖRT, weil Sie Ihren URIN NICHT HALTEN KONNTEN (URININKONTINENZ)?"
    }]
  },
  {
    "code" : "proctcae-ae-66",
    "display" : "Achieve and Maintain Erection",
    "designation" : [{
      "language" : "de",
      "value" : "Probleme eine Erektion zu bekommen oder zu halten"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-66a-sev",
    "display" : "Erection Difficulty Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre PROBLEME EINE EREKTION ZU BEKOMMEN ODER ZU HALTEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-67",
    "display" : "Ejaculation",
    "designation" : [{
      "language" : "de",
      "value" : "Probleme einen Samenerguss zu bekommen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq"
    },
    {
      "code" : "rank",
      "valueInteger" : 1
    }]
  },
  {
    "code" : "proctcae-67a-frq",
    "display" : "Ejaculation Problems Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie PROBLEME EINEN SAMENERGUSS ZU BEKOMMEN?"
    }]
  },
  {
    "code" : "proctcae-ae-68",
    "display" : "Decreased Libido",
    "designation" : [{
      "language" : "de",
      "value" : "Weniger Interesse an Sexualität"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-68a-sev",
    "display" : "Decreased Sexual Interest Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK vermindert war Ihr INTERESSE AN SEXUALITÄT im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-69",
    "display" : "Delayed Orgasm",
    "designation" : [{
      "language" : "de",
      "value" : "Es dauert zu lange bis man einen Orgasmus oder Höhepunkt bekommen kann"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-69a-yn",
    "display" : "Delayed Orgasm Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie das Gefühl, dass es ZU LANGE DAUERT BIS SIE EINEN ORGASMUS ODER HÖHEPUNKT BEKOMMEN KÖNNEN?"
    }]
  },
  {
    "code" : "proctcae-ae-70",
    "display" : "Unable to Have Orgasm",
    "designation" : [{
      "language" : "de",
      "value" : "Nicht in der Lage sein, einen Orgasmus oder Höhepunkt zu bekommen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-70a-yn",
    "display" : "Unable to Have Orgasm Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Waren Sie nicht IN DER LAGE EINEN ORGASMUS ODER HÖHEPUNKT ZU BEKOMMEN?"
    }]
  },
  {
    "code" : "proctcae-ae-71",
    "display" : "Pain with Sexual Intercourse",
    "designation" : [{
      "language" : "de",
      "value" : "Schmerzen der Scheide beim Geschlechtsverkehr"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-71a-sev",
    "display" : "Pain During Vaginal Sex Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre SCHMERZEN DER SCHEIDE BEIM GESCHLECHTSVERKEHR im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-72",
    "display" : "Breast Swelling and Tenderness",
    "designation" : [{
      "language" : "de",
      "value" : "Schwellung oder Druckempfindlichkeit der Brust"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-72a-sev",
    "display" : "Breast Swelling and Tenderness Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK hatten Sie eine SCHWELLUNG ODER DRUCKEMPFINDLICHKEIT DER BRUST im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-73",
    "display" : "Bruising",
    "designation" : [{
      "language" : "de",
      "value" : "Leicht blaue Flecken bekommen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-73a-yn",
    "display" : "Bruising Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Haben Sie LEICHT BLAUE FLECKEN BEKOMMEN?"
    }]
  },
  {
    "code" : "proctcae-ae-74",
    "display" : "Chills",
    "designation" : [{
      "language" : "de",
      "value" : "Schüttelfrost"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 4
    }]
  },
  {
    "code" : "proctcae-74a-frq",
    "display" : "Chills Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie SCHÜTTELFROST?"
    }]
  },
  {
    "code" : "proctcae-74b-sev",
    "display" : "Chills Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihr SCHÜTTELFROST im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-75",
    "display" : "Increased Sweating",
    "designation" : [{
      "language" : "de",
      "value" : "Unerwartetes oder starkes Schwitzen während des Tages oder der Nacht (nicht in Verbindung mit Hitzewallungen)"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 4
    }]
  },
  {
    "code" : "proctcae-75a-frq",
    "display" : "Increased Sweating Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie UNERWARTETES ODER STARKES SCHWITZEN WÄHREND DES TAGES ODER DER NACHT?"
    }]
  },
  {
    "code" : "proctcae-75b-sev",
    "display" : "Increased Sweating Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK hatten Sie UNERWARTETES ODER STARKES SCHWITZEN WÄHREND DES TAGES ODER DER NACHT im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-76",
    "display" : "Decreased Sweating",
    "designation" : [{
      "language" : "de",
      "value" : "Vermindertes Schwitzen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-76a-yn",
    "display" : "Decreased Sweating Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Konnten Sie UNERWARTET WENIGER SCHWITZEN?"
    }]
  },
  {
    "code" : "proctcae-ae-77",
    "display" : "Hot Flashes",
    "designation" : [{
      "language" : "de",
      "value" : "Hitzewallungen"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 4
    }]
  },
  {
    "code" : "proctcae-77a-frq",
    "display" : "Hot Flashes Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie HITZEWALLUNGEN?"
    }]
  },
  {
    "code" : "proctcae-77b-sev",
    "display" : "Hot Flashes Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK waren Ihre HITZEWALLUNGEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-78",
    "display" : "Nosebleed",
    "designation" : [{
      "language" : "de",
      "value" : "Nasenbluten"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "frq sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 4
    }]
  },
  {
    "code" : "proctcae-78a-frq",
    "display" : "Nosebleed Frequency",
    "designation" : [{
      "language" : "de",
      "value" : "Wie HÄUFIG hatten Sie NASENBLUTEN?"
    }]
  },
  {
    "code" : "proctcae-78b-sev",
    "display" : "Nosebleed Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihr NASENBLUTEN im SCHLIMMSTEN FALL?"
    }]
  },
  {
    "code" : "proctcae-ae-79",
    "display" : "Pain and Swelling at Injection Site",
    "designation" : [{
      "language" : "de",
      "value" : "Schmerzen, Schwellung oder Rötung der Haut an einer Einstichstelle von einer Infusion oder Spritze"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "presence"
    }]
  },
  {
    "code" : "proctcae-79a-yn",
    "display" : "Injection Site Reaction Presence",
    "designation" : [{
      "language" : "de",
      "value" : "Hatten Sie SCHMERZEN, EINE SCHWELLUNG ODER RÖTUNG DER HAUT AN EINER EINSTICHSTELLE VON EINER INFUSION ODER SPRITZE?"
    }]
  },
  {
    "code" : "proctcae-ae-80",
    "display" : "Body Odor",
    "designation" : [{
      "language" : "de",
      "value" : "Körpergeruch"
    }],
    "property" : [{
      "code" : "attributes",
      "valueString" : "sev"
    },
    {
      "code" : "rank",
      "valueInteger" : 2
    }]
  },
  {
    "code" : "proctcae-80a-sev",
    "display" : "Body Odor Severity",
    "designation" : [{
      "language" : "de",
      "value" : "Wie STARK war Ihr KÖRPERGERUCH im SCHLIMMSTEN FALL?"
    }]
  }]
}

```
