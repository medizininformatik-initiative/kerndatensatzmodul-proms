# MII CS PRO WHODAS 2.0 12-Item Response Scale and Item Codes - MII IG PRO v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII CS PRO WHODAS 2.0 12-Item Response Scale and Item Codes**

## CodeSystem: MII CS PRO WHODAS 2.0 12-Item Response Scale and Item Codes (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-whodas-12 | *Version*:2027.0.0-ballot |
| Active as of 2026-09-06 | *Computable Name*:MII_CS_PRO_WHODAS_12 |
| **Copyright/Legal**: WHODAS 2.0 © World Health Organization 2010. Scale/item text used under WHO terms; electronic or data-capture use requires a WHO licence agreement (free of charge for non-commercial use) via the WHO Classifications licensing process. MII-authored FHIR content is licensed CC0. | |

 
CodeSystem for the WHO Disability Assessment Schedule 2.0, 12-item self-administered version (WHODAS-12), with item codes and a 5-point answer scale. English primary displays with German designations. The answer concepts carry ordinalValue properties (0-4) enabling SDC ordinal scoring via answerValueSet. WHODAS 2.0 © WHO 2010; electronic use requires a WHO licence (see copyright). 

This Code system is referenced in the definition of the following value sets:

* [MII VS PRO WHODAS 2.0 12-Item Answer List](ValueSet-mii-vs-pro-whodas-12-answer-list.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "mii-cs-pro-whodas-12",
  "language" : "en",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-whodas-12",
  "version" : "2027.0.0-ballot",
  "name" : "MII_CS_PRO_WHODAS_12",
  "title" : "MII CS PRO WHODAS 2.0 12-Item Response Scale and Item Codes",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-09-06T21:15:57+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "CodeSystem for the WHO Disability Assessment Schedule 2.0, 12-item self-administered version (WHODAS-12), with item codes and a 5-point answer scale. English primary displays with German designations. The answer concepts carry ordinalValue properties (0-4) enabling SDC ordinal scoring via answerValueSet. WHODAS 2.0 © WHO 2010; electronic use requires a WHO licence (see copyright).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "WHODAS 2.0 © World Health Organization 2010. Scale/item text used under WHO terms; electronic or data-capture use requires a WHO licence agreement (free of charge for non-commercial use) via the WHO Classifications licensing process. MII-authored FHIR content is licensed CC0.",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 17,
  "property" : [{
    "code" : "ordinalValue",
    "uri" : "http://hl7.org/fhir/StructureDefinition/ordinalValue",
    "description" : "Numerical ordinal value (0-4) for SDC calculatedExpression scoring via .ordinal().sum()",
    "type" : "decimal"
  }],
  "concept" : [{
    "code" : "whodas12-answer-0",
    "display" : "None",
    "designation" : [{
      "language" : "de",
      "value" : "keine"
    }],
    "property" : [{
      "code" : "ordinalValue",
      "valueDecimal" : 0
    }]
  },
  {
    "code" : "whodas12-answer-1",
    "display" : "Mild",
    "designation" : [{
      "language" : "de",
      "value" : "geringe"
    }],
    "property" : [{
      "code" : "ordinalValue",
      "valueDecimal" : 1
    }]
  },
  {
    "code" : "whodas12-answer-2",
    "display" : "Moderate",
    "designation" : [{
      "language" : "de",
      "value" : "mäßige"
    }],
    "property" : [{
      "code" : "ordinalValue",
      "valueDecimal" : 2
    }]
  },
  {
    "code" : "whodas12-answer-3",
    "display" : "Severe",
    "designation" : [{
      "language" : "de",
      "value" : "starke"
    }],
    "property" : [{
      "code" : "ordinalValue",
      "valueDecimal" : 3
    }]
  },
  {
    "code" : "whodas12-answer-4",
    "display" : "Extreme or cannot do",
    "designation" : [{
      "language" : "de",
      "value" : "sehr starke/nicht möglich"
    }],
    "property" : [{
      "code" : "ordinalValue",
      "valueDecimal" : 4
    }]
  },
  {
    "code" : "whodas12-q01",
    "display" : "Standing for long periods such as 30 minutes?",
    "designation" : [{
      "language" : "de",
      "value" : "längere Zeit (ca. 30 min) zu stehen?"
    }]
  },
  {
    "code" : "whodas12-q02",
    "display" : "Taking care of your household responsibilities?",
    "designation" : [{
      "language" : "de",
      "value" : "Ihren Haushaltspflichten nachzukommen?"
    }]
  },
  {
    "code" : "whodas12-q03",
    "display" : "Learning a new task, for example, learning how to get to a new place?",
    "designation" : [{
      "language" : "de",
      "value" : "Neue Aufgaben zu lernen (z.B. erlernen an einen neuen Ort zu gelangen, den sie nicht kannten?)"
    }]
  },
  {
    "code" : "whodas12-q04",
    "display" : "Joining in community activities (for example, festivities, religious or other activities) in the same way as anyone else can?",
    "designation" : [{
      "language" : "de",
      "value" : "Wie viele Schwierigkeiten hatten Sie, an gesellschaftlichen Aktivitäten (wie z.B. Festlichkeiten, religiöse oder andere Aktivitäten) in der gleichen Art und Weise teilzunehmen, wie jeder andere?"
    }]
  },
  {
    "code" : "whodas12-q05",
    "display" : "Being emotionally affected by your health problems?",
    "designation" : [{
      "language" : "de",
      "value" : "Wie sehr wurden Sie durch Ihren gesundheitlichen Zustand emotional belastet?"
    }]
  },
  {
    "code" : "whodas12-q06",
    "display" : "Concentrating on doing something for ten minutes?",
    "designation" : [{
      "language" : "de",
      "value" : "Sich auf etwas für 10 Minuten zu konzentrieren?"
    }]
  },
  {
    "code" : "whodas12-q07",
    "display" : "Walking a long distance such as a kilometre?",
    "designation" : [{
      "language" : "de",
      "value" : "Eine längere Strecke (ca. einen Kilometer) zu Fuß zu gehen?"
    }]
  },
  {
    "code" : "whodas12-q08",
    "display" : "Washing your whole body?",
    "designation" : [{
      "language" : "de",
      "value" : "Ihren gesamten Körper zu waschen?"
    }]
  },
  {
    "code" : "whodas12-q09",
    "display" : "Getting dressed?",
    "designation" : [{
      "language" : "de",
      "value" : "sich anzuziehen?"
    }]
  },
  {
    "code" : "whodas12-q10",
    "display" : "Dealing with people you do not know?",
    "designation" : [{
      "language" : "de",
      "value" : "Im Umgang mit anderen Personen, die Sie nicht kennen?"
    }]
  },
  {
    "code" : "whodas12-q11",
    "display" : "Maintaining a friendship?",
    "designation" : [{
      "language" : "de",
      "value" : "Eine Freundschaft aufrechtzuerhalten?"
    }]
  },
  {
    "code" : "whodas12-q12",
    "display" : "Your day-to-day work/school?",
    "designation" : [{
      "language" : "de",
      "value" : "Bei der Bewältigung des Arbeits-/Schulalltags?"
    }]
  }]
}

```
