# CodeSystem - MII IG PRO v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* [**MII QST PRO EORTC QLQ-C30 Variant B**](Questionnaire-mii-qst-pro-eortc-qlq-c30-variant-b.md)
* **CodeSystem**

## CodeSystem: CodeSystem 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/Questionnaire/mii-qst-pro-eortc-qlq-c30-variant-b#eortc-qlq-c30-cs-b | *Version*:2027.0.0-ballot.rc1 |
| Active | *Maschinenlesbarer Name*: |

Dieses CodeSystem wird in der Definition der folgenden ValueSets referenziert:

* [MII VS PRO EORTC QLQ-C30 4-Point Scale](ValueSet-mii-vs-pro-eortc-qlq-c30-scale-4pt.md)
* [MII VS PRO EORTC QLQ-C30 7-Point Scale](ValueSet-mii-vs-pro-eortc-qlq-c30-scale-7pt.md)
* [MII VS PRO EORTC QLQ-C30 Role Functioning Scale](ValueSet-mii-vs-pro-eortc-qlq-c30-scale-role.md)

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 

