# PRO-CTCAE Deutsches Brustkrebszentrum-Subset (21 Symptome) - MII IG PRO v2027.0.0-rc.1

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **PRO-CTCAE Deutsches Brustkrebszentrum-Subset (21 Symptome)**

## Questionnaire: PRO-CTCAE Deutsches Brustkrebszentrum-Subset (21 Symptome) (Experimentell) 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/Questionnaire/mii-qst-pro-pro-ctcae-breast-de | *Version*:2027.0.0-rc.1 |
| Draft Stand: 2026-11-05 | *Maschinenlesbarer Name*:MII_QST_PRO_PRO_CTCAE_Breast_DE |

 
PRO-CTCAE Brustkrebszentrum-Subset: 21 Symptome ausgewählt nach Prävalenz und Wichtigkeit bei ambulanten Brustkrebspatientinnen (Hamacher et al., BMC Cancer 2023). Scoring via CQL Library (CompositeGrade pro Symptom + Average Composite Score). 

*  [Baumansicht](#tabs-tree) 
*  [Beispielanzeige](#tabs-sample) 
*  [Formularlogik](#tabs-logic) 

### Diesen Fragebogen testen

### Antworten zu diesem Fragebogen

Es sind derzeit keine QuestionnaireResponse-Instanzen für diesen Fragebogen in diesem IG definiert.



## Resource Content

```json
{
  "resourceType" : "Questionnaire",
  "id" : "mii-qst-pro-pro-ctcae-breast-de",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-pr-pro-questionnaire|2027.0.0-rc.1"]
  },
  "language" : "de",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "natural",
      "display" : "Natural"
    }
  },
  {
    "extension" : [{
      "url" : "displayable",
      "valueBoolean" : true
    },
    {
      "url" : "collectable",
      "valueBoolean" : true
    },
    {
      "url" : "calculatable",
      "valueBoolean" : false
    },
    {
      "url" : "extractable",
      "valueBoolean" : false
    },
    {
      "url" : "domainAligned",
      "valueBoolean" : false
    }],
    "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-ex-pro-questionnaire-capabilities"
  },
  {
    "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
    "valueBoolean" : true
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/Questionnaire/mii-qst-pro-pro-ctcae-breast-de",
  "version" : "2027.0.0-rc.1",
  "name" : "MII_QST_PRO_PRO_CTCAE_Breast_DE",
  "title" : "PRO-CTCAE Deutsches Brustkrebszentrum-Subset (21 Symptome)",
  "_title" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "en"
      },
      {
        "url" : "content",
        "valueString" : "PRO-CTCAE German Breast Cancer Subset (21 Symptoms)"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-11-05T07:47:07+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "PRO-CTCAE Brustkrebszentrum-Subset: 21 Symptome ausgewählt nach Prävalenz und Wichtigkeit bei ambulanten Brustkrebspatientinnen (Hamacher et al., BMC Cancer 2023). Scoring via CQL Library (CompositeGrade pro Symptom + Average Composite Score).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "code" : [{
    "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-questionnaire-catalogue",
    "code" : "proctcae-breast-de",
    "display" : "PRO-CTCAE German Breast Cancer Subset (21 Symptoms)"
  }],
  "item" : [{
    "linkId" : "proctcae-53",
    "text" : "Müdigkeit, Erschöpfung oder fehlende Energie",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-53a-sev",
      "text" : "Wie STARK waren Ihre MÜDIGKEIT, ERSCHÖPFUNG ODER FEHLENDE ENERGIE im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    },
    {
      "linkId" : "proctcae-53b-int",
      "text" : "Wie sehr haben MÜDIGKEIT, ERSCHÖPFUNG ODER FEHLENDE ENERGIE Sie in Ihren täglichen Aktivitäten GESTÖRT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-39",
    "text" : "Taubheit oder Kribbeln in Händen oder Füßen",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-39a-sev",
      "text" : "Wie STARK hatten Sie TAUBHEIT ODER KRIBBELN IN HÄNDEN ODER FÜSSEN im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    },
    {
      "linkId" : "proctcae-39b-int",
      "text" : "Wie sehr hatten Sie TAUBHEIT ODER KRIBBELN IN HÄNDEN ODER FÜSSEN in Ihren täglichen Aktivitäten GESTÖRT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-09",
    "text" : "Übelkeit",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-09a-frq",
      "text" : "Wie HÄUFIG hatten Sie ÜBELKEIT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-frequency"
    },
    {
      "linkId" : "proctcae-09b-sev",
      "text" : "Wie STARK war Ihre ÜBELKEIT im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    }]
  },
  {
    "linkId" : "proctcae-50",
    "text" : "Muskelschmerzen",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-50a-frq",
      "text" : "Wie HÄUFIG hatten Sie MUSKELSCHMERZEN?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-frequency"
    },
    {
      "linkId" : "proctcae-50b-sev",
      "text" : "Wie STARK hatten Sie MUSKELSCHMERZEN im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    },
    {
      "linkId" : "proctcae-50c-int",
      "text" : "Wie sehr haben MUSKELSCHMERZEN Sie in Ihren täglichen Aktivitäten GESTÖRT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-52",
    "text" : "Probleme beim Schlafen",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-52a-sev",
      "text" : "Wie STARK waren Ihre PROBLEME BEIM SCHLAFEN im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    },
    {
      "linkId" : "proctcae-52b-int",
      "text" : "Wie sehr haben PROBLEME BEIM SCHLAFEN Sie in Ihren täglichen Aktivitäten GESTÖRT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-27",
    "text" : "Haarausfall",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-27a-int",
      "text" : "Hatten Sie HAARAUSFALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-51",
    "text" : "Gelenkschmerzen (z. B. Ellenbogen, Knie, Schultern)",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-51a-frq",
      "text" : "Wie HÄUFIG hatten Sie GELENKSCHMERZEN (Z. B. ELLENBOGEN, KNIE, SCHULTERN)?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-frequency"
    },
    {
      "linkId" : "proctcae-51b-sev",
      "text" : "Wie STARK hatten Sie GELENKSCHMERZEN (Z. B. ELLENBOGEN, KNIE, SCHULTERN) im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    },
    {
      "linkId" : "proctcae-51c-int",
      "text" : "Wie sehr haben GELENKSCHMERZEN (Z. B. ELLENBOGEN, KNIE, SCHULTERN) Sie in Ihren täglichen Aktivitäten GESTÖRT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-41",
    "text" : "Verschwommenes Sehen",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-41a-sev",
      "text" : "Wie STARK VERSCHWOMMEN haben Sie im SCHLIMMSTEN FALL GESEHEN?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    },
    {
      "linkId" : "proctcae-41b-int",
      "text" : "Wie sehr hat Sie VERSCHWOMMENES SEHEN in Ihren täglichen Aktivitäten GESTÖRT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-46",
    "text" : "Probleme sich zu konzentrieren",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-46a-sev",
      "text" : "Wie STARK waren Ihre PROBLEME SICH ZU KONZENTRIEREN im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    },
    {
      "linkId" : "proctcae-46b-int",
      "text" : "Wie sehr haben Ihre PROBLEME SICH ZU KONZENTRIEREN Sie in Ihren täglichen Aktivitäten GESTÖRT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-48",
    "text" : "Schmerzen",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-48a-frq",
      "text" : "Wie HÄUFIG hatten Sie SCHMERZEN?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-frequency"
    },
    {
      "linkId" : "proctcae-48b-sev",
      "text" : "Wie STARK waren Ihre SCHMERZEN im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    },
    {
      "linkId" : "proctcae-48c-int",
      "text" : "Wie sehr haben SCHMERZEN Sie in Ihren täglichen Aktivitäten GESTÖRT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-16",
    "text" : "Durchfall",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-16a-frq",
      "text" : "Wie HÄUFIG hatten Sie DURCHFALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-frequency"
    }]
  },
  {
    "linkId" : "proctcae-15",
    "text" : "Verstopfung",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-15a-sev",
      "text" : "Wie STARK war Ihre VERSTOPFUNG im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    }]
  },
  {
    "linkId" : "proctcae-07",
    "text" : "Geschmacksveränderungen beim Essen oder Trinken",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-07a-sev",
      "text" : "Wie STARK waren Ihre GESCHMACKSVERÄNDERUNGEN BEIM ESSEN ODER TRINKEN im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    }]
  },
  {
    "linkId" : "proctcae-40",
    "text" : "Schwindel",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-40a-sev",
      "text" : "Wie STARK war Ihr SCHWINDEL im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    },
    {
      "linkId" : "proctcae-40b-int",
      "text" : "Wie sehr hat SCHWINDEL Sie in Ihren täglichen Aktivitäten GESTÖRT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-19",
    "text" : "Kurzatmigkeit",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-19a-sev",
      "text" : "Wie STARK war Ihre KURZATMIGKEIT im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    },
    {
      "linkId" : "proctcae-19b-int",
      "text" : "Wie sehr hat KURZATMIGKEIT Sie in Ihren täglichen Aktivitäten GESTÖRT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-23",
    "text" : "Herzklopfen, Herzrasen oder unregelmäßiger Puls",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-23a-frq",
      "text" : "Wie HÄUFIG hatten Sie HERZKLOPFEN, HERZRASEN ODER EINEN UNREGELMÄSSIGEN PULS?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-frequency"
    },
    {
      "linkId" : "proctcae-23b-sev",
      "text" : "Wie STARK waren Ihr HERZKLOPFEN, HERZRASEN ODER UNREGELMÄSSIGER PULS im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    }]
  },
  {
    "linkId" : "proctcae-47",
    "text" : "Probleme mit dem Gedächtnis (Vergesslichkeit)",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-47a-sev",
      "text" : "Wie STARK waren Ihre PROBLEME MIT DEM GEDÄCHTNIS (VERGESSLICHKEIT) im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    },
    {
      "linkId" : "proctcae-47b-int",
      "text" : "Wie sehr haben Sie Ihre PROBLEME MIT DEM GEDÄCHTNIS (VERGESSLICHKEIT) in Ihren täglichen Aktivitäten GESTÖRT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-22",
    "text" : "Geschwollene Arme oder Beine",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-22a-frq",
      "text" : "Wie HÄUFIG hatten Sie GESCHWOLLENE ARME ODER BEINE?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-frequency"
    },
    {
      "linkId" : "proctcae-22b-sev",
      "text" : "Wie STARK GESCHWOLLEN waren Ihre ARME ODER BEINE im SCHLIMMSTEN FALL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-severity"
    },
    {
      "linkId" : "proctcae-22c-int",
      "text" : "Wie sehr haben GESCHWOLLENE ARME ODER BEINE Sie in Ihren täglichen Aktivitäten GESTÖRT?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-interference"
    }]
  },
  {
    "linkId" : "proctcae-24",
    "text" : "Hautausschlag",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-24a-yn",
      "text" : "Hatten Sie einen HAUTAUSSCHLAG?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-presence"
    }]
  },
  {
    "linkId" : "proctcae-32",
    "text" : "Furchen oder Unebenheiten der Finger- oder Fußnägel",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-32a-yn",
      "text" : "Hatten Sie FURCHEN ODER UNEBENHEITEN DER FINGER- ODER FUSSNÄGEL?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-presence"
    }]
  },
  {
    "linkId" : "proctcae-33",
    "text" : "Veränderungen der Farbe von Finger- oder Fußnägeln",
    "type" : "group",
    "item" : [{
      "linkId" : "proctcae-33a-yn",
      "text" : "Hatten Sie VERÄNDERUNGEN DER FARBE VON FINGER- ODER FUSSNÄGELN?",
      "type" : "choice",
      "required" : true,
      "answerValueSet" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/ValueSet/mii-vs-pro-pro-ctcae-presence"
    }]
  }]
}

```
