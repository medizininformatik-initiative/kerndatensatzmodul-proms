# MII EXA PRO Patient - MII IG PRO v2027.0.0-rc.1

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII EXA PRO Patient**

## Beispiel Patient: MII EXA PRO Patient

-------

**German**

-------

Max Mustermann Male, DoB: 1980-05-15 ( http://identifiers.org/patient-ids#12345)

-------



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "mii-exa-pro-patient",
  "identifier" : [{
    "system" : "http://identifiers.org/patient-ids",
    "value" : "12345"
  }],
  "name" : [{
    "family" : "Mustermann",
    "given" : ["Max"]
  }],
  "gender" : "male",
  "birthDate" : "1980-05-15"
}

```
