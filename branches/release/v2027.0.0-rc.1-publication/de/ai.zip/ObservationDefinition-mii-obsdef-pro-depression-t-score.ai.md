# MII ObsDef PRO Depression Domain T-Score - MII IG PRO v2027.0.0-rc.1

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII ObsDef PRO Depression Domain T-Score**

## ObservationDefinition: MII ObsDef PRO Depression Domain T-Score

-------

**German**

-------

Profile: [MII PR PRO Score Blueprint / Template](StructureDefinition-mii-pr-pro-score-blueprint.md) version: 2027.0.0-rc.1

**ArtifactVersion**: 2027.0.0-rc.1

**CQF Citation**: Riazy L, Grote M, Liegl G, Rose M, Fischer F. Cross-Sectional Reference Data From 29 European Countries for 6 Frequently Used Depression Measures. JAMA Network Open. 2025;8(6):e2517394

**category**: Survey

**code**: PROMIS emotional distress - depression - version 1.0 Tscore

**permittedDataType**: Quantity

**multipleResultsAllowed**: false

**method**: PROMIS Depression T-score metric derived from European Health Interview Survey (EHIS) wave 3 cross-cultural validation study

### QuantitativeDetails

| | |
| :--- | :--- |
| - | **Unit** |
| * | {score} |

> **qualifiedInterval****category**: reference range**range**: 41.8-51.5**context**: German general population - EHIS wave 3 (n=22,996): Mean 46.5 (SD 7.7), Median 45.5**appliesTo**: German general population - EHIS wave 3 (n=22,996)

> **qualifiedInterval****category**: reference range**range**: 38.06-50.4**context**: European male population - EHIS wave 3 (29 countries): Median 44.11**appliesTo**: European male population - EHIS wave 3 (29 countries), Male

> **qualifiedInterval****category**: reference range**range**: 40-52.76**context**: European female population - EHIS wave 3 (29 countries): Median 46.37**appliesTo**: European female population - EHIS wave 3 (29 countries), Female

> **qualifiedInterval****category**: reference range**range**: 39.11-51.68**context**: Overall European population median (IQR) - EHIS wave 3, 29 countries (n=287,530)**appliesTo**: Overall European population - EHIS wave 3, 29 countries (n=287,530)



## Resource Content

```json
{
  "resourceType" : "ObservationDefinition",
  "id" : "mii-obsdef-pro-depression-t-score",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-pr-pro-score-blueprint|2027.0.0-rc.1"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-version",
    "valueString" : "2027.0.0-rc.1"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-citation",
    "valueString" : "Riazy L, Grote M, Liegl G, Rose M, Fischer F. Cross-Sectional Reference Data From 29 European Countries for 6 Frequently Used Depression Measures. JAMA Network Open. 2025;8(6):e2517394"
  }],
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "survey"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "77861-3",
      "display" : "PROMIS emotional distress - depression - version 1.0 Tscore"
    },
    {
      "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-score-catalogue",
      "code" : "promis-depression",
      "display" : "PROMIS Depression Score"
    }]
  },
  "permittedDataType" : ["Quantity"],
  "multipleResultsAllowed" : false,
  "method" : {
    "text" : "PROMIS Depression T-score metric derived from European Health Interview Survey (EHIS) wave 3 cross-cultural validation study"
  },
  "quantitativeDetails" : {
    "unit" : {
      "coding" : [{
        "system" : "http://unitsofmeasure.org",
        "code" : "{score}",
        "display" : "{score}"
      }]
    }
  },
  "qualifiedInterval" : [{
    "category" : "reference",
    "range" : {
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-ex-pro-score-score-health-correlation",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/measure-improvement-notation",
            "code" : "decrease"
          }],
          "text" : "Higher scores indicate worse health (more depression symptoms)"
        }
      }],
      "low" : {
        "value" : 41.8
      },
      "high" : {
        "value" : 51.5
      }
    },
    "context" : {
      "text" : "German general population - EHIS wave 3 (n=22,996): Mean 46.5 (SD 7.7), Median 45.5"
    },
    "appliesTo" : [{
      "text" : "German general population - EHIS wave 3 (n=22,996)"
    }]
  },
  {
    "category" : "reference",
    "range" : {
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-ex-pro-score-score-health-correlation",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/measure-improvement-notation",
            "code" : "decrease"
          }],
          "text" : "Higher scores indicate worse health (more depression symptoms)"
        }
      }],
      "low" : {
        "value" : 38.06
      },
      "high" : {
        "value" : 50.4
      }
    },
    "context" : {
      "text" : "European male population - EHIS wave 3 (29 countries): Median 44.11"
    },
    "appliesTo" : [{
      "text" : "European male population - EHIS wave 3 (29 countries)"
    },
    {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v3-AdministrativeGender",
        "code" : "M",
        "display" : "Male"
      }]
    }]
  },
  {
    "category" : "reference",
    "range" : {
      "extension" : [{
        "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-ex-pro-score-score-health-correlation",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/measure-improvement-notation",
            "code" : "decrease"
          }],
          "text" : "Higher scores indicate worse health (more depression symptoms)"
        }
      }],
      "low" : {
        "value" : 40
      },
      "high" : {
        "value" : 52.76
      }
    },
    "context" : {
      "text" : "European female population - EHIS wave 3 (29 countries): Median 46.37"
    },
    "appliesTo" : [{
      "text" : "European female population - EHIS wave 3 (29 countries)"
    },
    {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v3-AdministrativeGender",
        "code" : "F",
        "display" : "Female"
      }]
    }]
  },
  {
    "category" : "reference",
    "range" : {
      "low" : {
        "value" : 39.11
      },
      "high" : {
        "value" : 51.68
      }
    },
    "context" : {
      "text" : "Overall European population median (IQR) - EHIS wave 3, 29 countries (n=287,530)"
    },
    "appliesTo" : [{
      "text" : "Overall European population - EHIS wave 3, 29 countries (n=287,530)"
    }]
  }]
}

```
