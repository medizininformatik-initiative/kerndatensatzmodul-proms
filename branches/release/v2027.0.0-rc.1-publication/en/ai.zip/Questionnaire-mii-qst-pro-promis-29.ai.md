# MII QST PRO PROMIS-29 (Adults) - MII IG PRO v2027.0.0-rc.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII QST PRO PROMIS-29 (Adults)**

## Questionnaire: MII QST PRO PROMIS-29 (Adults) (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/Questionnaire/mii-qst-pro-promis-29 | *Version*:2027.0.0-rc.1 |
| Active as of 2026-11-10 | *Computable Name*: |
| **Usage**: PROMIS (Patient-Reported Outcomes Measurement Information System) (https://www.healthmeasures.net/explore-measurement-systems/promis), PROMIS National Center Deutschland (CPCOR Charité) — Curator of the official German translations provided by PCOR-MII (https://cpcor.charite.de/promis_national_center_deutschland), PROMIS-29 Profile Documentation (https://www.healthmeasures.net/explore-measurement-systems/promis) | |
| **Copyright/Legal**: The FHIR Questionnaire resource (linkIds, extensions, score calculation logic, observation extraction definitions) is part of the MII PRO Module and is licensed under CC-BY 4.0.The PROMIS items contained herein (item text, response options, scoring algorithms, IRT parameters) are © 2008–2024 PROMIS Health Organization and PROMIS Cooperative Group. PROMIS® is a registered trademark. See https://www.healthmeasures.net for the upstream license.The official German translations are provided by PCOR-MII (Patient-Centered Outcomes Research within the Medizininformatik-Initiative) and curated by the PROMIS National Center Germany (CPCOR, Charité – Universitätsmedizin Berlin; head: Felix Fischer).Institutional use outside the PCOR-MII / MII context requires a usage request to CPCOR: https://cpcor.charite.de/promis_national_center_deutschland/nutzungsanfragenLOINC® codes are © Regenstrief Institute, Inc. and used under the LOINC license: https://loinc.org/license/ | |

 
PROMIS-29 Profile v2.1 - Comprehensive health-related quality of life assessment across 7 domains 

*  [Tree view](#tabs-tree) 
*  [Sample Rendering](#tabs-sample) 
*  [Form Logic](#tabs-logic) 

### Test this Questionnaire

### Responses for this Questionnaire

There are currently no QuestionnaireResponse instances for this Questionnaire defined in this IG.



## Resource Content

```json
{
  "resourceType" : "Questionnaire",
  "id" : "mii-qst-pro-promis-29",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-pr-pro-questionnaire|2027.0.0-rc.1"]
  },
  "language" : "en",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "natural",
      "display" : "Natural"
    }
  },
  {
    "extension" : [{
      "url" : "displayable",
      "valueBoolean" : true
    },
    {
      "url" : "collectable",
      "valueBoolean" : true
    },
    {
      "url" : "calculatable",
      "valueBoolean" : true
    },
    {
      "url" : "extractable",
      "valueBoolean" : true
    },
    {
      "url" : "domainAligned",
      "valueBoolean" : true
    }],
    "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-ex-pro-questionnaire-capabilities"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-library",
    "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/Library/mii-lib-pro-promis-29|2027.0.0-rc.1"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/variable",
    "valueExpression" : {
      "name" : "physicalFunctionRaw",
      "language" : "text/fhirpath",
      "expression" : "%resource.item.item.where(linkId.matches('^promis-pfa(11|21|23|53)$')).answer.value.weight().sum()"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/variable",
    "valueExpression" : {
      "name" : "anxietyRaw",
      "language" : "text/fhirpath",
      "expression" : "%resource.item.item.where(linkId.matches('^promis-edanx(01|40|41|53)$')).answer.value.weight().sum()"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/variable",
    "valueExpression" : {
      "name" : "depressionRaw",
      "language" : "text/fhirpath",
      "expression" : "%resource.item.item.where(linkId.matches('^promis-eddep(04|06|29|41)$')).answer.value.weight().sum()"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/variable",
    "valueExpression" : {
      "name" : "fatigueRaw",
      "language" : "text/fhirpath",
      "expression" : "%resource.item.item.where(linkId.matches('^promis-(hi7|an3|fatexp41|fatexp40)$')).answer.value.weight().sum()"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/variable",
    "valueExpression" : {
      "name" : "sleepRaw",
      "language" : "text/fhirpath",
      "expression" : "%resource.item.item.where(linkId.matches('^promis-(sleep109|sleep116|sleep20|sleep44)$')).answer.value.weight().sum()"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/variable",
    "valueExpression" : {
      "name" : "socialRaw",
      "language" : "text/fhirpath",
      "expression" : "%resource.item.item.where(linkId.matches('^promis-srpper(11-caps|18-caps|23-caps|46-caps)$')).answer.value.weight().sum()"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/variable",
    "valueExpression" : {
      "name" : "painInterferenceRaw",
      "language" : "text/fhirpath",
      "expression" : "%resource.item.item.where(linkId.matches('^promis-painin(9|22|31|34)$')).answer.value.weight().sum()"
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/Questionnaire/mii-qst-pro-promis-29",
  "version" : "2027.0.0-rc.1",
  "title" : "MII QST PRO PROMIS-29 (Adults)",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-11-10T20:27:35+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "PROMIS-29 Profile v2.1 - Comprehensive health-related quality of life assessment across 7 domains",
  "useContext" : [{
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus"
    },
    "valueReference" : {
      "display" : "PROMIS (Patient-Reported Outcomes Measurement Information System) (https://www.healthmeasures.net/explore-measurement-systems/promis)"
    }
  },
  {
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus"
    },
    "valueReference" : {
      "display" : "PROMIS National Center Deutschland (CPCOR Charité) — Curator of the official German translations provided by PCOR-MII (https://cpcor.charite.de/promis_national_center_deutschland)"
    }
  },
  {
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus"
    },
    "valueReference" : {
      "display" : "PROMIS-29 Profile Documentation (https://www.healthmeasures.net/explore-measurement-systems/promis)"
    }
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "The FHIR Questionnaire resource (linkIds, extensions, score calculation logic, observation extraction definitions) is part of the MII PRO Module and is licensed under CC-BY 4.0.\n\nThe PROMIS items contained herein (item text, response options, scoring algorithms, IRT parameters) are © 2008–2024 PROMIS Health Organization and PROMIS Cooperative Group. PROMIS® is a registered trademark. See https://www.healthmeasures.net for the upstream license.\n\nThe official German translations are provided by PCOR-MII (Patient-Centered Outcomes Research within the Medizininformatik-Initiative) and curated by the PROMIS National Center Germany (CPCOR, Charité – Universitätsmedizin Berlin; head: Felix Fischer).\n\nInstitutional use outside the PCOR-MII / MII context requires a usage request to CPCOR: https://cpcor.charite.de/promis_national_center_deutschland/nutzungsanfragen\n\nLOINC® codes are © Regenstrief Institute, Inc. and used under the LOINC license: https://loinc.org/license/",
  "code" : [{
    "system" : "http://loinc.org",
    "code" : "62337-1",
    "display" : "PROMIS item bank - 29 profile"
  },
  {
    "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-questionnaire-catalogue",
    "code" : "promis-promis29",
    "display" : "PROMIS-29 Questionnaire"
  }],
  "item" : [{
    "linkId" : "PROMIS-29.PhysicalFunction",
    "text" : "Physical Function",
    "_text" : {
      "extension" : [{
        "extension" : [{
          "url" : "lang",
          "valueCode" : "de"
        },
        {
          "url" : "content",
          "valueString" : "Körperliche Funktion"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/translation"
      }]
    },
    "type" : "group",
    "item" : [{
      "linkId" : "promis-pfa11",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61597-1",
        "display" : "Are you able to do chores such as vacuuming or yard work [PROMIS]"
      }],
      "text" : "Are you able to do chores such as vacuuming or yard work?",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Können Sie Hausarbeiten erledigen, z.B. Staubsaugen oder Gartenarbeit?"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13921-4",
          "display" : "Without any difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ohne jede Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13918-0",
          "display" : "With a little difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mit geringen Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13920-6",
          "display" : "With some difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mit einigen Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13919-8",
          "display" : "With much difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mit großen Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13912-3",
          "display" : "Unable to do",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Kann ich gar nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-pfa21",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61607-8",
        "display" : "Are you able to go up and down stairs at a normal pace [PROMIS]"
      }],
      "text" : "Are you able to go up and down stairs at a normal pace?",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Können Sie mit normaler Geschwindigkeit Treppen hoch- und runtergehen?"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13921-4",
          "display" : "Without any difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ohne jede Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13918-0",
          "display" : "With a little difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mit geringen Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13920-6",
          "display" : "With some difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mit einigen Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13919-8",
          "display" : "With much difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mit großen Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13912-3",
          "display" : "Unable to do",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Kann ich gar nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-pfa23",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61609-4",
        "display" : "Are you able to go for a walk of at least 15 minutes [PROMIS]"
      }],
      "text" : "Are you able to go for a walk of at least 15 minutes?",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Können Sie mindestens 15 Minuten lang spazieren gehen?"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13921-4",
          "display" : "Without any difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ohne jede Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13918-0",
          "display" : "With a little difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mit geringen Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13920-6",
          "display" : "With some difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mit einigen Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13919-8",
          "display" : "With much difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mit großen Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13912-3",
          "display" : "Unable to do",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Kann ich gar nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-pfa53",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61635-9",
        "display" : "Are you able to run errands and shop [PROMIS]"
      }],
      "text" : "Are you able to run errands and shop?",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Können Sie Besorgungen machen und einkaufen gehen?"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13921-4",
          "display" : "Without any difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ohne jede Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13918-0",
          "display" : "With a little difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mit geringen Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13920-6",
          "display" : "With some difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mit einigen Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13919-8",
          "display" : "With much difficulty",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mit großen Schwierigkeiten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13912-3",
          "display" : "Unable to do",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Kann ich gar nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    }]
  },
  {
    "linkId" : "PROMIS-29.Anxiety",
    "text" : "Anxiety",
    "_text" : {
      "extension" : [{
        "extension" : [{
          "url" : "lang",
          "valueCode" : "de"
        },
        {
          "url" : "content",
          "valueString" : "Angst"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/translation"
      }]
    },
    "type" : "group",
    "item" : [{
      "linkId" : "PROMIS-29.Anxiety.Description",
      "text" : "In the past 7 days…",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "In den letzten 7 Tagen:"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "display"
    },
    {
      "linkId" : "promis-edanx01",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61923-9",
        "display" : "I felt fearful in past 7 days [PROMIS]"
      }],
      "text" : "I felt fearful.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich fürchtete mich."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6270-8",
          "display" : "Never",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10044-8",
          "display" : "Often",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Oft"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Immer"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-edanx40",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61941-1",
        "display" : "I found it hard to focus on anything other than my anxiety in past 7 days"
      }],
      "text" : "I found it hard to focus on anything other than my anxiety.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich fand es schwer, auf etwas anderes zu achten als auf meine Angst."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6270-8",
          "display" : "Never",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10044-8",
          "display" : "Often",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Oft"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Immer"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-edanx41",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61942-9",
        "display" : "My worries overwhelmed me in past 7 days"
      }],
      "text" : "My worries overwhelmed me.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Meine Sorgen haben mich überwältigt."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6270-8",
          "display" : "Never",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10044-8",
          "display" : "Often",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Oft"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Immer"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-edanx53",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61949-4",
        "display" : "I felt uneasy in past 7 days"
      }],
      "text" : "I felt uneasy.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich fühlte mich unruhig."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6270-8",
          "display" : "Never",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10044-8",
          "display" : "Often",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Oft"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Immer"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    }]
  },
  {
    "linkId" : "PROMIS-29.Depression",
    "text" : "Depression",
    "_text" : {
      "extension" : [{
        "extension" : [{
          "url" : "lang",
          "valueCode" : "de"
        },
        {
          "url" : "content",
          "valueString" : "Depression"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/translation"
      }]
    },
    "type" : "group",
    "item" : [{
      "linkId" : "PROMIS-29.Depression.Description",
      "text" : "In the past 7 days…",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "In den letzten 7 Tagen:"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "display"
    },
    {
      "linkId" : "promis-eddep04",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61953-6",
        "display" : "I felt worthless in past 7 days [PROMIS]"
      }],
      "text" : "I felt worthless.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich fühlte mich wertlos."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6270-8",
          "display" : "Never",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10044-8",
          "display" : "Often",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Oft"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Immer"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-eddep06",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61955-1",
        "display" : "I felt helpless in past 7 days [PROMIS]"
      }],
      "text" : "I felt helpless.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich fühlte mich hilflos."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6270-8",
          "display" : "Never",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10044-8",
          "display" : "Often",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Oft"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Immer"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-eddep29",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61967-6",
        "display" : "I felt depressed in past 7 days [PROMIS]"
      }],
      "text" : "I felt depressed.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich fühlte mich niedergeschlagen."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6270-8",
          "display" : "Never",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10044-8",
          "display" : "Often",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Oft"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Immer"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-eddep41",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61973-4",
        "display" : "I felt hopeless in past 7 days [PROMIS]"
      }],
      "text" : "I felt hopeless.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich fühlte mich hoffnungslos."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6270-8",
          "display" : "Never",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10044-8",
          "display" : "Often",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Oft"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Immer"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    }]
  },
  {
    "linkId" : "PROMIS-29.Fatigue",
    "text" : "Fatigue",
    "_text" : {
      "extension" : [{
        "extension" : [{
          "url" : "lang",
          "valueCode" : "de"
        },
        {
          "url" : "content",
          "valueString" : "Erschöpfung"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/translation"
      }]
    },
    "type" : "group",
    "item" : [{
      "linkId" : "PROMIS-29.Fatigue.Description",
      "text" : "In the past 7 days…",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "In den letzten 7 Tagen:"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "display"
    },
    {
      "linkId" : "promis-hi7",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61878-5",
        "display" : "I feel fatigued during the past 7 days [PROMIS]"
      }],
      "text" : "I feel fatigued.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich bin erschöpft."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Überhaupt nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13863-8",
          "display" : "A little bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ein wenig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13909-9",
          "display" : "Somewhat",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mäßig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13902-4",
          "display" : "Quite a bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ziemlich"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13914-9",
          "display" : "Very much",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-an3",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61882-7",
        "display" : "I had trouble starting things because I was tired in past 7 days [PROMIS]"
      }],
      "text" : "I have trouble starting things because I am tired.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Es fällt mir schwer, etwas anzufangen, weil ich müde bin."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Überhaupt nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13863-8",
          "display" : "A little bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ein wenig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13909-9",
          "display" : "Somewhat",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mäßig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13902-4",
          "display" : "Quite a bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ziemlich"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13914-9",
          "display" : "Very much",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-fatexp41",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61865-2",
        "display" : "How run-down did you feel on average in past 7 days [PROMIS]"
      }],
      "text" : "How run-down did you feel on average?",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Wie ausgelaugt fühlten Sie sich im Allgemeinen?"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Überhaupt nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13863-8",
          "display" : "A little bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ein wenig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13909-9",
          "display" : "Somewhat",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mäßig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13902-4",
          "display" : "Quite a bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ziemlich"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13914-9",
          "display" : "Very much",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-fatexp40",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61864-5",
        "display" : "How fatigued were you on average in past 7 days [PROMIS]"
      }],
      "text" : "How fatigued were you on average?",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Wie erschöpft waren Sie im Allgemeinen?"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Überhaupt nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13863-8",
          "display" : "A little bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ein wenig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13909-9",
          "display" : "Somewhat",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mäßig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13902-4",
          "display" : "Quite a bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ziemlich"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13914-9",
          "display" : "Very much",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    }]
  },
  {
    "linkId" : "PROMIS-29.Sleep",
    "text" : "Sleep Disturbance",
    "_text" : {
      "extension" : [{
        "extension" : [{
          "url" : "lang",
          "valueCode" : "de"
        },
        {
          "url" : "content",
          "valueString" : "Schlafstörungen"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/translation"
      }]
    },
    "type" : "group",
    "item" : [{
      "linkId" : "PROMIS-29.Sleep.Description",
      "text" : "In the past 7 days…",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "In den letzten 7 Tagen:"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "display"
    },
    {
      "linkId" : "promis-sleep109",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61987-4",
        "display" : "My sleep quality was...in past 7 days [PROMIS]"
      }],
      "text" : "My sleep quality was...",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Meine Schlafqualität war ..."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9615-1",
          "display" : "Very poor",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr schlecht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA8969-3",
          "display" : "Poor",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Schlecht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA8968-5",
          "display" : "Fair",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mäßig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA8967-7",
          "display" : "Good",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Gut"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13913-1",
          "display" : "Very Good",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr gut"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-sleep116",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61986-6",
        "display" : "My sleep was refreshing in past 7 days [PROMIS]"
      }],
      "text" : "My sleep was refreshing.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Mein Schlaf war erfrischend."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Überhaupt nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13863-8",
          "display" : "A little bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ein wenig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13909-9",
          "display" : "Somewhat",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mäßig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13902-4",
          "display" : "Quite a bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ziemlich"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13914-9",
          "display" : "Very much",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-sleep20",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61998-1",
        "display" : "I had a problem with my sleep 7 days [PROMIS]"
      }],
      "text" : "I had a problem with my sleep.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich hatte Schlafprobleme."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Überhaupt nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13863-8",
          "display" : "A little bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ein wenig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13909-9",
          "display" : "Somewhat",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mäßig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13902-4",
          "display" : "Quite a bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ziemlich"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13914-9",
          "display" : "Very much",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-sleep44",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61999-9",
        "display" : "I had difficulty falling asleep in past 7 days [PROMIS]"
      }],
      "text" : "I had difficulty falling asleep.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Ich hatte Schwierigkeiten einzuschlafen."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Überhaupt nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13863-8",
          "display" : "A little bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ein wenig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13909-9",
          "display" : "Somewhat",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mäßig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13902-4",
          "display" : "Quite a bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ziemlich"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13914-9",
          "display" : "Very much",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    }]
  },
  {
    "linkId" : "PROMIS-29.Social",
    "text" : "Ability to Participate in Social Roles and Activities",
    "_text" : {
      "extension" : [{
        "extension" : [{
          "url" : "lang",
          "valueCode" : "de"
        },
        {
          "url" : "content",
          "valueString" : "Soziale Teilhabe"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/translation"
      }]
    },
    "type" : "group",
    "item" : [{
      "linkId" : "promis-srpper23-caps",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "76709-5",
        "display" : "I have trouble doing all of my usual work (include work at home) [PROMIS]"
      }],
      "text" : "I have trouble doing all of my usual work (include work at home).",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Es fällt mir schwer, meine gewohnte Arbeit zu erledigen (einschließlich der Arbeit zu Hause)."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6270-8",
          "display" : "Never",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA14747-2",
          "display" : "Usually",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Meistens"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Immer"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-srpper11-caps",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "75417-6",
        "display" : "I have trouble doing all of my regular leisure activities with others [PROMIS]"
      }],
      "text" : "I have trouble doing all of my regular leisure activities with others.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Es fällt mir schwer, allen meinen regelmäßigen Freizeitaktivitäten mit anderen nachzugehen."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6270-8",
          "display" : "Never",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA14747-2",
          "display" : "Usually",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Meistens"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Immer"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-srpper18-caps",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "76708-7",
        "display" : "I have trouble doing all of the family activities that I want to do [PROMIS]"
      }],
      "text" : "I have trouble doing all of the family activities that I want to do.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Es fällt mir schwer, allen Aktivitäten nachzugehen, die ich mit meiner Familie machen möchte."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6270-8",
          "display" : "Never",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA14747-2",
          "display" : "Usually",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Meistens"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Immer"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-srpper46-caps",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "76712-9",
        "display" : "I have trouble doing all of the activities with friends that I want to do [PROMIS]"
      }],
      "text" : "I have trouble doing all of the activities with friends that I want to do.",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Es fällt mir schwer, allen Aktivitäten nachzugehen, die ich mit Freunden machen möchte."
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6270-8",
          "display" : "Never",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Nie"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10066-1",
          "display" : "Rarely",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Selten"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA10082-8",
          "display" : "Sometimes",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Manchmal"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA14747-2",
          "display" : "Usually",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Meistens"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA9933-8",
          "display" : "Always",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Immer"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    }]
  },
  {
    "linkId" : "PROMIS-29.PainInterference",
    "text" : "Pain Interference",
    "_text" : {
      "extension" : [{
        "extension" : [{
          "url" : "lang",
          "valueCode" : "de"
        },
        {
          "url" : "content",
          "valueString" : "Schmerzbedingte Beeinträchtigung"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/translation"
      }]
    },
    "type" : "group",
    "item" : [{
      "linkId" : "PROMIS-29.PainInterference.Description",
      "text" : "In the past 7 days…",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "In den letzten 7 Tagen:"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "display"
    },
    {
      "linkId" : "promis-painin9",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61758-9",
        "display" : "How much did pain interfere with your day to day activities in past 7 days [PROMIS]"
      }],
      "text" : "How much did pain interfere with your day to day activities?",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Wie sehr beeinträchtigten Schmerzen Ihre Alltagsaktivitäten?"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Überhaupt nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13863-8",
          "display" : "A little bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ein wenig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13909-9",
          "display" : "Somewhat",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mäßig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13902-4",
          "display" : "Quite a bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ziemlich"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13914-9",
          "display" : "Very much",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-painin22",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61769-6",
        "display" : "How much did pain interfere with work around the home in past 7 days [PROMIS]"
      }],
      "text" : "How much did pain interfere with work around the home?",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Wie sehr beeinträchtigten Schmerzen Ihre häuslichen Tätigkeiten?"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Überhaupt nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13863-8",
          "display" : "A little bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ein wenig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13909-9",
          "display" : "Somewhat",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mäßig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13902-4",
          "display" : "Quite a bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ziemlich"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13914-9",
          "display" : "Very much",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-painin31",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61773-8",
        "display" : "How much did pain interfere with your ability to participate in social activities in past 7 days [PROMIS]"
      }],
      "text" : "How much did pain interfere with your ability to participate in social activities?",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Wie sehr beeinträchtigten Schmerzen Ihre Fähigkeit, an sozialen Aktivitäten teilzunehmen?"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Überhaupt nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13863-8",
          "display" : "A little bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ein wenig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13909-9",
          "display" : "Somewhat",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mäßig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13902-4",
          "display" : "Quite a bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ziemlich"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13914-9",
          "display" : "Very much",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    },
    {
      "linkId" : "promis-painin34",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61775-3",
        "display" : "How much did pain interfere with your household chores in past 7 days [PROMIS]"
      }],
      "text" : "How much did pain interfere with your household chores?",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Wie sehr beeinträchtigten Schmerzen Sie bei Ihrer Hausarbeit?"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "choice",
      "answerOption" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 1
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA6568-5",
          "display" : "Not at all",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Überhaupt nicht"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 2
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13863-8",
          "display" : "A little bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ein wenig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 3
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13909-9",
          "display" : "Somewhat",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Mäßig"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 4
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13902-4",
          "display" : "Quite a bit",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Ziemlich"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/itemWeight",
          "valueDecimal" : 5
        }],
        "valueCoding" : {
          "system" : "http://loinc.org",
          "code" : "LA13914-9",
          "display" : "Very much",
          "_display" : {
            "extension" : [{
              "extension" : [{
                "url" : "lang",
                "valueCode" : "de"
              },
              {
                "url" : "content",
                "valueString" : "Sehr"
              }],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }]
          }
        }
      }]
    }]
  },
  {
    "linkId" : "PROMIS-29.PainIntensity",
    "text" : "Pain Intensity",
    "_text" : {
      "extension" : [{
        "extension" : [{
          "url" : "lang",
          "valueCode" : "de"
        },
        {
          "url" : "content",
          "valueString" : "Schmerzintensität"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/translation"
      }]
    },
    "type" : "group",
    "item" : [{
      "linkId" : "PROMIS-29.PainIntensity.Description",
      "text" : "In the past 7 days…",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "In den letzten 7 Tagen:"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "display"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/minValue",
        "valueInteger" : 0
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/maxValue",
        "valueInteger" : 10
      }],
      "linkId" : "promis-global07",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "61583-1",
        "display" : "How would you rate your pain on average in past 7 days [PROMIS]"
      }],
      "text" : "How would you rate your pain on average?",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Wie würden Sie Ihre Schmerzen im Allgemeinen einschätzen?"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "integer"
    }]
  },
  {
    "linkId" : "PROMIS-29.Scores",
    "text" : "Domain Scores",
    "_text" : {
      "extension" : [{
        "extension" : [{
          "url" : "lang",
          "valueCode" : "de"
        },
        {
          "url" : "content",
          "valueString" : "Bereichs-Bewertungen"
        }],
        "url" : "http://hl7.org/fhir/StructureDefinition/translation"
      }]
    },
    "type" : "group",
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%physicalFunctionRaw"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-physical-function-raw",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "71960-9",
        "display" : "PROMIS-29 Physical function score"
      }],
      "text" : "PROMIS-29 Physical Function - Raw Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Körperliche Funktion - Rohwert"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.item.item.where(linkId.matches('^promis-pfa(11|21|23|53)$')).answer.count() = 4, iif(%physicalFunctionRaw=4, 22.5, iif(%physicalFunctionRaw=5, 26.6, iif(%physicalFunctionRaw=6, 28.9, iif(%physicalFunctionRaw=7, 30.5, iif(%physicalFunctionRaw=8, 31.9, iif(%physicalFunctionRaw=9, 33.2, iif(%physicalFunctionRaw=10, 34.4, iif(%physicalFunctionRaw=11, 35.6, iif(%physicalFunctionRaw=12, 36.7, iif(%physicalFunctionRaw=13, 37.9, iif(%physicalFunctionRaw=14, 39.2, iif(%physicalFunctionRaw=15, 40.5, iif(%physicalFunctionRaw=16, 41.9, iif(%physicalFunctionRaw=17, 43.5, iif(%physicalFunctionRaw=18, 45.5, iif(%physicalFunctionRaw=19, 48.3, iif(%physicalFunctionRaw=20, 57.0, {}))))))))))))))))), {})"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-physical-function-tscore",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "91721-1",
        "display" : "PROMIS physical function - version 2.0 T-score"
      }],
      "text" : "PROMIS-29 Physical Function - T-Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Körperliche Funktion - T-Score"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%anxietyRaw"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-anxiety-raw",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "71968-2",
        "display" : "PROMIS-29 Anxiety score"
      }],
      "text" : "PROMIS-29 Anxiety - Raw Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Angst - Rohwert"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.item.item.where(linkId.matches('^promis-edanx(01|40|41|53)$')).answer.count() = 4, iif(%anxietyRaw=4, 40.3, iif(%anxietyRaw=5, 48.0, iif(%anxietyRaw=6, 51.2, iif(%anxietyRaw=7, 53.7, iif(%anxietyRaw=8, 55.8, iif(%anxietyRaw=9, 57.7, iif(%anxietyRaw=10, 59.5, iif(%anxietyRaw=11, 61.4, iif(%anxietyRaw=12, 63.4, iif(%anxietyRaw=13, 65.3, iif(%anxietyRaw=14, 67.3, iif(%anxietyRaw=15, 69.3, iif(%anxietyRaw=16, 71.2, iif(%anxietyRaw=17, 73.3, iif(%anxietyRaw=18, 75.4, iif(%anxietyRaw=19, 77.9, iif(%anxietyRaw=20, 81.6, {}))))))))))))))))), {})"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-anxiety-tscore",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "77862-1",
        "display" : "PROMIS emotional distress - anxiety - version 1.0 Tscore"
      }],
      "text" : "PROMIS-29 Anxiety - T-Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Angst - T-Score"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%depressionRaw"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-depression-raw",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "71966-6",
        "display" : "PROMIS-29 Depression score"
      }],
      "text" : "PROMIS-29 Depression - Raw Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Depression - Rohwert"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.item.item.where(linkId.matches('^promis-eddep(04|06|29|41)$')).answer.count() = 4, iif(%depressionRaw=4, 41.0, iif(%depressionRaw=5, 49.0, iif(%depressionRaw=6, 51.8, iif(%depressionRaw=7, 53.9, iif(%depressionRaw=8, 55.7, iif(%depressionRaw=9, 57.3, iif(%depressionRaw=10, 58.9, iif(%depressionRaw=11, 60.5, iif(%depressionRaw=12, 62.2, iif(%depressionRaw=13, 63.9, iif(%depressionRaw=14, 65.7, iif(%depressionRaw=15, 67.5, iif(%depressionRaw=16, 69.4, iif(%depressionRaw=17, 71.2, iif(%depressionRaw=18, 73.3, iif(%depressionRaw=19, 75.7, iif(%depressionRaw=20, 79.4, {}))))))))))))))))), {})"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-depression-tscore",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "77861-3",
        "display" : "PROMIS emotional distress - depression - version 1.0 Tscore"
      }],
      "text" : "PROMIS-29 Depression - T-Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Depression - T-Score"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%fatigueRaw"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-fatigue-raw",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "71964-1",
        "display" : "PROMIS-29 Fatigue score"
      }],
      "text" : "PROMIS-29 Fatigue - Raw Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Erschöpfung - Rohwert"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.item.item.where(linkId.matches('^promis-(hi7|an3|fatexp41|fatexp40)$')).answer.count() = 4, iif(%fatigueRaw=4, 33.7, iif(%fatigueRaw=5, 39.7, iif(%fatigueRaw=6, 43.1, iif(%fatigueRaw=7, 46.0, iif(%fatigueRaw=8, 48.6, iif(%fatigueRaw=9, 51.0, iif(%fatigueRaw=10, 53.1, iif(%fatigueRaw=11, 55.1, iif(%fatigueRaw=12, 57.0, iif(%fatigueRaw=13, 58.8, iif(%fatigueRaw=14, 60.7, iif(%fatigueRaw=15, 62.7, iif(%fatigueRaw=16, 64.6, iif(%fatigueRaw=17, 66.7, iif(%fatigueRaw=18, 69.0, iif(%fatigueRaw=19, 71.6, iif(%fatigueRaw=20, 75.8, {}))))))))))))))))), {})"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-fatigue-tscore",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "77864-7",
        "display" : "PROMIS fatigue - version 1.0 Tscore"
      }],
      "text" : "PROMIS-29 Fatigue - T-Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Erschöpfung - T-Score"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%sleepRaw"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-sleep-raw",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "71956-7",
        "display" : "PROMIS-29 Sleep disturbance score"
      }],
      "text" : "PROMIS-29 Sleep Disturbance - Raw Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Schlafstörungen - Rohwert"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.item.item.where(linkId.matches('^promis-(sleep109|sleep116|sleep20|sleep44)$')).answer.count() = 4, iif(%sleepRaw=4, 32.0, iif(%sleepRaw=5, 37.5, iif(%sleepRaw=6, 41.1, iif(%sleepRaw=7, 43.8, iif(%sleepRaw=8, 46.2, iif(%sleepRaw=9, 48.4, iif(%sleepRaw=10, 50.5, iif(%sleepRaw=11, 52.4, iif(%sleepRaw=12, 54.3, iif(%sleepRaw=13, 56.1, iif(%sleepRaw=14, 57.9, iif(%sleepRaw=15, 59.8, iif(%sleepRaw=16, 61.7, iif(%sleepRaw=17, 63.8, iif(%sleepRaw=18, 66.0, iif(%sleepRaw=19, 68.8, iif(%sleepRaw=20, 73.3, {}))))))))))))))))), {})"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-sleep-tscore",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "77860-5",
        "display" : "PROMIS sleep disturbance - version 1.0 Tscore"
      }],
      "text" : "PROMIS-29 Sleep Disturbance - T-Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Schlafstörungen - T-Score"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%socialRaw"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-social-raw",
      "code" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-score-catalogue",
        "code" : "promis-29-social-function-raw",
        "display" : "PROMIS-29 Ability to Participate in Social Roles and Activities Raw Score"
      }],
      "text" : "PROMIS-29 Social Roles and Activities - Raw Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Soziale Teilhabe - Rohwert"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.item.item.where(linkId.matches('^promis-srpper(11-caps|18-caps|23-caps|46-caps)$')).answer.count() = 4, iif(%socialRaw=4, 27.5, iif(%socialRaw=5, 31.8, iif(%socialRaw=6, 34.0, iif(%socialRaw=7, 35.7, iif(%socialRaw=8, 37.3, iif(%socialRaw=9, 38.8, iif(%socialRaw=10, 40.5, iif(%socialRaw=11, 42.3, iif(%socialRaw=12, 44.2, iif(%socialRaw=13, 46.2, iif(%socialRaw=14, 48.1, iif(%socialRaw=15, 50.0, iif(%socialRaw=16, 51.9, iif(%socialRaw=17, 53.7, iif(%socialRaw=18, 55.8, iif(%socialRaw=19, 58.3, iif(%socialRaw=20, 64.2, {}))))))))))))))))), {})"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-social-tscore",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "77854-8",
        "display" : "PROMIS ability to participate in social roles and activities - version 2.0 Tscore"
      }],
      "text" : "PROMIS-29 Social Roles and Activities - T-Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Soziale Teilhabe - T-Score"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%painInterferenceRaw"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-pain-interference-raw",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "71962-5",
        "display" : "PROMIS-29 Pain interference score"
      }],
      "text" : "PROMIS-29 Pain Interference - Raw Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Schmerzbedingte Beeinträchtigung - Rohwert"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{score}",
          "display" : "{score}"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.item.item.where(linkId.matches('^promis-painin(9|22|31|34)$')).answer.count() = 4, iif(%painInterferenceRaw=4, 41.6, iif(%painInterferenceRaw=5, 49.6, iif(%painInterferenceRaw=6, 52.0, iif(%painInterferenceRaw=7, 53.9, iif(%painInterferenceRaw=8, 55.6, iif(%painInterferenceRaw=9, 57.1, iif(%painInterferenceRaw=10, 58.5, iif(%painInterferenceRaw=11, 59.9, iif(%painInterferenceRaw=12, 61.2, iif(%painInterferenceRaw=13, 62.5, iif(%painInterferenceRaw=14, 63.8, iif(%painInterferenceRaw=15, 65.2, iif(%painInterferenceRaw=16, 66.6, iif(%painInterferenceRaw=17, 68.0, iif(%painInterferenceRaw=18, 69.7, iif(%painInterferenceRaw=19, 71.6, iif(%painInterferenceRaw=20, 75.6, {}))))))))))))))))), {})"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-observationExtract",
        "valueBoolean" : true
      }],
      "linkId" : "promis-29-pain-interference-tscore",
      "code" : [{
        "system" : "http://loinc.org",
        "code" : "77865-4",
        "display" : "PROMIS pain interference - version 1.0 Tscore"
      }],
      "text" : "PROMIS-29 Pain Interference - T-Score",
      "_text" : {
        "extension" : [{
          "extension" : [{
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "PROMIS-29 Schmerzbedingte Beeinträchtigung - T-Score"
          }],
          "url" : "http://hl7.org/fhir/StructureDefinition/translation"
        }]
      },
      "type" : "decimal",
      "readOnly" : true
    }]
  }]
}

```
