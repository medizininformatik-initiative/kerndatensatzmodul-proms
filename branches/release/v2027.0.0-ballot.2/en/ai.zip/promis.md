# PROMIS - MII IG PRO v2027.0.0-ballot.2

* [**Table of Contents**](toc.md)
* [**PRO Library**](pro-library.md)
* **PROMIS**

## PROMIS

The [Patient-Reported Outcomes Measurement Information System (PROMIS)](https://www.healthmeasures.net/explore-measurement-systems/promis) is an IRT-based measurement system developed by the US National Institutes of Health (NIH) for the standardized assessment of patient-reported outcomes. PROMIS instruments are internationally validated and yield T-Scores (Mean=50, SD=10 of the US general population) that are comparable across instruments and populations.

PROMIS instruments exist in various configurations:

| | | |
| :--- | :--- | :--- |
| **Multi-Domain Instrument** | Captures multiple health domains in a single questionnaire | [PROMIS-29](promis-29.md) |
| **Single-Domain Short Form** | Focuses on a single domain with a small number of items | PROMIS Physical Function SF 4a,[PROMIS Depression SF 4a](promis-depression.md) |
| **Item Bank** | Complete item pool for a domain, for CAT or custom assembly | PROMIS Depression Item Bank (future) |

### Implemented Instruments

#### PROMIS-29 Profile v2.1

Multi-domain instrument for assessing health-related quality of life across 7 domains (Physical Function, Anxiety, Depression, Fatigue, Sleep Disturbance, Social Function, Pain Interference) plus pain intensity.

**–> [Detailed documentation and preview](promis-29.md)**

#### PROMIS Depression Short Form 4a

Single-domain short form for assessing depression symptoms with 4 items from the PROMIS Depression Item Bank. Serves as an exemplary implementation of single-domain PROMIS instruments.

**–> [Detailed documentation and preview](promis-depression.md)**

#### PROMIS Scale v1.2 – Global Health

Ten items (Global01–Global10) on global physical and mental health yielding the Global Physical Health and Global Mental Health raw scores (4–20 each). Canonical full form for the PCOR-MII subset Global01/Global02/Global07; German translation so far only for these three items (`status = draft`).

**–> [Detailed documentation](promis-global-health.md)**

#### PROMIS Physical Function (Planned)

Exemplary single-domain instrument for the physical function domain. Planned as a reference implementation for single-domain PROMIS instruments with full score calculation and Observation extraction.

#### Licensing & Copyright

PROMIS instruments are free to use, but their use requires a usage agreement with the rights holders. Distribution is organised regionally: for projects in the DACH region, the **CPCOR (Charité)** — the PROMIS National Center Germany — distributes the validated German instruments; multinational projects obtain instruments through **HealthMeasures**. The attribution in this module is layered accordingly: the MII owns the FHIR structures, the PROMIS Health Organization owns the item wordings, the German translations come from the PCOR-MII master files, and the LOINC codes follow LOINC's terms of use. The module ships the items with this layered attribution; adopters running PROMIS instruments productively conclude the usage agreement themselves.

