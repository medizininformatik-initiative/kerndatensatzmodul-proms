# Translation Information - MII IG PRO v2027.0.0-ballot.2

* [**Table of Contents**](toc.md)
* **Translation Information**

## Translation Information

Dieser Implementation Guide ist in mehreren Sprachen verfügbar:

* **Englisch** (Primärsprache)
* **Deutsch** (Übersetzung)

Die Sprache kann über den Sprachumschalter in der oberen Navigationsleiste gewechselt werden.

### Übersetzungsansatz

Die Primärsprache dieses IG ist Englisch. Deutsche Übersetzungen werden für alle narrativen Seiten und Profil-Einleitungen bereitgestellt. FHIR-Ressourcendefinitionen (Profile, Extensions, Terminologien) verwenden englische Elementnamen gemäß FHIR-Konventionen, mit deutschen Beschreibungen wo zutreffend.

### Übersetzungen beitragen

Übersetzungsdateien werden in `input/translations/de/` gepflegt. Um Übersetzungen beizutragen oder zu verbessern, erstellen Sie bitte einen Pull Request im [GitHub-Repository](https://github.com/medizininformatik-initiative/kerndatensatzmodul-proms).

