#  - MII IG PRO v2026.4.1

## CodeSystem: CodeSystem 

### Testpläne

**Für das Artefakt mii-qst-pro-eortc-qlq-c30-variant-b_eortc-qlq-c30-cs-b CodeSystem sind derzeit keine TestPlans verfügbar.**

### Testskripte

**Für das Artefakt mii-qst-pro-eortc-qlq-c30-variant-b_eortc-qlq-c30-cs-b CodeSystem sind derzeit keine TestScripts verfügbar.**

