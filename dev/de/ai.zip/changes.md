# Changelog - MII IG PRO v2026.6.0

## Changelog

Diese Seite dokumentiert die Änderungen zwischen den Versionen des MII PRO-Moduls.

**Version: 2026.6.0**

Datum: 2026-09-01 (in Vorbereitung)

Minor-Release — **sechs neue Instrumente** des PCOR-MII-PSS-Sets (Persistent Somatic Syndrome), eine neue geteilte Antwortskala und eine präzisierte Konvention zur Display-Sprache. Keine Breaking Changes an bestehenden Ressourcen.

## Neue Instrumente

| | | | |
| :--- | :--- | :--- | :--- |
| **SCOFF**(Morgan et al. 1999) | 5 | binär (SNOMED CT) | Summe 0-5 |
| **WI-7 / Whiteley-7**(Fink et al. 1999) | 7 | binär (SNOMED CT) | Summe 0-7 |
| **PC-PTSD**(Prins et al. 2003) | 4 | binär (SNOMED CT) | Summe 0-4 |
| **SSD-12**(Toussaint et al. 2016) | 12 | 5-stufig, eigenes CodeSystem | Summe 0-48 |
| **ISR-Z**(Tritt et al. 2008) | 3 | 5-stufig, eigenes CodeSystem | **Mittelwert**0-4 |
| **EURONET-SOMA**(Rief et al. 2017) | 2 | NRS 0-10 | kein Score (Einzelitems) |

Alle Item-Texte stammen aus dem PCOR-MII Item Level Dictionary und wurden zeichengenau gegen diese Quelle geprüft. Alle Beispiel-Scores sind aus den `ordinalValue`-Gewichten nachgerechnet.

## Added: geteilte Ja/Nein-Antwortskala

Neu ist das RuleSet `YesNoAnswerOptions` (`input/fsh/rulesets/answer-scales.fsh`) für generische Ja/Nein-Antworten. Es verwendet **SNOMED CT `373066001` (Yes) / `373067005` (No)** gemäß der Empfehlung des TC Terminologien (HL7 Deutschland / Interop Council) — statt eines selbstdefinierten MII-CodeSystems, das standardisierte Terminologie verdoppeln würde.

Da SNOMED-Konzepten keine `ordinalValue`-Property angehängt werden kann, nutzen diese Instrumente **inline `answerOption`** statt `answerValueSet`. Damit tragen die Antworten in QuestionnaireResponses eine terminologisch eindeutige Kodierung mit `system` und `code` statt systemloser Integer.

## Präzisiert: Display-Sprache in Antwort-CodeSystems

Der `display`-Wert eines Antwortkonzepts steht in der **Sprache des Fragebogens**; weitere Sprachen werden als `designation` geführt. Das ist keine Stilfrage: In einer Ressource mit `language = #de` verlangt der FHIR-Validator den deutschen Display im `valueCoding`. Steht dort der englische, schlägt die gesamte `answerValueSet`-Prüfung fehl — mit der irreführenden Folgemeldung **"Der angegebene Wert ist nicht in den im Fragebogen gesetzten options value set enthalten"**, die auf ein Terminologie-Problem hindeutet, das gar nicht existiert.

## Hinweise zur Modellierung

* **ISR-Z bildet einen Mittelwert, keine Summe.** Das ISR definiert Skalenwerte als Mittelwerte der Items (Tritt et al. 2008); die FHIRPath-Berechnung nutzt entsprechend `.avg()` statt `.sum()`, Wertebereich 0-4.
* **Sprachwahl je Instrument.** `language` folgt der Originalsprache des Instruments: SCOFF, WI-7 und EURONET-SOMA sind EN-primär mit deutscher Übersetzung, PC-PTSD, SSD-12 und ISR-Z DE-primär. Wo keine validierte Originalfassung belegbar war, wurde bewusst **keine** Übersetzung erfunden.
* **Cut-offs bleiben Dokumentation.** Publizierte Trennwerte (SCOFF >= 2, PC-PTSD >= 3) sind als `qualifiedInterval` in den ObservationDefinitions dokumentiert, aber nicht als ausführbare Interpretationslogik ausgeliefert.
* **Terminologie.** Für keines der sechs Instrumente führen LOINC oder SNOMED CT einen Code des Instruments selbst (geprüft gegen LOINC 2.83 und SNOMED International 2026-05-01); die Kodierung erfolgt über den MII-Questionnaire-Katalog.

**Version: 2026.5.2**

Datum: 2026-07-27 (in Vorbereitung)

Patch-Release (Fix-Only) — **keine** Änderungen an Instrumenten, Profilen oder Terminologie. Empfohlen für alle, die 2026.4.0–2026.5.1 einsetzen.

## Bugfix: Import scheitert in HAPI FHIR (Server startet nicht)

Die Packages **2026.4.0–2026.5.1** ließen sich nicht in HAPI FHIR laden — der Server brach beim Start mit folgendem Fehler ab:

```
HAPI-0838: ConceptMap[url='…/ConceptMap/mii-cm-pro-bdi-ii-to-promis-depression-observation']
           contains at least one group without a value in ConceptMap.group.source
→ HAPI-1286: Error installing IG … → Application run failed → Unable to start web server

```

* **Ursache:** Die mit 2026.4.0 eingeführte ConceptMap `mii-cm-pro-bdi-ii-to-promis-depression-observation` war ein unvollständiger Stub (nur 2 von 64 PROsetta-Stone-Stützstellen, `group` ohne `source`/`target`-CodeSystem). HAPI weist ConceptMaps ohne `group.source` beim Package-Install ab und bricht den Serverstart ab. 2026.3.0 enthielt noch **keine** ConceptMap und lud daher fehlerfrei.
* **Fix:** Der ConceptMap-Stub wurde aus Quelle und Package entfernt. Die BDI-II→PROMIS-Depression-T-Score-Umrechnung bleibt als vollständiger FHIRPath-Crosswalk im BDI-II-Questionnaire erhalten; eine CQL-Library-Lösung ist für 2027 geplant.
* **Verifiziert:** 2026.5.2 wurde in HAPI FHIR (v7.6.0) getestet und startet fehlerfrei; die verbleibende ConceptMap `mii-cm-pro-phq-9-linkid-migration` wird korrekt installiert (sie trägt `sourceScope`/`targetScope`).

## Package-Hygiene (nebenbei behoben)

* Removed: Drei versehentlich mitgepackte IG-Publisher-Lifecycle-Artefakte (`onLoad-ig-working.json`, `onLoad-ig-updated.json`, `onGenerate-ig-working.json` — dreifache Kopie der `ImplementationGuide` mit identischer Canonical-URL) werden im Firely-Bake-Build jetzt herausgefiltert (`onLoad-*`/`onGenerate-*`/`onCheck-*`), ebenso defensiv macOS-Dateien (`._*`, `.DS_Store`). Kein HAPI-Startup-Blocker, aber unsauber im Package.
* Fixed: Einheitliche Versionierung — alle Conformance-Ressourcen tragen durchgängig `2026.5.2`. Zuvor enthielten ausgelieferte Packages gemischte Versionsstände (teils bis `2026.0.0`), weil `fsh-generated` nicht bei jedem Version-Bump regeneriert wurde.

**Version: 2026.5.1**

Datum: 2026-07-13 (released, Tag `v2026.5.1`, GitHub-Release + Package)

Patch-Release auf 2026.5.0.

## Migration & Breaking Changes

* **`BREAKING` (nachgezogen aus 2026.5.0):** Die PHQ-9-Item-linkIds wurden in 2026.5.0 vom Schema `phq-phq9-q01…q10` auf den gemeinsamen PHQ-D-Block-Namespace (`phq-phq2a…i` + `phq-phq9-difficulty`) umgestellt. Bestehende PHQ-9-`QuestionnaireResponse`s mit alten linkIds matchen den Questionnaire ab 2026.5.0 nicht mehr.
* Added: **ConceptMap `mii-cm-pro-phq-9-linkid-migration`** — bildet die alten PHQ-9-linkIds 1:1 auf die neuen ab (10 Items: `phq-phq9-q01…q09` → `phq-phq2a…i`, `phq-phq9-q10` → `phq-phq9-difficulty`), zur Migration bestehender Antworten. Die berechneten Items (`phq-phq9-score-total`, `phq-phq9-promis-tscore`) wurden nicht umbenannt.

**Version: 2026.5.0**

Datum: 2026-07-13 (released, Tag `v2026.5.0`, GitHub-Release + Package)

Minor-Release: zwei neue Instrumente (**WHODAS 2.0 12-Item** und **PHQ-15**), Aufbau einer gemeinsamen **PHQ-D-Itembank** (PHQ-9/PHQ-15), einheitliche **MII-Score-Codierung** über alle Score-ObsDefs und eine **CI-Verbesserung** (ValueSet-Expansion), die die answerValueSet-Antwortvalidierung dauerhaft korrigiert.

## Neue Instrumente

* Added: **WHODAS 2.0 12-Item (Selbstauskunft)** — WHO Disability Assessment Schedule 2.0, 12 Items über 6 ICF-Domänen, 30-Tage-Recall, 5-stufige Skala (0–4). Englisch primär mit deutschen Translations (validierte PCOR-MII-Wortlaute). Antworten via `answerValueSet` (`mii-vs-pro-whodas-12-answer-list`) mit ordinalValue-Gewichten auf den CodeSystem-Konzepten. **Einschränkungsscore** `mii-obsdef-pro-score-whodas12-simple-sum` (0–48, SNOMED `715823002`, MII-Katalog `whodas12-simple-sum`, höher = mehr Beeinträchtigung). Inkl. Beispiel-QuestionnaireResponse + Score-Observation und IG-Seite. 
* **Lizenz:** WHODAS 2.0 © WHO 2010. Die Bedingungen sind maschinenlesbar als `copyright` auf Questionnaire und CodeSystem hinterlegt: kostenfreie Kliniker-Eigennutzung; elektronische/Datenerfassungs-Nutzung erfordert eine (für nicht-kommerzielle Nutzung kostenlose) WHO-Nutzungsvereinbarung; Übersetzungen erfordern WHO-Genehmigung; MII-FHIR-Inhalte CC0, WHODAS-Itemtext © WHO.
 
* Added: **PHQ-15** (Gesundheitsfragebogen für Patienten, somatische Symptomlast, PHQ-D) — 15 Items, 4-Wochen-Recall, 3-stufige Skala (0–2). Englisch primär mit deutschen Translations (PHQ-D, Löwe et al. 2002). Antworten via `answerValueSet` mit ordinalValue-Gewichten. Score `mii-obsdef-pro-score-phq-15` (0–30, LOINC `70273-8`) inkl. **Schweregrad-Kategorien** (Kroenke et al. 2002: 0–4 / 5–9 / 10–14 / 15–30) als `qualifiedInterval`-Reference-Ranges. Inkl. IG-Seite. Lizenz: frei verfügbar (public domain), PHQ-D.

## Architektur: PHQ-D-Itembank

* Changed: **PHQ-9 und PHQ-15 nutzen ein gemeinsames PHQ-D-Block-LinkId-Schema** (`phq-phq…`). Die in beiden Instrumenten enthaltenen Items (Schlaf `phq-phq2c`, Müdigkeit `phq-phq2d`) teilen sich denselben linkId — Grundlage für item-basiertes Scoring über Instrumente hinweg.
* Changed: PHQ-15 auf `answerValueSet` + CodeSystem-`ordinalValue` (EN-first) umgestellt; `copyright`/Lizenz-Status auf PHQ-Ressourcen explizit gesetzt.

## Scoring & Terminologie

* Changed: **MII-Katalog-Code (`code.coding[mii]`) auf allen Score-ObservationDefinitions** ergänzt (PROMIS-29 ×8, PROMIS Cognitive Function SF4a, Depression-T-Score, BDI-II, PHQ-9, PHQ-15) — zusätzlich zu LOINC/SNOMED, einheitlich über den MII-Score-Catalogue abfragbar (zuvor bereits EQ-5D/EORTC/DASS-21/PRO-CTCAE).

## Technische Verbesserungen

* Changed: **CI** — `expand-valuesets.js` läuft jetzt nach SUSHI im IG-Build (`ig-publisher.yml`) und schreibt `vs.expansion` aus lokalen CodeSystems. Dadurch kann der Validator die MII-kontrollierten `answerValueSet`-Antwortskalen auflösen; die zuvor gemeldeten „Wert nicht in den angegebenen Optionen"-Findings auf Beispiel-QuestionnaireResponses entfallen (PHQ-15, WHODAS und künftige answerValueSet-Instrumente).

**Version: 2026.4.1**

Datum: 2026-06-15 (released, Tag `v2026.4.1`)

Patch-Release auf v2026.4.0: behebt fehlendes Versions-Metadatum auf den 3 EQ-5D-5L ObservationDefinitions, das beim Bake von v2026.4.0 entdeckt wurde.

FHIR-Ressourcen:

* Fixed: `mii-obsdef-pro-score-eq5d5l-index`, `mii-obsdef-pro-score-eq5d5l-profile`, `mii-obsdef-pro-score-eq5d5l-vas` – `* insert ObsDefVersion` und `* insert MetaProfile(...)` ergänzt (vorher fehlten beide RuleSets, dadurch keine `artifact-version`-Extension im Package und kein `meta.profile`-Eintrag mit Canonical-Version). Andere ObsDefs (PHQ-9, BDI-II, PROMIS-29, DASS-21, PRO-CTCAE, EORTC QLQ-C30, Depression T-Score) hatten beide RuleSets bereits.

Verifikation:

* Vorher: 36 ObsDefs mit artifact-version=2026.4.0, 3 ohne (EQ-5D)
* Nachher: 39 ObsDefs mit artifact-version=2026.4.1

**Version: 2026.4.0**

Datum: 2026-06-14 (released, Tag `v2026.4.0`)

Zwei thematische Erweiterungen in einem Release: **PROMIS-Konsolidierung** (PROMIS-16 PROPr, Wording-Migration, Copyright-Modell) und **Symptom-Screening für die onkologische und palliative Versorgung** (MIDOS2 + PRO-CTCAE Onkologisches Basisscreening).

## Symptom-Screening (MIDOS2 + PRO-CTCAE Onkologisches Basisscreening)

PRO-Instrumente:

* Added: **MIDOS2** (Minimal Documentation System for Patients in Palliative Care, DGP) – Palliativ-Symptom-Screening mit 13 Items (11 Symptome auf DGP-4-stufiger Severity-Skala, Wohlbefinden auf 4-stufiger Skala, Freitext)
* Added: **PRO-CTCAE Onkologisches Basisscreening** (DKG) – Subset des NCI PRO-CTCAE mit MIDOS2-äquivalenter Symptomauswahl, 10 AEs / 23 Items, Depressivität via PRO-CTCAE-konformes Mehrfach-Mapping (#55 Discouraged + #56 Sad), Angst+Anspannung via #54 Anxiety

Architektur:

* Added: PRO-CTCAE Complete als Master-Itembank, Derivate via `derivedFrom`
* Added: Catalogue-Einträge `midos-midos2` und `proctcae-onkologisches-basisscreening`

Terminologie & Mapping:

* Added: MIDOS2 CodeSystem mit DGP-4-stufiger Severity-Skala (keine/leichte/mittlere/starke)
* Added: MIDOS2 separate Wohlbefinden-Skala (sehr gut/eher gut/eher schlecht/sehr schlecht)
* Added: SNOMED-Properties auf MIDOS2 Item-Codes (wo eindeutig; Verifikation via Snowstorm ausstehend)
* Added: MIDOS2 ↔ PRO-CTCAE Item-Level Mapping (11 AEs, 23 Items)
* Verified: PRO-CTCAE Item-Wordings gegen NCI-Originaldokument (EN/DE)
* Identified: Diskrepanzen #27 Hair Loss + #59 Vaginal Discharge (int → amt) – dokumentiert

IG-Dokumentation:

* Added: `midos2.md` – Überblick, Skalen, Score-Berechnung, Mapping zu Onkologischem Basisscreening, Literatur
* Added: `proms-onkologisches-basisscreening.md` – PRO-CTCAE-basierte Symptomauswahl, Skalen, Composite Grading, MIDOS-Mapping
* Added: Beide Seiten als Unterseiten der PRO Library in `sushi-config.yaml` registriert

Beispiele:

* Added: `mii-exa-pro-midos2-response` – Palliativpatient mit moderater Symptomlast (Summe 19/33)
* Added: `mii-exa-pro-pro-ctcae-onkologisches-basisscreening-response` – Onkologischer Patient unter Chemotherapie

Qualitätssicherung:

* Status: Beide Instrumente `draft` + `experimental`
* TODO: MIDOS2 Source-Verifikation gegen Stiel et al. 2010/2012 (Bead `5jd`)

Quellen:

* NCI PRO-CTCAE Item Library v1.0 (EN/DE)
* Stiel et al. 2010/2012 (MIDOS2, Verifikation ausstehend)

## PROMIS-Konsolidierung

PROMIS-Konsolidierung: vollständige Implementierung des PROMIS-16-Profile v2.1 (PROPr), Wording-Migration der bestehenden PROMIS-29- und Cognitive-Function-SF4a-Questionnaires auf die offizielle deutsche PROMIS-Quelle, und Einführung eines mehrschichtigen Copyright-/Lizenz-Modells für alle PROMIS-Ressourcen.

PRO-Instrumente:

* Added: **PROMIS-16 Profile v2.1 (PROPr)** – ultrakurzes Multi-Domain-Instrument mit 16 Items über 8 Domänen (inkl. Cognitive Function); alle Items mit offiziellen deutschen Wordings aus dem PHO PDF "PROMIS-16 Profile v2.1 (PROPr), German, 20 September 2024" implementiert. Score-Berechnung (PROPr Utility + 8 Domain T-Scores) bewusst auf spätere Version verschoben (CQL Library `mii-lib-promis-16` geplant)
* Fixed: **PROMIS-29 Wording-Migration** – 25 Item-Texte in `mii-qst-pro-promis-29` und `mii-qst-pro-promis-29-de` an die offiziellen deutschen Wordings angepasst (vorher: AI-generierte/LOINC-Fragment-Übersetzungen). Quellen-Hierarchie: das PHO PDF "PROMIS-29 Profile v2.1 German, 06 April 2020" ist normativ; das PCOR-MII Master Item-Level Dictionary (DZPG-3-Entities) dient als sekundärer Cross-Check
* Fixed: **PROMIS-29 Pain Interference Verb-Tempus** – 4 Items (`promis-painin9`, `promis-painin22`, `promis-painin31`, `promis-painin34`) von Präsens "beeinträchtigen" auf Präteritum "beeinträchtigten" umgestellt, konform mit PHO PDF und mit der eigenen Section-Description "In den letzten 7 Tagen: Inwieweit beeinträchtigten Schmerzen…" (vorheriger Stand basierte auf PCOR-MII Master Wording, das hier vom PHO-Original abweicht)
* Fixed: **PROMIS-29 Antwortskalen** – 5 Items (HI7, AN3, Sleep116, Sleep20, Sleep44) von der Frequency-Skala auf die Intensity-Skala umgestellt; LOINC-Code-Tausch LA6270-8/LA10066-1/LA10082-8/LA10044-8/LA9933-8 → LA6568-5/LA13863-8/LA13909-9/LA13902-4/LA13914-9
* Fixed: **PROMIS-29 SRPPER23-CaPS** – falscher LOINC-Code 62041-9 ("satisfied with work") ersetzt durch 76709-5 ("trouble doing usual work") mit passendem deutschem Text (PCOR-MII Master enthält hier einen Tippfehler "erldige", unsere Version "erledigen" folgt PHO PDF)
* Changed: **PROMIS Cognitive Function SF 4a** – Copyright-RuleSet eingefügt (Wordings waren bereits PHO-konform und bleiben unverändert)

Architektur & Lizenzierung:

* Added: Zentrales RuleSet `PROMIS_Copyright_DE` (`input/fsh/rulesets/promis-copyright.fsh`) mit Schichten-Attribution für alle PROMIS-Questionnaires: 
1. FHIR-Resource-Struktur © MII (CC-BY 4.0)
1. PROMIS-Items © PROMIS Health Organization (Northwestern University)
1. Offizielle deutsche Übersetzungen bereitgestellt durch PCOR-MII, kuratiert durch PROMIS National Center Deutschland (CPCOR Charité, Leitung Felix Fischer)
1. LOINC-Codes © Regenstrief Institute
 
* Added: `publisher`, `copyright`, `useContext` (PROMIS + CPCOR) und `contact` (CPCOR-Nutzungsanfrage) auf allen PROMIS-Questionnaire-Instanzen
* Added: Neue ValueSet `MII_VS_PRO_PROMIS_Intensity_Response_Scale` (LOINC LL1024-0: Not at all/A little bit/Somewhat/Quite a bit/Very much mit deutschen Designationen)
* Clarified: `mii-qst-pro-promis-29-de` ist nur eine Darstellungsvariante (DE-primary für Renderer, die die `translation`-Extension nicht auswerten); inhaltlich identisch zur EN-primären Hauptversion `mii-qst-pro-promis-29`, die maßgeblich ist

IG-Dokumentation:

* Added: `input/pagecontent/promis-16.md` – Übersicht, Capabilities, PROPr-Methodik (3-Stufen), Item-Überlapp mit PROMIS-29, Vergleichstabelle, Lizenzierungs-Abschnitt
* Added: `implementation-guides/.../PROMIS/PROMIS-16.page.md` – Simplifier-Seite mit Vorschau/Tree/JSON/XML-Tabs
* Added: PROMIS-16 in `sushi-config.yaml` Menü und Simplifier-`toc.yaml` registriert
* Added: Zentrale "Lizenzierung & Urheberrecht"-Sektion in `input/pagecontent/promis.md` mit 4-Schichten-Tabelle und CPCOR-Nutzungsanfrage-Link
* Added: Hinweis auf der PROMIS-29-Seite (input + Simplifier), dass die DE-Variante nur zur Darstellung dient und nicht als eigenständige Implementierung gepflegt wird

Tooling:

* Added: Skill `.claude/skills/extract-qst-translations/` – jq-basierter Extraktor für Item-Texte und Translation-Extensions aus generierten Questionnaire-JSONs; inkl. automatischem Diff gegen PCOR-MII Master-Referenz. Verifikation aller PROMIS-Wording-Änderungen via `MATCH/DIFF`-Counter
* Added: `.gitignore`-Schutz für die Master-Referenz-TSV und den beads-credential-key

Verifikation:

* PROMIS-29 gegen PHO PDF (normativ): alle 29 Items wortgleich nach den PAININ4-Tempus-Fixes
* PROMIS-29 gegen PCOR-MII Master (sekundär): MATCH=24, DIFF=5 – 4 davon sind die bewussten PAININ-Präteritum-Fixes nach PHO, 1 ist der bekannte Master-Tippfehler "erldige" bei SRPPER23
* PROMIS-16 gegen PCOR-MII Master: MATCH=15, DIFF=0
* PROMIS Cognitive Function SF 4a gegen PCOR-MII Master: MATCH=4, DIFF=0

**Version: 2026.3.0**

Datum: 2026-05-08 (released, Tag `v2026.3.0`, noch nicht zurück in dev gemerged)

PRO-Instrumente:

* Added: GAD-7 (Generalized Anxiety Disorder 7-item Scale) – vollständige Implementierung mit Questionnaire, Terminologie und Scoring (#80)

FHIR-Ressourcen:

* Fixed: PROMIS-29 englische Variante repariert – 33 fehlerhafte Item-Texte korrigiert
* Removed: Unvollständige PROMIS-29 Minimal-Variante entfernt
* Removed: Unvollständiger ConceptMap-Stub `mii-cm-pro-bdi-ii-to-promis-depression-observation` entfernt (nur 2 von 64 PROsetta-Stone-Einträgen). Architektur-Entscheidung: Score-Konversionen werden zukünftig als CQL Library modelliert (geplant für 2027-Release)
* Fixed: Capabilities-Extension in `mii-qst-pro-promis-cognitive-function-sf4a` vervollständigt (`domainAligned`=true ergänzt)
* Added: Capabilities-Extension zu `mii-qst-pro-pro-ctcae-breast-de` hinzugefügt (`displayable`+`collectable`=true; `calculatable`/`extractable`/`domainAligned`=false – bewusste Entscheidung wegen cross-entity-Charakter, Composite-Grade-Scoring und noch ausstehender Scoring-Algorithmus-Wahl)

**Version: 2026.2.0**

Datum: 2026-03-30 (released, Tag `v2026.2.0`, Simplifier-Package published)

PRO-Instrumente:

* Added: DASS-21 (Depression Anxiety Stress Scales) – vollständige Implementierung mit Questionnaire, Terminologie (CodeSystem, ValueSets), Scoring und Beispielen
* Added: DASS-21 IG-Dokumentationsseite

Dependencies und Tooling:

* Changed: Dependency de.gematik.isik von 5.0.0 auf 5.1.1 aktualisiert (konsistent mit Bildgebung und Laborbefund)
* Changed: Dependency hl7.fhir.uv.extensions.r4 von 5.1.0 auf 5.2.0 aktualisiert (konsistent mit Bildgebung und Laborbefund)

ObservationDefinition:

* Fixed: Depression T-Score ObsDef – Populationsinformation von `qualifiedInterval.context.coding` nach `qualifiedInterval.appliesTo` verschoben (`context` beschreibt die Intervall-Kategorie, nicht die Zielpopulation)

EORTC QLQ-C30 ValueSet-Architektur:

* Changed: EORTC QLQ-C30 ValueSets von contained auf standalone external ValueSets umgestellt (Variant A)
* Added: Post-SUSHI ValueSet-Expansion-Script für LHC Forms Rendering-Kompatibilität
* Fixed: Display-Texte zu EORTC QLQ-C30 ValueSet-Konzepten hinzugefügt

Qualitätssicherung:

* Fixed: ObsDef-Titel entdoppelt, IG-Seite Score-Darstellung verbessert
* Fixed: Kaputte `` Syntax durch Markdown-Blockquotes ersetzt (DASS-21, PHQ-9 IG-Seiten)
* Fixed: CodeSystem/ValueSet auf kurze IDs umgestellt

Hinweis: Die DASS-21- und Qualitätssicherungs-Punkte waren ursprünglich als eigenständiger v2026.1.0-Release geplant, wurden aber nie als eigenes Package veröffentlicht. Inhalt ist erstmals als Teil von v2026.2.0 released.

**Version: 2026.0.1**

Datum: 26.01.2026

Bugfix-Release mit PROMIS-29 Ergänzungen und Canonical-URL-Korrektur.

FHIR-Ressourcen:

* Added: PROMIS-29 Deutsche Variante und umfassende Beispiele
* Fixed: PROMIS-29 QuestionnaireResponse Validierungsfehler behoben
* Fixed: Canonical URLs auf https standardisiert (http zu https)
* Fixed: packageId korrigiert (kerndatensatz.pro zu kerndatensatz.pros)

IG-Dokumentation:

* Changed: PROMIS IG-Seiten reorganisiert und Tree-Rendering gefixt
* Added: Individuelle Profilseiten für abstrakte Profile
* Added: SDC STU3 Spec-Links zu Questionnaire- und QR-Profilseiten

**Version: 2026.0.0**

Datum: 12.01.2026

Erster stabiler Release des MII PRO-Moduls für den produktiven Einsatz.

FHIR-Ressourcen und Profile:

* Added: SearchParameters für Questionnaire, QuestionnaireResponse, Observation (Suche nach Code, Subject, Patient)
* Added: CapabilityStatement zur Dokumentation der unterstützten FHIR-Operationen des PRO-Moduls
* Fixed: meta.profile zu allen Observation-Beispielinstanzen hinzugefügt (FHIR-Konformität)

Versionsverwaltung und Metadaten:

* Added: MetaProfile RuleSet für konsistente Profil-Konformanz mit versionierten Canonicals (Format: `{canonical}|{version}`)
* Added: ObsDefVersion RuleSet für R5-Backport der artifact-version Extension in ObservationDefinition (R4-Kompatibilität)
* Changed: Version RuleSets in zentrale Datei extrahiert (`input/fsh/rulesets/version.fsh`) für einfachere Release-Verwaltung

Dependencies und Tooling:

* Changed: Abhängigkeit zu de.medizininformatikinitiative.kerndatensatz.meta auf 2026.0.0 aktualisiert
* Added: package.bake.yaml für Firely Bake Packaging-Workflow
* Changed: package.json Name-Korrektur zu `de.medizininformatikinitiative.kerndatensatz.pros`

Qualitätssicherung und Validierung:

* Added: EORTC QLQ-C30 Validierungs-Suppressions und QA-Dokumentation
* Added: Vollständige Wartung des Questionnaire- und Score-Katalogs
* Changed: CI/CD mit inline Java-Validierung, Gradle-Caching und Timing-Informationen für schnellere Builds

Developer Experience:

* Added: Claude Code Konfiguration mit Build-, Release- und IG-Export-Skills
* Added: Zentralisiertes `/build-package` Kommando für FHIR Package Building
* Added: `/mii-testdata-contribution` Skill für Testdaten-Repository
* Added: `/fix-ig-export-links` Skill für Simplifier IG Export Link-Reparatur

**Version: 2026.0.0-ballot**

Initiale Ballotierungsversion mit Fokus auf SDC-basierte PRO-Erfassung und Score-Berechnung.

PRO-Instrumente:

* PHQ-9 (Patient Health Questionnaire-9) mit vollständiger Score-Berechnung (Raw-Score und T-Score)
* EQ-5D-5L (EuroQol 5-Dimension 5-Level) mit Index-, VAS- und Profil-Scores
* PROMIS-29 Profile v2.1 mit allen 7 Domänen (Physical Function, Anxiety, Depression, Fatigue, Sleep Disturbance, Social Function, Pain) und automatischer Scoring-Berechnung
* PROMIS Cognitive Function SF4a
* BDI-II (Beck Depression Inventory II) als Referenzimplementierung
* EORTC QLQ-C30 (Lebensqualität bei Krebspatienten) mit 15 Subskalen

FHIR Profile und Extensions:

* MII_PR_PRO_Questionnaire: SDC-basiertes Questionnaire-Profil mit Calculated Expressions und Conditional Display
* MII_PR_PRO_QuestionnaireResponse: Response-Erfassungsprofil mit SDC Extraction Capabilities
* MII_PR_PRO_Score_Blueprint: Vorlage für Score-Observations mit ObservationDefinition-Referenz
* MII_PR_PRO_Score_Instance: Instanz-Profil für berechnete Scores mit derivedFrom-Verknüpfung
* EX_MII_PRO_Questionnaire_Capabilities: Extension zur Dokumentation von Questionnaire-Fähigkeiten (displayable, collectable, calculatable, extractable)

Terminologie-Strategie:

* MII-kontrollierte CodeSysteme und ValueSets für zuverlässige Score-Berechnung mit ordinalValue-Extensions
* Deutsche Übersetzungen für alle Questionnaire-Items via translation-Extensions
* ordinalValue-Extensions (SDC STU3) für numerische Scoring-Gewichte in Antwort-Optionen
* FHIRPath-Ausdrücke nutzen `.ordinal()` für Weight-basierte Berechnungen

Technische Basis:

* FHIR R4 (4.0.1) mit SDC 3.0.0 (Structured Data Capture)
* Dependency zu de.medizininformatikinitiative.kerndatensatz.meta 2026.0.0
* Dependency zu de.gematik.isik 5.0.0 für deutsche Interoperabilität

