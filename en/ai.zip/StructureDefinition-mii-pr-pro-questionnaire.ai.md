# MII PR PRO Questionnaire - MII IG PRO v2027.0.0-ballot.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII PR PRO Questionnaire**

## Resource Profile: MII PR PRO Questionnaire ( Experimental ) 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-pr-pro-questionnaire | *Version*:2027.0.0-ballot.2 |
| Active as of 2026-11-11 | *Computable Name*:MII_PR_PRO_Questionnaire |

 
MII PR PRO Questionnaire, based on the FHIR Structure Data Capture Specification 

The abstract Questionnaire profile is the basis for all PRO questionnaires. It inherits from the [SDC Questionnaire](https://hl7.org/fhir/uv/sdc/STU3/StructureDefinition-sdc-questionnaire.html) profile and extends it with MII-specific capabilities and extensions. Concrete instrument profiles (PHQ-9, EQ-5D-5L, PROMIS-29 and so on) must inherit from this profile and add instrument-specific constraints.

**Core elements:**

* A mandatory URL for unambiguous identification
* Status and version for lifecycle management
* Capability extensions governing behaviour (displayable, collectable, calculatable, extractable)
* SDC extensions for advanced functionality (rendering, calculation, extraction)

**Example** — a concrete questionnaire inheriting from this abstract profile: [PHQ-9](Questionnaire-mii-qst-pro-phq-9.md).

**Usages:**

* Examples for this Profile: [Questionnaire/mii-qst-pro-bdi-bdi2](Questionnaire-mii-qst-pro-bdi-bdi2.md), [Questionnaire/mii-qst-pro-ces-d](Questionnaire-mii-qst-pro-ces-d.md), [Questionnaire/mii-qst-pro-dass-dass21](Questionnaire-mii-qst-pro-dass-dass21.md), [Questionnaire/mii-qst-pro-eortc-qlq-c30](Questionnaire-mii-qst-pro-eortc-qlq-c30.md)... Show 27 more, [Questionnaire/mii-qst-pro-epds](Questionnaire-mii-qst-pro-epds.md), [Questionnaire/mii-qst-pro-euronet-soma](Questionnaire-mii-qst-pro-euronet-soma.md), [Questionnaire/mii-qst-pro-euroqol-eq5d5l-answer-coding](Questionnaire-mii-qst-pro-euroqol-eq5d5l-answer-coding.md), [Questionnaire/mii-qst-pro-euroqol-eq5d5l-collectable](Questionnaire-mii-qst-pro-euroqol-eq5d5l-collectable.md), [Questionnaire/mii-qst-pro-euroqol-eq5d5l-displayable](Questionnaire-mii-qst-pro-euroqol-eq5d5l-displayable.md), [Questionnaire/mii-qst-pro-euroqol-eq5d5l-minimal](Questionnaire-mii-qst-pro-euroqol-eq5d5l-minimal.md), [Questionnaire/mii-qst-pro-gad-7](Questionnaire-mii-qst-pro-gad-7.md), [Questionnaire/mii-qst-pro-hads](Questionnaire-mii-qst-pro-hads.md), [Questionnaire/mii-qst-pro-isr-z](Questionnaire-mii-qst-pro-isr-z.md), [Questionnaire/mii-qst-pro-k6](Questionnaire-mii-qst-pro-k6.md), [MII_QST_PRO_MIDOS_MIDOS2](Questionnaire-mii-qst-pro-midos-midos2.md), [Questionnaire/mii-qst-pro-pc-ptsd](Questionnaire-mii-qst-pro-pc-ptsd.md), [Questionnaire/mii-qst-pro-phq-15](Questionnaire-mii-qst-pro-phq-15.md), [Questionnaire/mii-qst-pro-phq-9](Questionnaire-mii-qst-pro-phq-9.md), [MII_QST_PRO_PRO_CTCAE_Breast_DE](Questionnaire-mii-qst-pro-pro-ctcae-breast-de.md), [MII_QST_PRO_PRO_CTCAE_Onkologisches_Basisscreening](Questionnaire-mii-qst-pro-pro-ctcae-onkologisches-basisscreening.md), [Questionnaire/mii-qst-pro-promis-16](Questionnaire-mii-qst-pro-promis-16.md), [Questionnaire/mii-qst-pro-promis-29-de](Questionnaire-mii-qst-pro-promis-29-de.md), [Questionnaire/mii-qst-pro-promis-29-minimal](Questionnaire-mii-qst-pro-promis-29-minimal.md), [Questionnaire/mii-qst-pro-promis-29](Questionnaire-mii-qst-pro-promis-29.md), [Questionnaire/mii-qst-pro-promis-cognitive-function-sf4a](Questionnaire-mii-qst-pro-promis-cognitive-function-sf4a.md), [Questionnaire/mii-qst-pro-promis-depression-sf4a](Questionnaire-mii-qst-pro-promis-depression-sf4a.md), [Questionnaire/mii-qst-pro-promis-global-health](Questionnaire-mii-qst-pro-promis-global-health.md), [Questionnaire/mii-qst-pro-scoff](Questionnaire-mii-qst-pro-scoff.md), [Questionnaire/mii-qst-pro-ssd-12](Questionnaire-mii-qst-pro-ssd-12.md), [Questionnaire/mii-qst-pro-whodas-whodas12](Questionnaire-mii-qst-pro-whodas-whodas12.md) and [Questionnaire/mii-qst-pro-wi-7](Questionnaire-mii-qst-pro-wi-7.md)
* CapabilityStatements using this Profile: [MII CPS PRO CapabilityStatement](CapabilityStatement-mii-cps-pro-capabilitystatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/de.medizininformatikinitiative.kerndatensatz.pros|current/StructureDefinition/StructureDefinition-mii-pr-pro-questionnaire.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-mii-pr-pro-questionnaire.csv), [Excel](../StructureDefinition-mii-pr-pro-questionnaire.xlsx), [Schematron](../StructureDefinition-mii-pr-pro-questionnaire.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "mii-pr-pro-questionnaire",
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-pr-pro-questionnaire",
  "version" : "2027.0.0-ballot.2",
  "name" : "MII_PR_PRO_Questionnaire",
  "title" : "MII PR PRO Questionnaire",
  "status" : "active",
  "experimental" : true,
  "date" : "2026-11-11T08:11:12+00:00",
  "publisher" : "Medizininformatik-Initiative",
  "contact" : [{
    "name" : "Medizininformatik-Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de"
    },
    {
      "system" : "email",
      "value" : "office@medizininformatik-initiative.de"
    }]
  }],
  "description" : "MII PR PRO Questionnaire, based on the FHIR Structure Data Capture Specification",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "ihe-sdc",
    "name" : "IHE SDC"
  },
  {
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "objimpl",
    "uri" : "http://hl7.org/fhir/object-implementation",
    "name" : "Object Implementation Information"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Questionnaire",
  "baseDefinition" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Questionnaire",
      "path" : "Questionnaire"
    },
    {
      "id" : "Questionnaire.extension",
      "path" : "Questionnaire.extension",
      "min" : 1
    },
    {
      "id" : "Questionnaire.extension:capabilities",
      "path" : "Questionnaire.extension",
      "sliceName" : "capabilities",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/StructureDefinition/mii-ex-pro-questionnaire-capabilities"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Questionnaire.version",
      "path" : "Questionnaire.version",
      "min" : 1
    },
    {
      "id" : "Questionnaire.derivedFrom",
      "path" : "Questionnaire.derivedFrom",
      "mustSupport" : true
    },
    {
      "id" : "Questionnaire.copyright",
      "path" : "Questionnaire.copyright",
      "mustSupport" : true
    },
    {
      "id" : "Questionnaire.code",
      "path" : "Questionnaire.code",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "description" : "Different code systems for the same questionnaire",
        "ordered" : false,
        "rules" : "open"
      },
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Questionnaire.code:snomed",
      "path" : "Questionnaire.code",
      "sliceName" : "snomed",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Questionnaire.code:snomed.system",
      "path" : "Questionnaire.code.system",
      "min" : 1,
      "fixedUri" : "http://snomed.info/sct",
      "mustSupport" : true
    },
    {
      "id" : "Questionnaire.code:snomed.code",
      "path" : "Questionnaire.code.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Questionnaire.code:loinc",
      "path" : "Questionnaire.code",
      "sliceName" : "loinc",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Questionnaire.code:loinc.system",
      "path" : "Questionnaire.code.system",
      "min" : 1,
      "fixedUri" : "http://loinc.org",
      "mustSupport" : true
    },
    {
      "id" : "Questionnaire.code:loinc.code",
      "path" : "Questionnaire.code.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Questionnaire.code:mii",
      "path" : "Questionnaire.code",
      "sliceName" : "mii",
      "min" : 0,
      "max" : "1"
    },
    {
      "id" : "Questionnaire.code:mii.system",
      "path" : "Questionnaire.code.system",
      "min" : 1,
      "fixedUri" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-pro/CodeSystem/mii-cs-pro-questionnaire-catalogue",
      "mustSupport" : true
    },
    {
      "id" : "Questionnaire.code:mii.code",
      "path" : "Questionnaire.code.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Questionnaire.item.answerOption.extension",
      "path" : "Questionnaire.item.answerOption.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Questionnaire.item.answerOption.extension:itemWeight",
      "path" : "Questionnaire.item.answerOption.extension",
      "sliceName" : "itemWeight",
      "short" : "Scoring weight of this option (SDC .weight())",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/itemWeight"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Questionnaire.item.answerOption.value[x]:valueCoding",
      "path" : "Questionnaire.item.answerOption.value[x]",
      "sliceName" : "valueCoding",
      "type" : [{
        "code" : "Coding"
      }]
    },
    {
      "id" : "Questionnaire.item.answerOption.value[x]:valueCoding.extension:itemWeightOnCoding",
      "path" : "Questionnaire.item.answerOption.value[x].extension",
      "sliceName" : "itemWeightOnCoding",
      "short" : "Not allowed here: put itemWeight on the answerOption, not on its Coding",
      "min" : 0,
      "max" : "0",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/itemWeight"]
      }]
    }]
  }
}

```
