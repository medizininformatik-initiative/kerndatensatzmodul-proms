# Code Systems - MII IG PRO v2027.0.0-ballot.rc4

* [**Table of Contents**](toc.md)
* **Code Systems**

## Code Systems

> **Optional page (0..1).** The KDS module menu lists this page as **optional**. Decide for your module: **keep** it — fill it in and delete this banner and the `OPTIONAL-PAGE` marker comment (in this file AND the German mirror) — or **remove** it, following the per-entry procedure in [`docs/optional-pages.md`](https://github.com/medizininformatik-initiative/kerndatensatzmodul-proms/blob/main/docs/optional-pages.md) of this repository. A release must not ship with this banner (convention check M9).

### Code Systems

This page describes the CodeSystems of the **PRO** module (naming convention `MII_CS_<Module>_<Name>`). The ValueSets built on them are described on the [Value Sets](value-sets.md) page.

**Important:** CodeSystem resources of external terminologies (e.g. ICD-10-GM, OPS, SNOMED CT) are **not** published in this module; they are obtained from the central KDS terminology service (SU-TermServ): [https://mii-termserv.de/](https://mii-termserv.de/).

> [TODO: List the module's own CodeSystems, or refer to the automatically generated artifact list — or remove this page if your module defines none.]

